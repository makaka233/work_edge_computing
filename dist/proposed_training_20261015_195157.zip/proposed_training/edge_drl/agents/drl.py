from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import torch
from torch import nn

from edge_drl.env.environment import EdgeComputingEnv
from edge_drl.env.scenario import TaskRequest
from edge_drl.models.ppo import PPOAgent
from edge_drl.allocators.nic_kkt import nic_link_rates
from edge_drl.agents.rollout_features import edge_features as vector_edge_features, route_plan, nic_features
from edge_drl.agents.slow_context import (
    SlowDeploymentContext, SLOW_DEPLOYMENT_CONTEXT, INVENTORY_DIM, BUDGET_DIM,
    CURRENT_STAGE_DIM, CANDIDATE_DIM, STAGE_COST_DIM,
)
from edge_drl.agents.slow_chain_context import (
    SlowChainContext, SLOW_CHAIN_CONTEXT, CHAIN_NODE_DIM, CHAIN_STAGE_DIM,
)
from edge_drl.agents.slow_history import HISTORY_NODE_DIM, HISTORY_STAGE_DIM, SlowRouteHistory


SLOW_GLOBAL_DIM = 17
SLOW_NODE_BASE_FEATURE_DIM = 6
SLOW_EDGE_FEATURE_DIM = 4
SLOW_STAGE_FEATURE_DIM = 10


def _discounted_window_returns(
    rewards: np.ndarray,
    dones: np.ndarray,
    gamma: float,
) -> np.ndarray:
    """Discount ten-minute Slow rewards without crossing episode boundaries."""

    rewards_np = np.asarray(rewards, dtype=np.float32)
    dones_np = np.asarray(dones, dtype=bool)
    if rewards_np.ndim != 1 or dones_np.shape != rewards_np.shape:
        raise ValueError("Slow rewards and dones must have the same 1D shape")
    if not 0.0 <= gamma <= 1.0:
        raise ValueError("Slow window gamma must be in [0, 1]")
    discounted = np.zeros_like(rewards_np)
    running_return = 0.0
    for index in range(len(rewards_np) - 1, -1, -1):
        if dones_np[index]:
            running_return = 0.0
        running_return = float(rewards_np[index]) + gamma * running_return
        discounted[index] = running_return
    return discounted


def slow_node_feature_dim(num_service_types: int, cost_context: bool = False,
                          max_service_stages: int = 3, deployment_context: bool = False,
                          chain_context: bool = False, history_context: bool = False) -> int:
    return SLOW_NODE_BASE_FEATURE_DIM + num_service_types + (2 if cost_context else 0) + (
        num_service_types * max_service_stages + CANDIDATE_DIM if deployment_context else 0) + (CHAIN_NODE_DIM if chain_context else 0) + (HISTORY_NODE_DIM if history_context else 0)


def slow_global_dim(num_service_types: int, cost_context: bool = False,
                    max_service_stages: int = 3, deployment_context: bool = False,
                    integer_quotas: bool = False, tail_reallocation: bool = False) -> int:
    return SLOW_GLOBAL_DIM + (5 * num_service_types if cost_context else 0) + (
        INVENTORY_DIM * num_service_types * max_service_stages + BUDGET_DIM + CURRENT_STAGE_DIM
        if deployment_context else 0) + (5 if integer_quotas else 0) + (
        1 + num_service_types * max_service_stages if tail_reallocation else 0)


def slow_stage_feature_dim(cost_context: bool = False, deployment_context: bool = False,
                           chain_context: bool = False, history_context: bool = False) -> int:
    return SLOW_STAGE_FEATURE_DIM + (2 if cost_context else 0) + (STAGE_COST_DIM if deployment_context else 0) + (CHAIN_STAGE_DIM if chain_context else 0) + (HISTORY_STAGE_DIM if history_context else 0)


def slow_obs_dim(num_nodes: int, num_service_types: int, cost_context: bool = False,
                 max_service_stages: int = 3, deployment_context: bool = False,
                 integer_quotas: bool = False, chain_context: bool = False,
                 tail_reallocation: bool = False) -> int:
    return (
        slow_global_dim(num_service_types, cost_context, max_service_stages, deployment_context, integer_quotas, tail_reallocation)
        + num_nodes * slow_node_feature_dim(num_service_types, cost_context, max_service_stages, deployment_context, chain_context, tail_reallocation)
        + num_nodes * num_nodes * SLOW_EDGE_FEATURE_DIM
    )


def slow_incremental_obs_dim(
    num_nodes: int,
    num_service_types: int,
    max_service_stages: int,
    cost_context: bool = False,
    deployment_context: bool = False,
    integer_quotas: bool = False,
    chain_context: bool = False,
    tail_reallocation: bool = False,
) -> int:
    return slow_obs_dim(num_nodes, num_service_types, cost_context, max_service_stages, deployment_context, integer_quotas, chain_context, tail_reallocation) + (
        num_service_types * max_service_stages * slow_stage_feature_dim(cost_context, deployment_context, chain_context, tail_reallocation)
    )


def fast_feature_dims(chain_context: str = "legacy", batch_credit: bool = False) -> tuple[int, int]:
    if chain_context == "legacy":
        return FAST_GLOBAL_DIM, FAST_NODE_FEATURE_DIM
    if chain_context == "chain-v2":
        return FAST_CHAIN_GLOBAL_DIM, FAST_CHAIN_NODE_FEATURE_DIM
    if chain_context == "chain-kkt-v3":
        return FAST_KKT_GLOBAL_DIM + (6 if batch_credit else 0), FAST_KKT_NODE_FEATURE_DIM
    raise ValueError("fast chain context must be 'legacy', 'chain-v2', or 'chain-kkt-v3'")


def fast_obs_dim(
    num_nodes: int,
    policy_kind: str = "gat_node_scorer",
    chain_context: str = "legacy",
    batch_credit: bool = False,
) -> int:
    global_dim, node_feature_dim = fast_feature_dims(chain_context, batch_credit)
    dim = global_dim + num_nodes * node_feature_dim
    if policy_kind == "gat_node_scorer":
        dim += num_nodes * num_nodes * FAST_EDGE_FEATURE_DIM
    return dim


FAST_GLOBAL_DIM = 12
FAST_NODE_FEATURE_DIM = 9
FAST_EDGE_FEATURE_DIM = 3
FAST_CHAIN_GLOBAL_DIM = 16
FAST_CHAIN_NODE_FEATURE_DIM = 13
FAST_KKT_GLOBAL_DIM = 18
FAST_KKT_NODE_FEATURE_DIM = 18


class SlowWindowCritic(nn.Module):
    def __init__(self, obs_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, states: torch.Tensor) -> torch.Tensor:
        return self.network(states).squeeze(-1)


@dataclass
class SlowDeploymentPPOAgent:
    num_nodes: int
    num_service_types: int
    max_service_stages: int
    replicas_per_stage: int = 5
    coverage_repair: bool = True
    lr: float = 3e-4
    count_lr: float = 2e-4
    stage_lr: float | None = None
    placement_lr: float | None = None
    k_epochs: int = 3
    stage_k_epochs: int | None = None
    placement_k_epochs: int | None = None
    entropy_coef: float = 0.001
    count_entropy_coef: float | None = None
    placement_entropy_coef: float | None = 0.005
    placement_entropy_final_coef: float | None = 0.0035
    placement_entropy_hold_updates: int = 64
    placement_entropy_decay_updates: int = 64
    placement_entropy_target: float | None = 1.8
    placement_entropy_max_coef: float = 0.05
    placement_entropy_adaptation_rate: float = 2e-3
    count_global_advantage_coef: float = 0.25
    placement_global_advantage_coef: float = 0.35
    placement_global_attribution_coef: float = 0.50
    global_advantage_ev_full: float = 0.20
    value_coef: float = 0.5
    count_value_coef: float = 0.0
    critic_lr: float | None = 5e-4
    critic_k_epochs: int = 8
    critic_replay_windows: int = 96
    critic_replay_decay: float = 0.90
    critic_holdout_windows: int = 12
    critic_holdout_episodes: int = 2
    critic_gradient_clip: float = 5.0
    window_gamma: float = 0.95
    target_kl: float | None = 0.03
    count_target_kl: float | None = 0.015
    placement_target_kl: float | None = None
    minibatch_size: int = 2048
    tail_latency_coef: float = 0.35
    deterministic_count_mode: str = "expected"
    allocation_mode: str = "legacy-factorized"
    quota_decode: str = "auto"
    counterfactual_credit_coef: float = 0.0
    cost_context: bool = False
    team_window_credit: bool = False
    team_value_coef: float = 0.5
    deployment_context: str = "legacy"
    learning_repair: str = "none"
    device: str = "cpu"
    _active_context: SlowDeploymentContext | None = field(default=None, init=False, repr=False)
    last_deployment_diagnostics: list[dict] = field(default_factory=list, init=False)
    last_stage_budget_diagnostics: list[dict] = field(default_factory=list, init=False)
    last_update_diagnostics: dict = field(default_factory=dict, init=False)
    count_ppo: PPOAgent = field(init=False)
    stage_ppo: PPOAgent | None = field(init=False, default=None)
    placement_ppo: PPOAgent = field(init=False)
    ppo: PPOAgent = field(init=False)
    window_critic: SlowWindowCritic = field(init=False)
    critic_optimizer: torch.optim.Optimizer = field(init=False)
    pending_count_indices: list[int] = field(default_factory=list)
    pending_placement_indices: list[int] = field(default_factory=list)
    pending_count_stage_keys: list[tuple[int, int]] = field(default_factory=list)
    pending_count_node_ids: list[int | None] = field(default_factory=list)
    pending_stage_indices: list[int] = field(default_factory=list)
    pending_stage_keys: list[tuple[int, int]] = field(default_factory=list)
    pending_stage_node_ids: list[int] = field(default_factory=list)
    pending_budget_fraction: float = 0.0
    pending_budget_feasible_capacity: int = 0
    pending_budget_replica_slot_upper_bound: int = 0
    pending_budget_requested_replicas: int = 0
    pending_budget_available_memory_gb: float = 0.0
    pending_budget_available_storage_gb: float = 0.0
    pending_budget_target_memory_gb: float = 0.0
    pending_budget_target_storage_gb: float = 0.0
    pending_budget_used_memory_gb: float = 0.0
    pending_budget_used_storage_gb: float = 0.0
    pending_placement_stage_keys: list[tuple[int, int]] = field(default_factory=list)
    count_action_returns: list[float] = field(default_factory=list)
    stage_action_returns: list[float] = field(default_factory=list)
    placement_action_returns: list[float] = field(default_factory=list)
    count_action_stage_keys: list[tuple[int, int]] = field(default_factory=list)
    stage_action_stage_keys: list[tuple[int, int]] = field(default_factory=list)
    placement_action_stage_keys: list[tuple[int, int]] = field(default_factory=list)
    count_window_ids: list[int] = field(default_factory=list)
    stage_window_ids: list[int] = field(default_factory=list)
    placement_window_ids: list[int] = field(default_factory=list)
    window_states: list[np.ndarray] = field(default_factory=list)
    window_old_values: list[float] = field(default_factory=list)
    window_returns: list[float] = field(default_factory=list)
    window_dones: list[bool] = field(default_factory=list)
    window_episode_ids: list[int] = field(default_factory=list)
    pending_window_id: int | None = None
    last_window_feedback: dict[str, float] = field(default_factory=dict)
    last_route_history: dict = field(default_factory=dict)
    placement_updates_completed: int = field(default=0, init=False)
    placement_entropy_current_coef: float = field(default=0.0, init=False)
    last_window_critic_holdout_ev: float = field(default=0.0, init=False)
    critic_return_mean: float = field(default=0.0, init=False)
    critic_return_std: float = field(default=1.0, init=False)
    critic_update_index: int = field(default=0, init=False)
    critic_replay_states: list[np.ndarray] = field(default_factory=list)
    critic_replay_returns: list[float] = field(default_factory=list)
    critic_replay_update_ids: list[int] = field(default_factory=list)
    critic_replay_episode_ids: list[int] = field(default_factory=list)
    critic_episode_index: int = field(default=0, init=False)

    def __post_init__(self) -> None:
        if self.quota_decode == "auto":
            self.quota_decode = ("categorical-mean" if self.allocation_mode in {"stage-budget-v5", "stage-budget-v6"}
                                 else "categorical-mode" if self.integer_quotas else "mean")
        expected_decoders = ({"categorical-mode", "categorical-mean"} if self.integer_quotas else
                             {"mean", "integer-mode"} if self.allocation_mode == "stage-budget-v3" else {"mean"})
        if self.quota_decode not in expected_decoders:
            raise ValueError(f"quota decoder {self.quota_decode!r} is incompatible with {self.allocation_mode}")
        if self.deployment_context not in {"legacy", SLOW_DEPLOYMENT_CONTEXT, SLOW_CHAIN_CONTEXT}:
            raise ValueError("unknown Slow deployment context")
        if self.chain_context and not self.integer_quotas:
            raise ValueError("deployment-chain-v3 requires integer stage budgets")
        if self.tail_reallocation and not self.chain_context:
            raise ValueError("stage-budget-v6 requires deployment-chain-v3")
        if self.learning_repair not in {"none", "conditional-replay-v1", "prefix-credit-v2", "prefix-structured-v3"}:
            raise ValueError("unknown Slow learning repair")
        if self.learning_repair != "none" and not self.deployment_aware:
            raise ValueError("Slow learning repair requires deployment-aware-v2")
        if self.deployment_aware and (not self.team_window_credit or self.allocation_mode not in {"budget-continuous-v2", "stage-budget-v3", "stage-budget-v4", "stage-budget-v5", "stage-budget-v6"}):
            raise ValueError("deployment-aware-v2 requires repaired team credit and budget-continuous-v2")
        if self.integer_quotas and not self.deployment_aware:
            raise ValueError("stage-budget-v4 requires deployment-aware-v2")
        if self.team_window_credit and (not np.isfinite(self.team_value_coef) or self.team_value_coef <= 0):
            raise ValueError("conditional team critic requires a positive finite team_value_coef")
        if not 0.0 <= self.tail_latency_coef <= 1.0:
            raise ValueError("tail_latency_coef must be in [0, 1]")
        if self.deterministic_count_mode not in {"expected", "mode"}:
            raise ValueError("deterministic_count_mode must be 'expected' or 'mode'")
        if self.allocation_mode not in {
            "legacy-factorized",
            "global-incremental",
            "budget-incremental",
            "budget-continuous-v2",
            "stage-budget-v3",
            "stage-budget-v4",
            "stage-budget-v5",
            "stage-budget-v6",
        }:
            raise ValueError(
                "allocation_mode must be 'legacy-factorized', 'global-incremental', "
                "'budget-incremental', or 'budget-continuous-v2'"
            )
        if self.counterfactual_credit_coef < 0.0:
            raise ValueError("counterfactual_credit_coef must be non-negative")
        if self.stage_lr is not None and self.stage_lr <= 0.0:
            raise ValueError("stage_lr must be positive when provided")
        if self.placement_lr is not None and self.placement_lr <= 0.0:
            raise ValueError("placement_lr must be positive when provided")
        if self.stage_k_epochs is not None and self.stage_k_epochs < 1:
            raise ValueError("stage_k_epochs must be positive when provided")
        if self.placement_k_epochs is not None and self.placement_k_epochs < 1:
            raise ValueError("placement_k_epochs must be positive when provided")
        placement_entropy_start = self._placement_entropy_start()
        placement_entropy_final = self._placement_entropy_final()
        if placement_entropy_start < 0.0 or placement_entropy_final < 0.0:
            raise ValueError("placement entropy coefficients must be non-negative")
        if placement_entropy_final > placement_entropy_start:
            raise ValueError("placement_entropy_final_coef must not exceed the initial coefficient")
        if self.placement_entropy_hold_updates < 0:
            raise ValueError("placement_entropy_hold_updates must be >= 0")
        if self.placement_entropy_decay_updates < 1:
            raise ValueError("placement_entropy_decay_updates must be >= 1")
        if self.placement_entropy_target is not None and self.placement_entropy_target < 0.0:
            raise ValueError("placement_entropy_target must be non-negative")
        if self.placement_entropy_max_coef < placement_entropy_start:
            raise ValueError("placement_entropy_max_coef must be at least the initial coefficient")
        if self.placement_entropy_adaptation_rate < 0.0:
            raise ValueError("placement_entropy_adaptation_rate must be non-negative")
        if self.count_global_advantage_coef < 0.0 or self.placement_global_advantage_coef < 0.0:
            raise ValueError("Slow global advantage coefficients must be non-negative")
        if self.placement_global_attribution_coef < 0.0:
            raise ValueError("placement_global_attribution_coef must be non-negative")
        if self.global_advantage_ev_full <= 0.0:
            raise ValueError("global_advantage_ev_full must be positive")
        if not 0.0 <= self.window_gamma <= 1.0:
            raise ValueError("window_gamma must be in [0, 1]")
        if self.critic_replay_windows < 1:
            raise ValueError("critic_replay_windows must be positive")
        if self.critic_holdout_windows < 1:
            raise ValueError("critic_holdout_windows must be positive")
        if self.critic_holdout_episodes < 1:
            raise ValueError("critic_holdout_episodes must be positive")
        if self.critic_replay_windows <= self.critic_holdout_windows:
            raise ValueError("critic_replay_windows must exceed critic_holdout_windows")
        if not 0.0 < self.critic_replay_decay <= 1.0:
            raise ValueError("critic_replay_decay must be in (0, 1]")
        if self.critic_gradient_clip <= 0.0:
            raise ValueError("critic_gradient_clip must be positive")
        self.placement_entropy_current_coef = placement_entropy_start
        incremental_allocation = self.allocation_mode in {
            "global-incremental",
            "budget-incremental",
            "budget-continuous-v2",
            "stage-budget-v3",
            "stage-budget-v4",
            "stage-budget-v5",
            "stage-budget-v6",
        }
        budget_allocation = self.allocation_mode in {
            "budget-incremental",
            "budget-continuous-v2",
            "stage-budget-v3",
            "stage-budget-v4",
            "stage-budget-v5",
            "stage-budget-v6",
        }
        continuous_budget = self.allocation_mode in {"budget-continuous-v2", "stage-budget-v3"}
        maximum_extra_replicas = (
            self.num_nodes * self.num_service_types * self.max_service_stages
        )
        self.count_ppo = PPOAgent(
            obs_dim=(
                self._obs_dim()
                if budget_allocation
                else slow_incremental_obs_dim(
                    self.num_nodes,
                    self.num_service_types,
                    self.max_service_stages,
                    self.cost_context,
                    self.deployment_aware,
                )
                if incremental_allocation
                else self._obs_dim()
            ),
            action_dim=(
                self.num_nodes + 1
                if self.integer_quotas
                else 1
                if continuous_budget
                else maximum_extra_replicas + 1
                if budget_allocation
                else self.num_service_types * self.max_service_stages + 1
                if incremental_allocation
                else self.replicas_per_stage
            ),
            hidden_dim=128,
            lr=self.count_lr,
            gamma=0.99,
            k_epochs=self.k_epochs,
            entropy_coef=self.entropy_coef if self.count_entropy_coef is None else self.count_entropy_coef,
            # Count uses direct stage-centered Monte-Carlo returns.  Its
            # consistently failed value head must not dominate the shared
            # graph encoder with critic gradients.
            value_coef=self.team_value_coef if self.team_window_credit else self.count_value_coef,
            target_kl=self.count_target_kl,
            minibatch_size=self.minibatch_size,
            policy_kind=(
                "slow_gat_beta_quota"
                if self.allocation_mode in {"stage-budget-v5", "stage-budget-v6"}
                else "slow_gat_quota"
                if self.integer_quotas
                else "slow_gat_budget"
                if continuous_budget
                else "slow_gat_count"
                if budget_allocation
                else "slow_gat_stage"
                if incremental_allocation
                else "slow_gat_count"
            ),
            global_dim=self._global_dim(),
            node_feature_dim=self._node_dim(),
            edge_feature_dim=SLOW_EDGE_FEATURE_DIM,
            stage_feature_dim=(
                slow_stage_feature_dim(self.cost_context, self.deployment_aware, self.chain_context)
                if incremental_allocation and not budget_allocation
                else None
            ),
            num_nodes=self.num_nodes,
            detach_critic_backbone=True,
            normalize_value_targets=self.team_window_credit,
            independent_critic=self.deployment_aware,
            critic_lr=self.critic_lr if self.deployment_aware else None,
            critic_extra_epochs=max(self.critic_k_epochs - self.k_epochs, 0) if self.deployment_aware else 0,
            slow_learning_repair=self.learning_repair != "none",
            prefix_credit=self.prefix_credit,
            structured_critic=self.learning_repair == "prefix-structured-v3",
            conditional_replay_windows=self.critic_replay_windows,
            conditional_replay_decay=self.critic_replay_decay,
            full_batch_kl_stop=self.deployment_aware,
            guarded_epochs=self.deployment_aware,
            device=self.device,
        )
        self.placement_ppo = PPOAgent(
            obs_dim=self._obs_dim(),
            action_dim=self.num_nodes,
            hidden_dim=128,
            lr=self.lr if self.placement_lr is None else self.placement_lr,
            gamma=0.99,
            k_epochs=(
                self.k_epochs
                if self.placement_k_epochs is None
                else self.placement_k_epochs
            ),
            entropy_coef=self.placement_entropy_coefficient(),
            value_coef=self.team_value_coef if self.team_window_credit else self.value_coef,
            target_kl=self.target_kl if self.placement_target_kl is None else self.placement_target_kl,
            minibatch_size=self.minibatch_size,
            policy_kind="slow_gat_node",
            global_dim=self._global_dim(),
            node_feature_dim=self._node_dim(),
            edge_feature_dim=SLOW_EDGE_FEATURE_DIM,
            num_nodes=self.num_nodes,
            detach_critic_backbone=True,
            normalize_value_targets=self.team_window_credit,
            independent_critic=self.deployment_aware,
            critic_lr=self.critic_lr if self.deployment_aware else None,
            critic_extra_epochs=max(self.critic_k_epochs - self.placement_ppo_epochs, 0) if self.deployment_aware else 0,
            slow_learning_repair=self.learning_repair != "none",
            prefix_credit=self.prefix_credit,
            structured_critic=self.learning_repair == "prefix-structured-v3",
            conditional_replay_windows=self.critic_replay_windows,
            conditional_replay_decay=self.critic_replay_decay,
            full_batch_kl_stop=self.deployment_aware,
            guarded_epochs=self.deployment_aware,
            device=self.device,
        )
        self.ppo = self.placement_ppo
        critic_device = torch.device(self.device)
        self.window_critic = SlowWindowCritic(
            self._obs_dim(),
            hidden_dim=128,
        ).to(critic_device)
        self.critic_optimizer = torch.optim.Adam(
            self.window_critic.parameters(),
            lr=self.lr if self.critic_lr is None else self.critic_lr,
        )
        # The separate Stage actor is exclusive to the new budget mode.  Do
        # not instantiate it for legacy modes: constructing a spare network
        # would consume PyTorch RNG and silently change their reproducibility.
        if budget_allocation:
            self.stage_ppo = PPOAgent(
                obs_dim=slow_incremental_obs_dim(
                    self.num_nodes,
                    self.num_service_types,
                    self.max_service_stages,
                    self.cost_context,
                    self.deployment_aware,
                    self.integer_quotas,
                    self.chain_context,
                    self.tail_reallocation,
                ),
                action_dim=self.num_service_types * self.max_service_stages + 1,
                hidden_dim=128,
                lr=self.count_lr if self.stage_lr is None else self.stage_lr,
                gamma=0.99,
                k_epochs=(
                    self.k_epochs
                    if self.stage_k_epochs is None
                    else self.stage_k_epochs
                ),
                entropy_coef=(
                    self.entropy_coef
                    if self.count_entropy_coef is None
                    else self.count_entropy_coef
                ),
                value_coef=self.team_value_coef if self.team_window_credit else self.count_value_coef,
                target_kl=self.count_target_kl,
                minibatch_size=self.minibatch_size,
                policy_kind="slow_gat_stage",
                global_dim=self._global_dim(),
                node_feature_dim=self._node_dim(),
                edge_feature_dim=SLOW_EDGE_FEATURE_DIM,
                stage_feature_dim=slow_stage_feature_dim(self.cost_context, self.deployment_aware, self.chain_context, self.tail_reallocation),
                num_nodes=self.num_nodes,
                detach_critic_backbone=True,
                normalize_value_targets=self.team_window_credit,
                independent_critic=self.deployment_aware,
                critic_lr=self.critic_lr if self.deployment_aware else None,
                critic_extra_epochs=max(self.critic_k_epochs - (self.stage_k_epochs or self.k_epochs), 0) if self.deployment_aware else 0,
                slow_learning_repair=self.learning_repair != "none",
                prefix_credit=self.prefix_credit,
                structured_critic=self.learning_repair == "prefix-structured-v3",
                conditional_replay_windows=self.critic_replay_windows,
                conditional_replay_decay=self.critic_replay_decay,
                full_batch_kl_stop=self.deployment_aware,
                guarded_epochs=self.deployment_aware,
                device=self.device,
            )

    @property
    def integer_quotas(self) -> bool:
        return self.allocation_mode in {"stage-budget-v4", "stage-budget-v5", "stage-budget-v6"}

    @property
    def tail_reallocation(self) -> bool:
        return self.allocation_mode == "stage-budget-v6"

    @property
    def prefix_credit(self) -> bool:
        return self.learning_repair in {"prefix-credit-v2", "prefix-structured-v3"}

    @property
    def deployment_aware(self) -> bool:
        return self.deployment_context in {SLOW_DEPLOYMENT_CONTEXT, SLOW_CHAIN_CONTEXT}

    @property
    def chain_context(self) -> bool:
        return self.deployment_context == SLOW_CHAIN_CONTEXT

    @property
    def placement_ppo_epochs(self) -> int:
        return self.k_epochs if self.placement_k_epochs is None else self.placement_k_epochs

    def _global_dim(self) -> int:
        return slow_global_dim(self.num_service_types, self.cost_context, self.max_service_stages, self.deployment_aware, self.integer_quotas, self.tail_reallocation)

    def _node_dim(self) -> int:
        return slow_node_feature_dim(self.num_service_types, self.cost_context, self.max_service_stages, self.deployment_aware, self.chain_context, self.tail_reallocation)

    def _obs_dim(self) -> int:
        return slow_obs_dim(self.num_nodes, self.num_service_types, self.cost_context, self.max_service_stages, self.deployment_aware, self.integer_quotas, self.chain_context, self.tail_reallocation)

    def _context(self, env, demand):
        return self._active_context or (SlowChainContext(env, demand, history=self.last_route_history if self.tail_reallocation else None) if self.chain_context else SlowDeploymentContext(env, demand))

    def _deployment_features(self, env, demand, deployment, service_id=None, stage_id=None):
        context = self._context(env, demand)
        budget = [self.pending_budget_fraction,
                  self.pending_budget_target_memory_gb / max(context.memory_capacity.sum(), 1e-9),
                  self.pending_budget_target_storage_gb / max(context.storage_capacity.sum(), 1e-9),
                  max(self.pending_budget_target_memory_gb - self.pending_budget_used_memory_gb, 0) / max(context.memory_capacity.sum(), 1e-9),
                  max(self.pending_budget_target_storage_gb - self.pending_budget_used_storage_gb, 0) / max(context.storage_capacity.sum(), 1e-9),
                  float(self.pending_budget_target_memory_gb > 0)]
        global_features, node_features = context.features(
            deployment, budget=budget, service_id=service_id, stage_id=stage_id)
        visited = getattr(self, "_stage_budget_visited", None)
        if self.allocation_mode in {"stage-budget-v3", "stage-budget-v4", "stage-budget-v5", "stage-budget-v6"} and visited is not None:
            # Preserve visited stages even when Count chose zero extra replicas.
            # Valid=1, valid+already-processed=2; no hidden executor-only state.
            global_features[:context.size * INVENTORY_DIM:INVENTORY_DIM] += visited
        if self.integer_quotas:
            maximum, selected, remaining, phase = getattr(self, "_quota_state", (0, 0, 0, "coverage"))
            global_features = np.r_[global_features, maximum / self.num_nodes,
                selected / self.num_nodes, remaining / self.num_nodes,
                float(phase == "count"), float(phase == "placement")]
        if self.tail_reallocation:
            closed = getattr(self, "_reallocation_closed", np.zeros(context.size, dtype=bool))
            global_features = np.r_[global_features, float(getattr(self, "_reallocation_phase", False)), closed]
        return global_features, node_features

    def _placement_entropy_start(self) -> float:
        return float(self.entropy_coef if self.placement_entropy_coef is None else self.placement_entropy_coef)

    def _placement_entropy_final(self) -> float:
        start = self._placement_entropy_start()
        return float(start if self.placement_entropy_final_coef is None else self.placement_entropy_final_coef)

    def placement_entropy_schedule_coefficient(self) -> float:
        progress = min(
            max(float(self.placement_updates_completed - self.placement_entropy_hold_updates), 0.0)
            / float(self.placement_entropy_decay_updates),
            1.0,
        )
        start = self._placement_entropy_start()
        return start + progress * (self._placement_entropy_final() - start)

    def placement_entropy_coefficient(self) -> float:
        return max(
            float(self.placement_entropy_current_coef),
            self.placement_entropy_schedule_coefficient(),
        )

    def _adapt_placement_entropy_coefficient(self, observed_entropy: float) -> float:
        self.placement_updates_completed += 1
        schedule_floor = self.placement_entropy_schedule_coefficient()
        if self.placement_entropy_target is None or not np.isfinite(observed_entropy):
            next_coef = schedule_floor
        else:
            next_coef = self.placement_entropy_current_coef + self.placement_entropy_adaptation_rate * (
                float(self.placement_entropy_target) - float(observed_entropy)
            )
            next_coef = float(np.clip(next_coef, schedule_floor, self.placement_entropy_max_coef))
        self.placement_entropy_current_coef = float(next_coef)
        self.placement_ppo.entropy_coef = self.placement_entropy_current_coef
        return self.placement_entropy_current_coef

    def global_advantage_reliability(self) -> float:
        """Scale global credit by predictive performance on unseen recent windows."""

        return float(
            np.clip(
                max(self.last_window_critic_holdout_ev, 0.0)
                / self.global_advantage_ev_full,
                0.0,
                1.0,
            )
        )

    def plan_deployment(self, env: EdgeComputingEnv, deterministic: bool = False, record: bool = True) -> np.ndarray:
        try:
            deployment = self._plan_deployment(env, deterministic=deterministic, record=record)
            if self.deployment_aware:
                context = self._active_context
                _, pooled, proxy = context.inventory(deployment)
                self.last_deployment_diagnostics = [
                    {"service_id": service.service_id, "stage_id": stage.stage_id,
                     "nodes": np.flatnonzero(deployment[service.service_id, stage.stage_id]).tolist(),
                     "replicas": int(deployment[service.service_id, stage.stage_id].sum()),
                     "pooled_effective_gcycles_s": float(pooled[service.service_id * self.max_service_stages + stage.stage_id]),
                     "expected_work_gcycles_s": float(context.arrival * context.mass[service.service_id * self.max_service_stages + stage.stage_id] * context.compute[service.service_id * self.max_service_stages + stage.stage_id]),
                     "compute_proxy_cost_s": float(proxy[service.service_id * self.max_service_stages + stage.stage_id]),
                     "memory_per_replica_gb": stage.memory_gb}
                    for service in env.scenario.services for stage in service.stages
                ]
            return deployment
        finally:
            self._active_context = None

    def _plan_deployment(self, env: EdgeComputingEnv, deterministic: bool = False, record: bool = True) -> np.ndarray:
        env._require_ready()
        assert env.scenario is not None
        current = env.deployment if env.deployment is not None else np.zeros(
            (self.num_service_types, self.max_service_stages, self.num_nodes), dtype=bool
        )
        deployment = np.zeros_like(current, dtype=bool)
        remaining_memory = env.service_memory_capacities()
        remaining_storage = env.service_storage_capacities()
        demand = self._node_service_demand(env)
        if self.deployment_aware:
            context_class = SlowChainContext if self.chain_context else SlowDeploymentContext
            self._active_context = context_class(env, demand,
                **({"history":self.last_route_history} if self.tail_reallocation else {}),
                competition_aware=self.allocation_mode in {"stage-budget-v3", "stage-budget-v4", "stage-budget-v5", "stage-budget-v6"})
        self.pending_count_indices.clear()
        self.pending_placement_indices.clear()
        self.pending_count_stage_keys.clear()
        self.pending_count_node_ids.clear()
        self.pending_stage_indices.clear()
        self.pending_stage_keys.clear()
        self.pending_stage_node_ids.clear()
        self.pending_budget_fraction = 0.0
        self.pending_budget_feasible_capacity = 0
        self.pending_budget_replica_slot_upper_bound = 0
        self.pending_budget_requested_replicas = 0
        self.pending_budget_available_memory_gb = 0.0
        self.pending_budget_available_storage_gb = 0.0
        self.pending_budget_target_memory_gb = 0.0
        self.pending_budget_target_storage_gb = 0.0
        self.pending_budget_used_memory_gb = 0.0
        self.pending_budget_used_storage_gb = 0.0
        self.pending_placement_stage_keys.clear()
        self._stage_budget_visited = None
        self._reallocation_phase = False
        self._reallocation_closed = np.zeros(self.num_service_types * self.max_service_stages, dtype=bool)
        self._quota_state = (0, 0, 0, "coverage")
        self.last_stage_budget_diagnostics = []
        window_id: int | None = None
        if record:
            if self.pending_window_id is not None:
                raise RuntimeError("previous slow deployment window has no completed return")
            window_state = self._build_window_state(env, demand, remaining_memory, remaining_storage)
            old_value = 0.
            if not self.prefix_credit:
                state_t = torch.as_tensor(window_state, dtype=torch.float32, device=self.device).unsqueeze(0)
                with torch.no_grad():
                    normalized_value = float(self.window_critic(state_t).item())
                    old_value = normalized_value * self.critic_return_std + self.critic_return_mean
            window_id = len(self.window_states)
            self.window_states.append(window_state)
            self.window_old_values.append(old_value)
            self.pending_window_id = window_id

        if self.allocation_mode in {"stage-budget-v3", "stage-budget-v4", "stage-budget-v5", "stage-budget-v6"}:
            from edge_drl.agents.stage_budget import plan_stage_budgets
            return plan_stage_budgets(self, env, deployment, remaining_memory, remaining_storage,
                                      demand, window_id, deterministic, record)
        if self.allocation_mode in {"budget-incremental", "budget-continuous-v2"}:
            return self._plan_deployment_budget(
                env,
                deployment=deployment,
                remaining_memory=remaining_memory,
                remaining_storage=remaining_storage,
                demand=demand,
                window_id=window_id,
                deterministic=deterministic,
                record=record,
            )
        if self.allocation_mode == "global-incremental":
            return self._plan_deployment_incremental(
                env,
                deployment=deployment,
                remaining_memory=remaining_memory,
                remaining_storage=remaining_storage,
                demand=demand,
                window_id=window_id,
                deterministic=deterministic,
                record=record,
            )

        stage_sequence = [
            (service, stage)
            for service in env.scenario.services
            for stage in service.stages
        ]
        for stage_index, (service, stage) in enumerate(stage_sequence):
            future_stages = [future_stage for _, future_stage in stage_sequence[stage_index + 1 :]]
            reserved_memory = float(sum(future_stage.memory_gb for future_stage in future_stages))
            reserved_storage = float(sum(future_stage.storage_gb for future_stage in future_stages))
            count_state = self._build_state(
                env,
                demand,
                remaining_memory,
                remaining_storage,
                service.service_id,
                stage.stage_id,
                0,
                planned_deployment=deployment,
            )
            count_mask = self._build_count_mask(
                stage,
                remaining_memory,
                remaining_storage,
                reserved_memory=reserved_memory,
                reserved_storage=reserved_storage,
            )
            if not count_mask.any():
                continue
            if deterministic and self.deterministic_count_mode == "expected":
                # Replica count is ordinal.  The categorical mode is unstable while
                # the policy is still broad: a tiny logit difference can turn a
                # nearly uniform policy into an arbitrarily small deployment.  Use
                # the conservative (ceiling) posterior mean for deterministic
                # collection/evaluation, while PPO training still samples exactly
                # from the categorical policy.
                count_probs, count_value = self.count_ppo.action_probabilities(
                    count_state,
                    count_mask,
                )
                expected_replicas = float(
                    np.dot(count_probs, np.arange(1, self.replicas_per_stage + 1, dtype=np.float32))
                )
                target_replicas = int(np.ceil(expected_replicas - 1e-8))
                target_replicas = int(np.clip(target_replicas, 1, int(np.count_nonzero(count_mask))))
                count_action = target_replicas - 1
                count_logprob = float(np.log(max(float(count_probs[count_action]), 1e-12)))
            else:
                count_action, count_logprob, count_value = self.count_ppo.act(
                    count_state,
                    count_mask,
                    deterministic=deterministic,
                )
            if not count_mask[count_action]:
                count_action = int(np.where(count_mask)[0][0])
            target_replicas = count_action + 1
            if record:
                self.count_ppo.buffer.states.append(count_state)
                self.count_ppo.buffer.masks.append(count_mask.astype(bool))
                self.count_ppo.buffer.actions.append(count_action)
                self.count_ppo.buffer.logprobs.append(count_logprob)
                self.count_ppo.buffer.values.append(count_value)
                self.pending_count_indices.append(len(self.count_ppo.buffer.actions) - 1)
                self.pending_count_stage_keys.append((service.service_id, stage.stage_id))
                self.pending_count_node_ids.append(None)
                assert window_id is not None
                self.count_window_ids.append(window_id)

            for replica_idx in range(target_replicas):
                state = self._build_state(
                    env,
                    demand,
                    remaining_memory,
                    remaining_storage,
                    service.service_id,
                    stage.stage_id,
                    replica_idx,
                    planned_deployment=deployment,
                )
                already = deployment[service.service_id, stage.stage_id]
                feasible_new = (
                    (remaining_memory >= stage.memory_gb)
                    & (remaining_storage >= stage.storage_gb)
                    & ~already
                )
                mask = feasible_new
                if not mask.any():
                    break

                action, logprob, value = self.placement_ppo.act(state, mask, deterministic=deterministic)
                if not mask[action]:
                    action = int(np.where(mask)[0][0])

                if record:
                    self.placement_ppo.buffer.states.append(state)
                    self.placement_ppo.buffer.masks.append(mask.astype(bool))
                    self.placement_ppo.buffer.actions.append(action)
                    self.placement_ppo.buffer.logprobs.append(logprob)
                    self.placement_ppo.buffer.values.append(value)
                    self.pending_placement_indices.append(len(self.placement_ppo.buffer.actions) - 1)
                    self.pending_placement_stage_keys.append((service.service_id, stage.stage_id))
                    assert window_id is not None
                    self.placement_window_ids.append(window_id)

                deployment[service.service_id, stage.stage_id, action] = True
                remaining_memory[action] -= stage.memory_gb
                remaining_storage[action] -= stage.storage_gb

        if self.coverage_repair:
            self._coverage_repair(env, deployment, remaining_memory, remaining_storage)

        feasible, reason = env.check_deployment_feasible(deployment)
        if not feasible:
            deployment = self._repair_with_current_or_full(env, deployment)
        return deployment

    def _plan_deployment_budget(
        self,
        env: EdgeComputingEnv,
        *,
        deployment: np.ndarray,
        remaining_memory: np.ndarray,
        remaining_storage: np.ndarray,
        demand: np.ndarray,
        window_id: int | None,
        deterministic: bool,
        record: bool,
    ) -> np.ndarray:
        """Choose one extra-replica budget, then allocate it with Stage/Node PPO.

        Coverage remains mandatory.  Unlike global-incremental mode, termination
        is an ordinal decision made once per window and never competes with a
        long sequence of stage ADD logits.
        """

        assert env.scenario is not None
        stages = [
            (service, stage)
            for service in env.scenario.services
            for stage in service.stages
        ]
        stage_by_key = {
            (int(service.service_id), int(stage.stage_id)): stage
            for service, stage in stages
        }
        memory_capacity = np.maximum(env.service_memory_capacities(), 1e-9)
        storage_capacity = np.maximum(env.service_storage_capacities(), 1e-9)

        def coverage_priority(item) -> tuple[float, float, int, int]:
            service, stage = item
            feasible = np.count_nonzero(
                (remaining_memory >= stage.memory_gb)
                & (remaining_storage >= stage.storage_gb)
            )
            pressure = max(
                float(np.min(stage.memory_gb / memory_capacity)),
                float(np.min(stage.storage_gb / storage_capacity)),
            )
            return float(feasible), -pressure, int(service.service_id), int(stage.stage_id)

        for service, stage in sorted(stages, key=coverage_priority):
            placed = self._place_slow_replica(
                env,
                deployment=deployment,
                remaining_memory=remaining_memory,
                remaining_storage=remaining_storage,
                demand=demand,
                service_id=int(service.service_id),
                stage_id=int(stage.stage_id),
                replica_idx=0,
                window_id=window_id,
                deterministic=deterministic,
                record=record,
            )
            if placed is None:
                break

        budget_state = self._build_window_state(
            env,
            demand,
            remaining_memory,
            remaining_storage,
            planned_deployment=deployment,
        )
        continuous_budget = self.allocation_mode == "budget-continuous-v2"
        if continuous_budget:
            # This count is diagnostic only.  It never scales or discretizes
            # the continuous action because pair counts ignore heterogeneous
            # resource sizes and are not an executable replica capacity.
            replica_slot_upper_bound = self._replica_slot_upper_bound(
                env,
                remaining_memory,
                remaining_storage,
                deployment,
            )
            feasible_budget_capacity = 0
            budget_mask = np.ones(1, dtype=bool)
        else:
            budget_mask = self._build_budget_mask(
                env,
                remaining_memory,
                remaining_storage,
                deployment,
            )
            feasible_budget_capacity = int(np.flatnonzero(budget_mask)[-1])
            replica_slot_upper_bound = 0
        budget_action, budget_logprob, budget_value = self.count_ppo.act(
            budget_state,
            budget_mask,
            deterministic=deterministic,
        )
        if continuous_budget:
            budget_fraction = float(np.clip(float(budget_action), 0.0, 1.0))
            available_memory_gb = float(np.maximum(remaining_memory, 0.0).sum())
            available_storage_gb = float(np.maximum(remaining_storage, 0.0).sum())
            target_memory_gb = budget_fraction * available_memory_gb
            target_storage_gb = budget_fraction * available_storage_gb
            used_memory_gb = 0.0
            used_storage_gb = 0.0
            requested_replicas = 0
            stored_budget_action: int | float = budget_fraction
        else:
            discrete_budget = int(budget_action)
            if not budget_mask[discrete_budget]:
                discrete_budget = int(np.flatnonzero(budget_mask)[0])
            budget_fraction = (
                float(discrete_budget) / max(float(feasible_budget_capacity), 1.0)
            )
            requested_replicas = discrete_budget
            stored_budget_action = discrete_budget
            available_memory_gb = 0.0
            available_storage_gb = 0.0
            target_memory_gb = 0.0
            target_storage_gb = 0.0
            used_memory_gb = 0.0
            used_storage_gb = 0.0
        self.pending_budget_fraction = budget_fraction
        self.pending_budget_feasible_capacity = feasible_budget_capacity
        self.pending_budget_replica_slot_upper_bound = replica_slot_upper_bound
        self.pending_budget_available_memory_gb = available_memory_gb
        self.pending_budget_available_storage_gb = available_storage_gb
        self.pending_budget_target_memory_gb = target_memory_gb
        self.pending_budget_target_storage_gb = target_storage_gb
        if record:
            self.count_ppo.buffer.states.append(budget_state)
            self.count_ppo.buffer.masks.append(budget_mask.astype(bool))
            self.count_ppo.buffer.actions.append(stored_budget_action)
            self.count_ppo.buffer.logprobs.append(float(budget_logprob))
            self.count_ppo.buffer.values.append(float(budget_value))
            self.pending_count_indices.append(len(self.count_ppo.buffer.actions) - 1)
            self.pending_count_stage_keys.append((-2, -2))
            self.pending_count_node_ids.append(None)
            assert window_id is not None
            self.count_window_ids.append(window_id)

        stage_stop_action = self.num_service_types * self.max_service_stages
        if self.stage_ppo is None:
            raise RuntimeError("budget-incremental allocation requires the Slow Stage actor")
        maximum_expansions = (
            self.num_nodes * len(stages)
            if continuous_budget
            else requested_replicas
        )
        allocated_replicas = 0
        for _ in range(maximum_expansions):
            stage_state = self._build_incremental_state(
                env,
                demand,
                remaining_memory,
                remaining_storage,
                deployment,
            )
            stage_mask = self._build_incremental_stage_mask(
                env,
                remaining_memory,
                remaining_storage,
                deployment,
            )
            stage_mask[stage_stop_action] = False
            if continuous_budget:
                remaining_memory_budget = max(
                    target_memory_gb - used_memory_gb,
                    0.0,
                )
                remaining_storage_budget = max(
                    target_storage_gb - used_storage_gb,
                    0.0,
                )
                for service, stage in stages:
                    stage_action_index = (
                        int(service.service_id) * self.max_service_stages
                        + int(stage.stage_id)
                    )
                    if (
                        float(stage.memory_gb) > remaining_memory_budget + 1e-9
                        or float(stage.storage_gb) > remaining_storage_budget + 1e-9
                    ):
                        stage_mask[stage_action_index] = False
            if not stage_mask.any():
                break
            stage_action, stage_logprob, stage_value = self.stage_ppo.act(
                stage_state,
                stage_mask,
                deterministic=deterministic,
            )
            stage_action = int(stage_action)
            if not stage_mask[stage_action]:
                stage_action = int(np.flatnonzero(stage_mask)[0])
            service_id, stage_id = divmod(stage_action, self.max_service_stages)
            replica_idx = int(deployment[service_id, stage_id].sum())
            stage_buffer_index: int | None = None
            if record:
                self.stage_ppo.buffer.states.append(stage_state)
                self.stage_ppo.buffer.masks.append(stage_mask.astype(bool))
                self.stage_ppo.buffer.actions.append(stage_action)
                self.stage_ppo.buffer.logprobs.append(float(stage_logprob))
                self.stage_ppo.buffer.values.append(float(stage_value))
                stage_buffer_index = len(self.stage_ppo.buffer.actions) - 1
                self.pending_stage_indices.append(stage_buffer_index)
                self.pending_stage_keys.append((service_id, stage_id))
                assert window_id is not None
                self.stage_window_ids.append(window_id)
            node_id = self._place_slow_replica(
                env,
                deployment=deployment,
                remaining_memory=remaining_memory,
                remaining_storage=remaining_storage,
                demand=demand,
                service_id=service_id,
                stage_id=stage_id,
                replica_idx=replica_idx,
                window_id=window_id,
                deterministic=deterministic,
                record=record,
            )
            if node_id is None:
                break
            allocated_replicas += 1
            if continuous_budget:
                selected_stage = stage_by_key[(service_id, stage_id)]
                used_memory_gb += float(selected_stage.memory_gb)
                used_storage_gb += float(selected_stage.storage_gb)
            if record:
                assert stage_buffer_index is not None
                self.pending_stage_node_ids.append(int(node_id))

        self.pending_budget_requested_replicas = (
            allocated_replicas if continuous_budget else requested_replicas
        )
        self.pending_budget_used_memory_gb = used_memory_gb
        self.pending_budget_used_storage_gb = used_storage_gb

        if self.coverage_repair:
            self._coverage_repair(env, deployment, remaining_memory, remaining_storage)
        feasible, _ = env.check_deployment_feasible(deployment)
        if not feasible:
            deployment = self._repair_with_current_or_full(env, deployment)
        return deployment

    def _replica_slot_upper_bound(
        self,
        env: EdgeComputingEnv,
        remaining_memory: np.ndarray,
        remaining_storage: np.ndarray,
        deployment: np.ndarray,
    ) -> int:
        """Count currently feasible stage-node pairs for diagnostics only.

        This is deliberately not used to scale the continuous budget action:
        heterogeneous replica sizes make a pair count neither a safe nor an
        exact capacity.  Resource targets are enforced against the actual
        memory and storage cost of every Stage/Placement decision instead.
        """

        assert env.scenario is not None
        active_stages = [
            (service, stage)
            for service in env.scenario.services
            for stage in service.stages
        ]
        if not active_stages:
            return 0
        globally_available = 0
        for service, stage in active_stages:
            service_id = int(service.service_id)
            stage_id = int(stage.stage_id)
            remaining_replicas = max(
                self.replicas_per_stage
                - int(deployment[service_id, stage_id].sum()),
                0,
            )
            if remaining_replicas <= 0:
                continue
            feasible_nodes = (
                (remaining_memory >= float(stage.memory_gb))
                & (remaining_storage >= float(stage.storage_gb))
                & ~deployment[service_id, stage_id]
            )
            globally_available += min(
                int(np.count_nonzero(feasible_nodes)),
                remaining_replicas,
            )
        return max(globally_available, 0)

    def _build_budget_mask(
        self,
        env: EdgeComputingEnv,
        remaining_memory: np.ndarray,
        remaining_storage: np.ndarray,
        deployment: np.ndarray,
    ) -> np.ndarray:
        """Return a conservative ordinal mask for feasible extra-replica budgets."""

        assert env.scenario is not None
        possible = 0
        minimum_memory = float("inf")
        minimum_storage = float("inf")
        for service in env.scenario.services:
            for stage in service.stages:
                feasible = (
                    (remaining_memory >= stage.memory_gb)
                    & (remaining_storage >= stage.storage_gb)
                    & ~deployment[service.service_id, stage.stage_id]
                )
                possible += min(
                    int(np.count_nonzero(feasible)),
                    max(self.replicas_per_stage - int(deployment[service.service_id, stage.stage_id].sum()), 0),
                )
                minimum_memory = min(minimum_memory, float(stage.memory_gb))
                minimum_storage = min(minimum_storage, float(stage.storage_gb))
        memory_bound = int(np.floor(float(remaining_memory.sum()) / max(minimum_memory, 1e-9)))
        storage_bound = int(np.floor(float(remaining_storage.sum()) / max(minimum_storage, 1e-9)))
        action_dim = int(self.count_ppo.policy.action_dim)
        maximum = min(possible, memory_bound, storage_bound, action_dim - 1)
        mask = np.zeros(action_dim, dtype=bool)
        mask[: maximum + 1] = True
        return mask

    def _plan_deployment_incremental(
        self,
        env: EdgeComputingEnv,
        *,
        deployment: np.ndarray,
        remaining_memory: np.ndarray,
        remaining_storage: np.ndarray,
        demand: np.ndarray,
        window_id: int | None,
        deterministic: bool,
        record: bool,
    ) -> np.ndarray:
        """Allocate coverage first, then spend the shared budget one replica at a time.

        The legacy policy commits every requested replica for service 0 before
        service 1 is considered.  Under a nearly full memory budget that makes
        service id, rather than marginal value, decide who gets the remaining
        capacity.  This mode first establishes one feasible replica per stage;
        a topology-aware stage actor then chooses the owner of every additional
        replica and can stop before filling the budget.
        """

        assert env.scenario is not None
        stages = [
            (service, stage)
            for service in env.scenario.services
            for stage in service.stages
        ]
        memory_capacity = np.maximum(env.service_memory_capacities(), 1e-9)
        storage_capacity = np.maximum(env.service_storage_capacities(), 1e-9)

        def coverage_priority(item) -> tuple[float, float, int, int]:
            service, stage = item
            feasible = np.count_nonzero(
                (remaining_memory >= stage.memory_gb)
                & (remaining_storage >= stage.storage_gb)
            )
            resource_pressure = max(
                float(np.min(stage.memory_gb / memory_capacity)),
                float(np.min(stage.storage_gb / storage_capacity)),
            )
            # Most constrained stages go first.  IDs are only deterministic
            # tie breakers and no longer control allocation of extra replicas.
            return (
                float(feasible),
                -resource_pressure,
                int(service.service_id),
                int(stage.stage_id),
            )

        for service, stage in sorted(stages, key=coverage_priority):
            placed = self._place_slow_replica(
                env,
                deployment=deployment,
                remaining_memory=remaining_memory,
                remaining_storage=remaining_storage,
                demand=demand,
                service_id=int(service.service_id),
                stage_id=int(stage.stage_id),
                replica_idx=0,
                window_id=window_id,
                deterministic=deterministic,
                record=record,
            )
            if placed is None:
                break

        stop_action = self.num_service_types * self.max_service_stages
        maximum_expansions = self.num_nodes * len(stages)
        for _ in range(maximum_expansions):
            count_state = self._build_incremental_state(
                env,
                demand,
                remaining_memory,
                remaining_storage,
                deployment,
            )
            count_mask = self._build_incremental_stage_mask(
                env,
                remaining_memory,
                remaining_storage,
                deployment,
            )
            if not count_mask[:-1].any():
                break
            count_action, count_logprob, count_value = self.count_ppo.act(
                count_state,
                count_mask,
                deterministic=deterministic,
            )
            if not count_mask[count_action]:
                count_action = stop_action

            stage_key = (
                (-1, -1)
                if count_action == stop_action
                else divmod(int(count_action), self.max_service_stages)
            )
            count_buffer_index: int | None = None
            if record:
                self.count_ppo.buffer.states.append(count_state)
                self.count_ppo.buffer.masks.append(count_mask.astype(bool))
                self.count_ppo.buffer.actions.append(int(count_action))
                self.count_ppo.buffer.logprobs.append(float(count_logprob))
                self.count_ppo.buffer.values.append(float(count_value))
                count_buffer_index = len(self.count_ppo.buffer.actions) - 1
                self.pending_count_indices.append(count_buffer_index)
                self.pending_count_stage_keys.append(stage_key)
                self.pending_count_node_ids.append(None)
                assert window_id is not None
                self.count_window_ids.append(window_id)

            if count_action == stop_action:
                break

            service_id, stage_id = stage_key
            replica_idx = int(deployment[service_id, stage_id].sum())
            node_id = self._place_slow_replica(
                env,
                deployment=deployment,
                remaining_memory=remaining_memory,
                remaining_storage=remaining_storage,
                demand=demand,
                service_id=service_id,
                stage_id=stage_id,
                replica_idx=replica_idx,
                window_id=window_id,
                deterministic=deterministic,
                record=record,
            )
            if node_id is None:
                break
            if record:
                assert count_buffer_index is not None
                self.pending_count_node_ids[-1] = int(node_id)

        if self.coverage_repair:
            self._coverage_repair(env, deployment, remaining_memory, remaining_storage)
        feasible, _ = env.check_deployment_feasible(deployment)
        if not feasible:
            deployment = self._repair_with_current_or_full(env, deployment)
        return deployment

    def _place_slow_replica(
        self,
        env: EdgeComputingEnv,
        *,
        deployment: np.ndarray,
        remaining_memory: np.ndarray,
        remaining_storage: np.ndarray,
        demand: np.ndarray,
        service_id: int,
        stage_id: int,
        replica_idx: int,
        window_id: int | None,
        deterministic: bool,
        record: bool,
    ) -> int | None:
        assert env.scenario is not None
        stage = env.scenario.services[service_id].stages[stage_id]
        already = deployment[service_id, stage_id]
        mask = (
            (remaining_memory >= stage.memory_gb)
            & (remaining_storage >= stage.storage_gb)
            & ~already
        )
        if not mask.any():
            return None
        state = self._build_state(
            env,
            demand,
            remaining_memory,
            remaining_storage,
            service_id,
            stage_id,
            replica_idx,
            planned_deployment=deployment,
        )
        action, logprob, value = self.placement_ppo.act(
            state,
            mask,
            deterministic=deterministic,
        )
        if not mask[action]:
            action = int(np.flatnonzero(mask)[0])
        if record:
            self.placement_ppo.buffer.states.append(state)
            self.placement_ppo.buffer.masks.append(mask.astype(bool))
            self.placement_ppo.buffer.actions.append(action)
            self.placement_ppo.buffer.logprobs.append(logprob)
            self.placement_ppo.buffer.values.append(value)
            self.pending_placement_indices.append(len(self.placement_ppo.buffer.actions) - 1)
            self.pending_placement_stage_keys.append((service_id, stage_id))
            assert window_id is not None
            self.placement_window_ids.append(window_id)
        deployment[service_id, stage_id, action] = True
        remaining_memory[action] -= stage.memory_gb
        remaining_storage[action] -= stage.storage_gb
        return int(action)

    def assign_pending_reward(
        self,
        reward: float,
        done: bool,
        *,
        stage_returns: dict[tuple[int, int], float] | None = None,
        count_stage_returns: dict[tuple[int, ...], float] | None = None,
        placement_stage_returns: dict[tuple[int, ...], float] | None = None,
    ) -> None:
        if self.pending_window_id is None:
            return
        if self.pending_window_id != len(self.window_returns):
            raise RuntimeError("slow deployment windows must be completed in collection order")
        self.window_returns.append(float(reward))
        self.window_dones.append(bool(done))
        self.window_episode_ids.append(self.critic_episode_index)
        if done:
            self.critic_episode_index += 1
        stage_returns = {} if stage_returns is None else stage_returns
        count_stage_returns = stage_returns if count_stage_returns is None else count_stage_returns
        placement_stage_returns = stage_returns if placement_stage_returns is None else placement_stage_returns
        self.count_action_stage_keys.extend(self.pending_count_stage_keys)
        if len(self.pending_stage_indices) != len(self.pending_stage_keys):
            raise ValueError("slow stage action indices and stage keys are misaligned")
        if len(self.pending_stage_keys) != len(self.pending_stage_node_ids):
            raise ValueError("slow stage action keys and node ids are misaligned")
        if len(self.pending_placement_indices) != len(self.pending_placement_stage_keys):
            raise ValueError("slow placement action indices and stage keys are misaligned")
        if len(self.pending_count_indices) != len(self.pending_count_node_ids):
            raise ValueError("slow count action indices and node ids are misaligned")
        if len(self.pending_count_stage_keys) != len(self.pending_count_node_ids):
            raise ValueError("slow count stage keys and node ids are misaligned")
        if self.pending_count_node_ids:
            self.count_action_returns.extend(
                float(
                    count_stage_returns.get(
                        (stage_key[0], stage_key[1], int(node_id)),
                        count_stage_returns.get(stage_key, reward),
                    )
                )
                if node_id is not None
                else float(count_stage_returns.get(stage_key, reward))
                for stage_key, node_id in zip(
                    self.pending_count_stage_keys,
                    self.pending_count_node_ids,
                )
            )
        else:
            self.count_action_returns.extend(
                float(count_stage_returns.get(stage_key, reward))
                for stage_key in self.pending_count_stage_keys
            )
        self.stage_action_stage_keys.extend(self.pending_stage_keys)
        self.stage_action_returns.extend(
            float(
                count_stage_returns.get(
                    (stage_key[0], stage_key[1], int(node_id)),
                    count_stage_returns.get(stage_key, reward),
                )
            )
            for stage_key, node_id in zip(
                self.pending_stage_keys,
                self.pending_stage_node_ids,
            )
        )
        self.placement_action_stage_keys.extend(self.pending_placement_stage_keys)
        for action_index, stage_key in zip(
            self.pending_placement_indices,
            self.pending_placement_stage_keys,
        ):
            node_id = int(self.placement_ppo.buffer.actions[action_index])
            node_key = (stage_key[0], stage_key[1], node_id)
            self.placement_action_returns.append(
                float(
                    placement_stage_returns.get(
                        node_key,
                        placement_stage_returns.get(stage_key, reward),
                    )
                )
            )
        self.pending_window_id = None
        self.pending_count_indices.clear()
        self.pending_placement_indices.clear()
        self.pending_count_stage_keys.clear()
        self.pending_count_node_ids.clear()
        self.pending_stage_indices.clear()
        self.pending_stage_keys.clear()
        self.pending_stage_node_ids.clear()
        self.pending_placement_stage_keys.clear()
        self.pending_budget_fraction = 0.0
        self.pending_budget_feasible_capacity = 0
        self.pending_budget_replica_slot_upper_bound = 0
        self.pending_budget_requested_replicas = 0
        self.pending_budget_available_memory_gb = 0.0
        self.pending_budget_available_storage_gb = 0.0
        self.pending_budget_target_memory_gb = 0.0
        self.pending_budget_target_storage_gb = 0.0
        self.pending_budget_used_memory_gb = 0.0
        self.pending_budget_used_storage_gb = 0.0

    def update(self, *, progress_label: str = "", progress_interval_seconds: float = 0.0) -> dict[str, float]:
        if self.pending_window_id is not None:
            raise ValueError("slow deployment buffer contains a window without a return")
        if not self.window_returns:
            return self.empty_update_metrics()
        if len(self.window_states) != len(self.window_returns):
            raise ValueError("slow deployment window states and returns are misaligned")
        if len(self.window_dones) != len(self.window_returns):
            raise ValueError("slow deployment window dones and returns are misaligned")
        if len(self.window_episode_ids) != len(self.window_returns):
            raise ValueError("slow deployment window episode ids and returns are misaligned")

        immediate_returns = np.asarray(self.window_returns, dtype=np.float32)
        trajectory_returns = _discounted_window_returns(
            immediate_returns,
            np.asarray(self.window_dones, dtype=bool),
            self.window_gamma,
        )
        # Optimize the cost of this rebuilt deployment window. This is an
        # explicit window-local objective, not long-horizon load-state credit.
        if self.team_window_credit:
            trajectory_returns = immediate_returns.copy()
        old_values = np.asarray(self.window_old_values, dtype=np.float32)
        window_advantages = trajectory_returns - old_values
        window_advantage_mean = float(window_advantages.mean())
        window_advantage_std = float(window_advantages.std())

        count_ids = np.asarray(self.count_window_ids, dtype=np.int64)
        stage_ids = np.asarray(self.stage_window_ids, dtype=np.int64)
        placement_ids = np.asarray(self.placement_window_ids, dtype=np.int64)
        if len(self.count_action_returns) != len(self.count_ppo.buffer.actions):
            raise ValueError("slow count action returns are misaligned")
        if len(self.count_action_stage_keys) != len(self.count_ppo.buffer.actions):
            raise ValueError("slow count action stage keys are misaligned")
        stage_buffer_actions = (
            self.stage_ppo.buffer.actions if self.stage_ppo is not None else []
        )
        if len(self.stage_action_returns) != len(stage_buffer_actions):
            raise ValueError("slow stage action returns are misaligned")
        if len(self.stage_action_stage_keys) != len(stage_buffer_actions):
            raise ValueError("slow stage action keys are misaligned")
        if len(self.placement_action_returns) != len(self.placement_ppo.buffer.actions):
            raise ValueError("slow placement action returns are misaligned")
        if len(self.placement_action_stage_keys) != len(self.placement_ppo.buffer.actions):
            raise ValueError("slow placement action stage keys are misaligned")
        count_returns = np.asarray(self.count_action_returns, dtype=np.float32)
        stage_returns = np.asarray(self.stage_action_returns, dtype=np.float32)
        placement_returns = np.asarray(self.placement_action_returns, dtype=np.float32)
        if self.team_window_credit:
            count_returns = immediate_returns[count_ids]
            stage_returns = immediate_returns[stage_ids]
            placement_returns = immediate_returns[placement_ids]
        # Stage is one categorical decision over all service stages.  Center
        # its advantages globally so the actor can learn that choosing stage A
        # was better than choosing stage B.  Per-selected-stage centering would
        # erase precisely that cross-stage signal.
        stage_group_ids = np.zeros(len(self.stage_action_stage_keys), dtype=np.int64)
        placement_group_ids = np.asarray(
            [
                service_id * self.max_service_stages + stage_id
                for service_id, stage_id in self.placement_action_stage_keys
            ],
            dtype=np.int64,
        )
        placement_action_weights = self._equal_window_action_weights(placement_ids)
        placement_attribution = self._placement_credit_attribution(
            placement_returns,
            placement_group_ids,
            placement_action_weights,
        )
        global_advantage_reliability = self.global_advantage_reliability()
        effective_count_global_coef = (
            self.count_global_advantage_coef * global_advantage_reliability
        )
        effective_placement_global_coef = (
            self.placement_global_advantage_coef * global_advantage_reliability
        )
        if self.team_window_credit:
            effective_count_global_coef = effective_placement_global_coef = 0.0
            placement_action_weights = np.ones(len(placement_ids), dtype=np.float32)
            placement_group_ids = np.zeros(len(placement_ids), dtype=np.int64)
        count_advantage_groups = (
            np.zeros(len(self.count_action_stage_keys), dtype=np.int64)
            if self.allocation_mode in {
                "global-incremental",
                "budget-incremental",
                "budget-continuous-v2",
                "stage-budget-v3",
                "stage-budget-v4",
                "stage-budget-v5",
            "stage-budget-v6",
            }
            else np.asarray(
                [
                    service_id * self.max_service_stages + stage_id
                    for service_id, stage_id in self.count_action_stage_keys
                ],
                dtype=np.int64,
            )
        )
        count_metrics = self.count_ppo.update_from_returns(
            count_returns,
            **({"critic_window_ids": count_ids} if self.learning_repair != "none" else {}),
            **({"critic_sample_weights": self._equal_window_action_weights(count_ids)} if self.deployment_aware else {}),
            sample_weights=(np.ones(len(count_ids), dtype=np.float32) if self.team_window_credit
                            else self._equal_window_action_weights(count_ids)),
            advantage_group_ids=count_advantage_groups,
            actor_use_value_baseline=self.team_window_credit,
            auxiliary_advantages=window_advantages[count_ids],
            auxiliary_advantage_coef=effective_count_global_coef,
            progress_label=f"{progress_label} count",
            progress_interval_seconds=progress_interval_seconds,
        )
        if stage_returns.size:
            if self.stage_ppo is None:
                raise RuntimeError("Slow Stage returns exist without a Stage actor")
            stage_metrics = self.stage_ppo.update_from_returns(
                stage_returns,
                **({"critic_window_ids": stage_ids} if self.learning_repair != "none" else {}),
                **({"critic_sample_weights": self._equal_window_action_weights(stage_ids)} if self.deployment_aware else {}),
                sample_weights=(np.ones(len(stage_ids), dtype=np.float32) if self.team_window_credit
                                else self._equal_window_action_weights(stage_ids)),
                advantage_group_ids=stage_group_ids,
                actor_use_value_baseline=self.team_window_credit,
                auxiliary_advantages=window_advantages[stage_ids],
                auxiliary_advantage_coef=effective_count_global_coef,
                progress_label=f"{progress_label} stage",
                progress_interval_seconds=progress_interval_seconds,
            )
        else:
            stage_metrics = {
                "loss": 0.0,
                "policy_loss": 0.0,
                "value_loss": 0.0,
                "entropy": 0.0,
                "approx_kl": 0.0,
                "advantage_mean": 0.0,
                "advantage_std": 0.0,
                "epochs_completed": 0.0,
                "kl_early_stop": 0.0,
                "optimizer_steps": 0.0,
            }
        placement_entropy_coef = self.placement_entropy_coefficient()
        self.placement_ppo.entropy_coef = placement_entropy_coef
        placement_metrics = self.placement_ppo.update_from_returns(
            placement_returns,
            **({"critic_window_ids": placement_ids} if self.learning_repair != "none" else {}),
            **({"critic_sample_weights": self._equal_window_action_weights(placement_ids)} if self.deployment_aware else {}),
            sample_weights=placement_action_weights,
            advantage_group_ids=placement_group_ids,
            actor_use_value_baseline=self.team_window_credit,
            auxiliary_advantages=window_advantages[placement_ids],
            auxiliary_advantage_coef=effective_placement_global_coef,
            auxiliary_attribution=placement_attribution,
            auxiliary_attribution_coef=self.placement_global_attribution_coef,
            progress_label=f"{progress_label} placement",
            progress_interval_seconds=progress_interval_seconds,
        )
        if self.deployment_aware:
            self.last_update_diagnostics = {
                f"{head}_{key}": metrics.get(key, 0.0)
                for head, metrics in (("count", count_metrics), ("stage", stage_metrics), ("placement", placement_metrics))
                for key in ("optimizer_steps", "samples_seen_fraction", "approx_kl", "normalized_entropy",
                            "kl_backtracks", "accepted_step_lr", "critic_extra_optimizer_steps",
                            "value_return_std", "explained_variance", "post_explained_variance")
            }
            if self.learning_repair != "none":
                self.last_update_diagnostics.update({
                    f"{head}_{key}": metrics.get(key, 0.)
                    for head, metrics in (("count", count_metrics), ("stage", stage_metrics), ("placement", placement_metrics))
                    for key in ("critic_prequential_ev", "critic_prequential_mse", "critic_post_mse",
                                "baseline_coef_used", "baseline_coef_next", "critic_replay_windows",
                                "critic_replay_samples", "critic_optimizer_steps", "prefix_trace_lambda",
                                "prefix_advantage_std", "mc_advantage_std", "actor_gradient_norm",
                                "entropy_gradient_norm", "baseline_return_variance", "baseline_residual_variance",
                                "baseline_residual_variance_ratio", "baseline_window_residual_variance", "diagnostic_windows",
                                "score_gradient_mc_variance", "score_gradient_baseline_variance", "score_gradient_variance_ratio",
                                "score_gradient_mean_cosine", "window_log_ratio_mean", "window_log_ratio_abs_max",
                                "window_kl_proxy_mean", "window_kl_proxy_max", "actor_update_time_s",
                                "critic_update_time_s", "critic_replay_max_age")
                })
        critic_metrics = self._update_window_critic(trajectory_returns)
        self.last_window_critic_holdout_ev = float(
            critic_metrics["holdout_explained_variance"]
        )
        placement_entropy_next_coef = self._adapt_placement_entropy_coefficient(
            placement_metrics.get("entropy", 0.0)
        )
        window_count = len(self.window_returns)
        self.count_window_ids.clear()
        self.stage_window_ids.clear()
        self.placement_window_ids.clear()
        self.count_action_returns.clear()
        self.stage_action_returns.clear()
        self.placement_action_returns.clear()
        self.count_action_stage_keys.clear()
        self.stage_action_stage_keys.clear()
        self.placement_action_stage_keys.clear()
        self.window_states.clear()
        self.window_old_values.clear()
        self.window_returns.clear()
        self.window_dones.clear()
        self.window_episode_ids.clear()
        return {
            "loss": count_metrics["loss"] + stage_metrics["loss"] + placement_metrics["loss"] + self.value_coef * critic_metrics["value_loss"],
            "policy_loss": count_metrics["policy_loss"] + stage_metrics["policy_loss"] + placement_metrics["policy_loss"],
            "value_loss": count_metrics["value_loss"] + stage_metrics["value_loss"] + placement_metrics["value_loss"],
            "entropy": count_metrics["entropy"] + stage_metrics["entropy"] + placement_metrics["entropy"],
            "approx_kl": max(
                count_metrics.get("approx_kl", 0.0),
                stage_metrics.get("approx_kl", 0.0),
                placement_metrics.get("approx_kl", 0.0),
            ),
            "window_count": float(window_count),
            "team_window_credit": float(self.team_window_credit),
            "stage_team_credit_fraction": float(self.team_window_credit and len(stage_ids) > 0),
            "window_return_mean": float(immediate_returns.mean()),
            "window_return_std": float(immediate_returns.std()),
            "trajectory_return_mean": float(trajectory_returns.mean()),
            "trajectory_return_std": float(trajectory_returns.std()),
            "count_return_mean": float(count_returns.mean()) if count_returns.size else 0.0,
            "count_return_std": float(count_returns.std()) if count_returns.size else 0.0,
            "stage_return_mean": float(stage_returns.mean()) if stage_returns.size else 0.0,
            "stage_return_std": float(stage_returns.std()) if stage_returns.size else 0.0,
            "placement_return_mean": float(placement_returns.mean()) if placement_returns.size else 0.0,
            "placement_return_std": float(placement_returns.std()) if placement_returns.size else 0.0,
            "advantage_mean": 0.5
            * (count_metrics.get("advantage_mean", 0.0) + placement_metrics.get("advantage_mean", 0.0)),
            "advantage_std": 0.5
            * (count_metrics.get("advantage_std", 0.0) + placement_metrics.get("advantage_std", 0.0)),
            "window_advantage_mean": window_advantage_mean,
            "window_advantage_std": window_advantage_std,
            "critic_explained_variance": 0.5
            * (
                count_metrics.get("explained_variance", 0.0)
                + placement_metrics.get("explained_variance", 0.0)
            ),
            "window_critic_explained_variance": critic_metrics["explained_variance"],
            "window_critic_active": float(not self.prefix_credit),
            "window_critic_value_loss": critic_metrics["value_loss"],
            "window_critic_raw_value_mse": critic_metrics["raw_value_mse"],
            "window_critic_train_explained_variance": critic_metrics[
                "train_explained_variance"
            ],
            "window_critic_holdout_explained_variance": critic_metrics[
                "holdout_explained_variance"
            ],
            "window_critic_replay_size": critic_metrics["replay_size"],
            "window_critic_train_size": critic_metrics["train_size"],
            "window_critic_holdout_size": critic_metrics["holdout_size"],
            "window_critic_train_episode_count": critic_metrics["train_episode_count"],
            "window_critic_holdout_episode_count": critic_metrics["holdout_episode_count"],
            "window_critic_return_mean": self.critic_return_mean,
            "window_critic_return_std": self.critic_return_std,
            "global_advantage_reliability": global_advantage_reliability,
            "count_loss": count_metrics["loss"],
            "count_advantage_mean": count_metrics.get("advantage_mean", 0.0),
            "count_advantage_std": count_metrics.get("advantage_std", 0.0),
            "count_global_advantage_mean": count_metrics.get("auxiliary_advantage_mean", 0.0),
            "count_global_advantage_std": count_metrics.get("auxiliary_advantage_std", 0.0),
            "count_global_advantage_coef": effective_count_global_coef,
            "count_global_advantage_configured_coef": self.count_global_advantage_coef,
            "count_combined_advantage_std": count_metrics.get("combined_advantage_std", 0.0),
            "count_policy_loss": count_metrics["policy_loss"],
            "count_value_loss": count_metrics["value_loss"],
            "count_entropy": count_metrics["entropy"],
            "count_approx_kl": count_metrics.get("approx_kl", 0.0),
            "count_epochs_completed": count_metrics.get("epochs_completed", 0.0),
            "count_kl_early_stop": count_metrics.get("kl_early_stop", 0.0),
            "count_optimizer_steps": count_metrics.get("optimizer_steps", 0.0),
            "count_explained_variance": count_metrics.get("explained_variance", 0.0),
            "count_post_explained_variance": count_metrics.get("post_explained_variance", 0.0),
            "stage_loss": stage_metrics["loss"],
            "stage_policy_loss": stage_metrics["policy_loss"],
            "stage_value_loss": stage_metrics["value_loss"],
            "stage_entropy": stage_metrics["entropy"],
            "stage_approx_kl": stage_metrics.get("approx_kl", 0.0),
            "stage_epochs_completed": stage_metrics.get("epochs_completed", 0.0),
            "stage_kl_early_stop": stage_metrics.get("kl_early_stop", 0.0),
            "stage_optimizer_steps": stage_metrics.get("optimizer_steps", 0.0),
            "stage_advantage_mean": stage_metrics.get("advantage_mean", 0.0),
            "stage_advantage_std": stage_metrics.get("advantage_std", 0.0),
            "placement_loss": placement_metrics["loss"],
            "placement_advantage_mean": placement_metrics.get("advantage_mean", 0.0),
            "placement_advantage_std": placement_metrics.get("advantage_std", 0.0),
            "placement_global_advantage_mean": placement_metrics.get("auxiliary_advantage_mean", 0.0),
            "placement_global_advantage_std": placement_metrics.get("auxiliary_advantage_std", 0.0),
            "placement_global_advantage_coef": effective_placement_global_coef,
            "placement_global_advantage_configured_coef": self.placement_global_advantage_coef,
            "placement_global_attribution_coef": self.placement_global_attribution_coef,
            "placement_global_attribution_mean_abs": placement_metrics.get(
                "auxiliary_attribution_mean_abs", 0.0
            ),
            "placement_combined_advantage_std": placement_metrics.get("combined_advantage_std", 0.0),
            "placement_policy_loss": placement_metrics["policy_loss"],
            "placement_value_loss": placement_metrics["value_loss"],
            "placement_entropy": placement_metrics["entropy"],
            "placement_entropy_coef": placement_entropy_coef,
            "placement_entropy_next_coef": placement_entropy_next_coef,
            "placement_entropy_schedule_coef": self.placement_entropy_schedule_coefficient(),
            "placement_entropy_target": (
                float(self.placement_entropy_target) if self.placement_entropy_target is not None else 0.0
            ),
            "placement_entropy_shortfall": max(
                float(self.placement_entropy_target or 0.0)
                - float(placement_metrics.get("entropy", 0.0)),
                0.0,
            ),
            "placement_entropy_saturated": float(
                np.isclose(placement_entropy_next_coef, self.placement_entropy_max_coef)
            ),
            "placement_updates_completed": float(self.placement_updates_completed),
            "placement_approx_kl": placement_metrics.get("approx_kl", 0.0),
            "placement_epochs_completed": placement_metrics.get("epochs_completed", 0.0),
            "placement_kl_early_stop": placement_metrics.get("kl_early_stop", 0.0),
            "placement_optimizer_steps": placement_metrics.get("optimizer_steps", 0.0),
            "placement_explained_variance": placement_metrics.get("explained_variance", 0.0),
            "placement_post_explained_variance": placement_metrics.get("post_explained_variance", 0.0),
        }

    def empty_update_metrics(self) -> dict[str, float]:
        return {
            "loss": 0.0,
            "policy_loss": 0.0,
            "value_loss": 0.0,
            "entropy": 0.0,
            "approx_kl": 0.0,
            "window_count": 0.0,
            "window_return_mean": 0.0,
            "window_return_std": 0.0,
            "trajectory_return_mean": 0.0,
            "trajectory_return_std": 0.0,
            "count_return_mean": 0.0,
            "count_return_std": 0.0,
            "stage_return_mean": 0.0,
            "stage_return_std": 0.0,
            "placement_return_mean": 0.0,
            "placement_return_std": 0.0,
            "advantage_mean": 0.0,
            "advantage_std": 0.0,
            "window_advantage_mean": 0.0,
            "window_advantage_std": 0.0,
            "critic_explained_variance": 0.0,
            "window_critic_explained_variance": 0.0,
            "window_critic_value_loss": 0.0,
            "window_critic_raw_value_mse": 0.0,
            "window_critic_train_explained_variance": 0.0,
            "window_critic_holdout_explained_variance": self.last_window_critic_holdout_ev,
            "window_critic_replay_size": float(len(self.critic_replay_returns)),
            "window_critic_train_size": 0.0,
            "window_critic_holdout_size": 0.0,
            "window_critic_train_episode_count": 0.0,
            "window_critic_holdout_episode_count": 0.0,
            "window_critic_return_mean": self.critic_return_mean,
            "window_critic_return_std": self.critic_return_std,
            "global_advantage_reliability": self.global_advantage_reliability(),
            "count_loss": 0.0,
            "count_advantage_mean": 0.0,
            "count_advantage_std": 0.0,
            "count_global_advantage_mean": 0.0,
            "count_global_advantage_std": 0.0,
            "count_global_advantage_coef": 0.0,
            "count_global_advantage_configured_coef": self.count_global_advantage_coef,
            "count_combined_advantage_std": 0.0,
            "count_policy_loss": 0.0,
            "count_value_loss": 0.0,
            "count_entropy": 0.0,
            "count_approx_kl": 0.0,
            "count_epochs_completed": 0.0,
            "count_kl_early_stop": 0.0,
            "count_optimizer_steps": 0.0,
            "count_explained_variance": 0.0,
            "count_post_explained_variance": 0.0,
            "stage_loss": 0.0,
            "stage_policy_loss": 0.0,
            "stage_value_loss": 0.0,
            "stage_entropy": 0.0,
            "stage_approx_kl": 0.0,
            "stage_epochs_completed": 0.0,
            "stage_kl_early_stop": 0.0,
            "stage_optimizer_steps": 0.0,
            "stage_advantage_mean": 0.0,
            "stage_advantage_std": 0.0,
            "placement_loss": 0.0,
            "placement_advantage_mean": 0.0,
            "placement_advantage_std": 0.0,
            "placement_global_advantage_mean": 0.0,
            "placement_global_advantage_std": 0.0,
            "placement_global_advantage_coef": 0.0,
            "placement_global_advantage_configured_coef": self.placement_global_advantage_coef,
            "placement_global_attribution_coef": self.placement_global_attribution_coef,
            "placement_global_attribution_mean_abs": 0.0,
            "placement_combined_advantage_std": 0.0,
            "placement_policy_loss": 0.0,
            "placement_value_loss": 0.0,
            "placement_entropy": 0.0,
            "placement_entropy_coef": self.placement_entropy_coefficient(),
            "placement_entropy_next_coef": self.placement_entropy_coefficient(),
            "placement_entropy_schedule_coef": self.placement_entropy_schedule_coefficient(),
            "placement_entropy_target": (
                float(self.placement_entropy_target) if self.placement_entropy_target is not None else 0.0
            ),
            "placement_entropy_shortfall": 0.0,
            "placement_entropy_saturated": float(
                np.isclose(self.placement_entropy_coefficient(), self.placement_entropy_max_coef)
            ),
            "placement_updates_completed": float(self.placement_updates_completed),
            "placement_approx_kl": 0.0,
            "placement_epochs_completed": 0.0,
            "placement_kl_early_stop": 0.0,
            "placement_optimizer_steps": 0.0,
            "placement_explained_variance": 0.0,
            "placement_post_explained_variance": 0.0,
        }

    def _equal_window_action_weights(self, window_ids: np.ndarray) -> np.ndarray:
        if len(window_ids) == 0:
            return np.asarray([], dtype=np.float32)
        counts = np.bincount(window_ids, minlength=len(self.window_returns)).astype(np.float32)
        return np.asarray([1.0 / max(float(counts[idx]), 1.0) for idx in window_ids], dtype=np.float32)

    @staticmethod
    def _placement_credit_attribution(
        local_returns: np.ndarray,
        group_ids: np.ndarray,
        sample_weights: np.ndarray,
    ) -> np.ndarray:
        """Score node choices relative to comparable service-stage actions.

        The Slow critic emits one residual per ten-minute window.  Without this
        attribution every node chosen in that window receives exactly the same
        global credit.  The standardized local return preserves the mean window
        signal while shifting bonus toward good nodes and penalty toward bad
        nodes.
        """

        values = np.asarray(local_returns, dtype=np.float32)
        groups = np.asarray(group_ids)
        weights = np.asarray(sample_weights, dtype=np.float32)
        if values.shape != groups.shape or values.shape != weights.shape:
            raise ValueError("placement credit arrays must have matching shapes")
        attribution = np.zeros_like(values)
        for group_id in np.unique(groups):
            indices = np.flatnonzero(groups == group_id)
            group_weights = weights[indices]
            group_values = values[indices]
            mean = float(np.average(group_values, weights=group_weights))
            variance = float(
                np.average(np.square(group_values - mean), weights=group_weights)
            )
            std = float(np.sqrt(variance))
            if std > 1e-8:
                attribution[indices] = (group_values - mean) / (std + 1e-8)
        return np.clip(attribution, -2.0, 2.0)

    def _update_window_critic(self, returns: np.ndarray) -> dict[str, float]:
        if self.prefix_credit:
            # Conditional prefix critics are the actual Actor baselines. Do
            # not spend updates on the legacy critic whose credit is disabled.
            return dict.fromkeys(("value_loss", "raw_value_mse", "explained_variance",
                "train_explained_variance", "holdout_explained_variance", "replay_size",
                "train_size", "holdout_size", "train_episode_count", "holdout_episode_count"), 0.)
        current_states = np.stack(self.window_states).astype(np.float32, copy=False)
        current_returns = np.asarray(returns, dtype=np.float32)
        self.critic_update_index += 1
        self.critic_replay_states.extend(state.copy() for state in current_states)
        self.critic_replay_returns.extend(float(value) for value in current_returns)
        self.critic_replay_update_ids.extend(
            [self.critic_update_index] * len(current_returns)
        )
        self.critic_replay_episode_ids.extend(self.window_episode_ids)
        while len(self.critic_replay_returns) > self.critic_replay_windows:
            oldest_episode = self.critic_replay_episode_ids[0]
            drop_count = 0
            while (
                drop_count < len(self.critic_replay_episode_ids)
                and self.critic_replay_episode_ids[drop_count] == oldest_episode
            ):
                drop_count += 1
            del self.critic_replay_states[:drop_count]
            del self.critic_replay_returns[:drop_count]
            del self.critic_replay_update_ids[:drop_count]
            del self.critic_replay_episode_ids[:drop_count]

        replay_states = np.stack(self.critic_replay_states).astype(np.float32, copy=False)
        replay_returns = np.asarray(self.critic_replay_returns, dtype=np.float32)
        replay_update_ids = np.asarray(self.critic_replay_update_ids, dtype=np.int64)
        replay_episode_ids = np.asarray(self.critic_replay_episode_ids, dtype=np.int64)
        unique_episodes = np.unique(replay_episode_ids)
        holdout_episode_count = min(self.critic_holdout_episodes, len(unique_episodes))
        holdout_episode_ids = unique_episodes[-holdout_episode_count:]
        holdout_mask = np.isin(replay_episode_ids, holdout_episode_ids)
        train_indices = np.flatnonzero(~holdout_mask)
        holdout_indices = np.flatnonzero(holdout_mask)

        value_loss = 0.0
        if len(train_indices) > 0:
            train_weights = np.power(
                float(self.critic_replay_decay),
                (self.critic_update_index - replay_update_ids[train_indices]).astype(
                    np.float64
                ),
            ).astype(np.float32)
            train_weights /= max(float(train_weights.mean()), 1e-8)
            weighted_mean = float(
                np.average(replay_returns[train_indices], weights=train_weights)
            )
            weighted_variance = float(
                np.average(
                    np.square(replay_returns[train_indices] - weighted_mean),
                    weights=train_weights,
                )
            )
            self.critic_return_mean = weighted_mean
            self.critic_return_std = max(float(np.sqrt(weighted_variance)), 1e-3)

            minibatch_size = min(32, len(train_indices))
            for _ in range(max(self.critic_k_epochs, 1)):
                order = np.random.permutation(train_indices)
                for start in range(0, len(train_indices), minibatch_size):
                    batch_indices = order[start : start + minibatch_size]
                    states = torch.as_tensor(
                        replay_states[batch_indices],
                        dtype=torch.float32,
                        device=self.device,
                    )
                    normalized_targets = torch.as_tensor(
                        (replay_returns[batch_indices] - self.critic_return_mean)
                        / self.critic_return_std,
                        dtype=torch.float32,
                        device=self.device,
                    )
                    weights = torch.as_tensor(
                        train_weights[batch_indices],
                        dtype=torch.float32,
                        device=self.device,
                    )
                    predictions = self.window_critic(states)
                    losses = nn.functional.smooth_l1_loss(
                        predictions,
                        normalized_targets,
                        reduction="none",
                    )
                    loss = (losses * weights).sum() / weights.sum().clamp_min(1e-8)
                    self.critic_optimizer.zero_grad()
                    loss.backward()
                    nn.utils.clip_grad_norm_(
                        self.window_critic.parameters(),
                        self.critic_gradient_clip,
                    )
                    self.critic_optimizer.step()
                    value_loss = float(loss.item())

        def raw_predictions(states_np: np.ndarray) -> np.ndarray:
            if len(states_np) == 0:
                return np.asarray([], dtype=np.float32)
            with torch.no_grad():
                normalized = self.window_critic(
                    torch.as_tensor(states_np, dtype=torch.float32, device=self.device)
                ).detach().cpu().numpy()
            return normalized * self.critic_return_std + self.critic_return_mean

        def explained_variance(targets: np.ndarray, predictions: np.ndarray) -> float:
            if len(targets) == 0 or len(predictions) == 0:
                return 0.0
            target_variance = float(np.var(targets))
            if target_variance <= 1e-8:
                return 0.0
            return 1.0 - float(np.var(targets - predictions)) / target_variance

        current_predictions = raw_predictions(current_states)
        train_predictions = raw_predictions(replay_states[train_indices])
        holdout_predictions = raw_predictions(replay_states[holdout_indices])
        return {
            "value_loss": value_loss,
            "raw_value_mse": float(
                np.mean(np.square(current_returns - current_predictions))
            ),
            "explained_variance": explained_variance(
                current_returns, current_predictions
            ),
            "train_explained_variance": explained_variance(
                replay_returns[train_indices], train_predictions
            ),
            "holdout_explained_variance": explained_variance(
                replay_returns[holdout_indices], holdout_predictions
            ),
            "replay_size": float(len(replay_returns)),
            "train_size": float(len(train_indices)),
            "holdout_size": float(len(holdout_indices)),
            "train_episode_count": float(len(np.unique(replay_episode_ids[train_indices]))),
            "holdout_episode_count": float(len(np.unique(replay_episode_ids[holdout_indices]))),
        }

    def _build_state(
        self,
        env: EdgeComputingEnv,
        demand: np.ndarray,
        remaining_memory: np.ndarray,
        remaining_storage: np.ndarray,
        service_id: int,
        stage_id: int,
        replica_idx: int,
        planned_deployment: np.ndarray | None = None,
    ) -> np.ndarray:
        assert env.scenario is not None
        nodes = env.scenario.nodes
        max_mem = max(n.memory_gb for n in nodes)
        max_storage = max(n.storage_gb for n in nodes)
        max_compute = max(n.compute_gcycles_per_s for n in nodes)
        total_node_demand = demand.sum(axis=1)
        max_node_demand = max(float(total_node_demand.max()), 1e-9)
        affinity_nodes = np.zeros(self.num_nodes, dtype=np.float32)
        placement = planned_deployment if planned_deployment is not None else env.deployment
        extra_global, extra_nodes = (self._deployment_features(env, demand, placement, service_id, stage_id)
                                     if self.deployment_aware else ([], None))
        if placement is not None and stage_id > 0:
            affinity_nodes = placement[service_id, stage_id - 1].astype(np.float32)
        node_features = []
        node_nic_features = nic_features(env) if self.cost_context else None
        for node in nodes:
            node_features.extend(
                [
                    remaining_memory[node.node_id] / max_mem,
                    remaining_storage[node.node_id] / max_storage,
                    node.compute_gcycles_per_s / max_compute,
                    env.node_compute_load[node.node_id],
                    total_node_demand[node.node_id] / max_node_demand,
                    affinity_nodes[node.node_id],
                ]
            )
            node_features.extend(demand[node.node_id].tolist())
            if self.cost_context:
                node_features.extend(node_nic_features[node.node_id].tolist())
            if self.deployment_aware:
                node_features.extend(extra_nodes[node.node_id].tolist())
        scalars = [
            service_id / max(self.num_service_types - 1, 1),
            stage_id / max(self.max_service_stages - 1, 1),
            replica_idx / max(self.replicas_per_stage - 1, 1),
            env.current_time_minute / max(env.config.episode_minutes, 1),
            len(env.scenario.services[service_id].stages) / self.max_service_stages,
            np.log1p(env._arrival_rate_per_minute()) / np.log1p(20_000.0),
            np.log1p(env._arrival_rate_per_minute() * env.config.deployment_interval_minutes)
            / np.log1p(5_000_000.0),
            1.0,
        ]
        return np.asarray(
            scalars + self._feedback_features() + self._service_cost_features(env) + list(extra_global)
            + node_features + self._build_edge_features(env),
            dtype=np.float32,
        )

    def _build_window_state(
        self,
        env: EdgeComputingEnv,
        demand: np.ndarray,
        remaining_memory: np.ndarray,
        remaining_storage: np.ndarray,
        planned_deployment: np.ndarray | None = None,
    ) -> np.ndarray:
        assert env.scenario is not None
        nodes = env.scenario.nodes
        memory_capacity = env.service_memory_capacities()
        storage_capacity = env.service_storage_capacities()
        max_compute = max(n.compute_gcycles_per_s for n in nodes)
        total_node_demand = demand.sum(axis=1)
        max_node_demand = max(float(total_node_demand.max()), 1e-9)
        active_deployment = (
            planned_deployment if planned_deployment is not None else env.deployment
        )
        extra_global, extra_nodes = (self._deployment_features(env, demand, active_deployment)
                                     if self.deployment_aware else ([], None))
        deployed_nodes = (
            np.any(active_deployment, axis=(0, 1)).astype(np.float32)
            if active_deployment is not None
            else np.zeros(self.num_nodes, dtype=np.float32)
        )
        node_features: list[float] = []
        node_nic_features = nic_features(env) if self.cost_context else None
        for node in nodes:
            node_features.extend(
                [
                    remaining_memory[node.node_id] / max(memory_capacity[node.node_id], 1e-9),
                    remaining_storage[node.node_id] / max(storage_capacity[node.node_id], 1e-9),
                    node.compute_gcycles_per_s / max_compute,
                    env.node_compute_load[node.node_id],
                    total_node_demand[node.node_id] / max_node_demand,
                    deployed_nodes[node.node_id],
                ]
            )
            node_features.extend(demand[node.node_id].tolist())
            if self.cost_context:
                node_features.extend(node_nic_features[node.node_id].tolist())
            if self.deployment_aware:
                node_features.extend(extra_nodes[node.node_id].tolist())
        current_replica_rate = 0.0
        if active_deployment is not None:
            current_replica_rate = float(active_deployment.mean())
        finite_link_load = env.link_load[np.isfinite(env.link_load)]
        mean_link_load = float(np.mean(finite_link_load)) if finite_link_load.size else 0.0
        max_link_load = float(np.max(finite_link_load)) if finite_link_load.size else 0.0
        scalars = [
            env.current_time_minute / max(env.config.episode_minutes, 1),
            np.log1p(env._arrival_rate_per_minute()) / np.log1p(20_000.0),
            np.log1p(env._arrival_rate_per_minute() * env.config.deployment_interval_minutes)
            / np.log1p(5_000_000.0),
            current_replica_rate,
            float(np.mean(env.node_compute_load)),
            float(np.max(env.node_compute_load)),
            mean_link_load,
            max_link_load,
        ]
        return np.asarray(
            scalars + self._feedback_features() + self._service_cost_features(env) + list(extra_global)
            + node_features + self._build_edge_features(env),
            dtype=np.float32,
        )

    def _build_incremental_state(
        self,
        env: EdgeComputingEnv,
        demand: np.ndarray,
        remaining_memory: np.ndarray,
        remaining_storage: np.ndarray,
        deployment: np.ndarray,
    ) -> np.ndarray:
        """Insert per-stage marginal-resource features into the graph state."""

        assert env.scenario is not None
        base = self._build_window_state(
            env,
            demand,
            remaining_memory,
            remaining_storage,
            planned_deployment=deployment,
        )
        node_end = self._global_dim() + self.num_nodes * self._node_dim()
        global_and_nodes = base[:node_end]
        edge_features = base[node_end:]
        stage_features: list[float] = []
        maximum_stage_demand = max(float(demand.sum(axis=0).max()), 1e-9)
        memory_capacity = np.maximum(env.service_memory_capacities(), 1e-9)
        storage_capacity = np.maximum(env.service_storage_capacities(), 1e-9)
        cost_features = (self._context(env, demand).stage_costs(deployment, remaining_memory, remaining_storage)
                         if self.deployment_aware else None)
        for service_id in range(self.num_service_types):
            service = env.scenario.services[service_id]
            for stage_id in range(self.max_service_stages):
                valid = stage_id < len(service.stages)
                if not valid:
                    stage_features.extend([0.0] * slow_stage_feature_dim(self.cost_context, self.deployment_aware, self.chain_context, self.tail_reallocation))
                    continue
                stage = service.stages[stage_id]
                placed = deployment[service_id, stage_id]
                feasible = (
                    (remaining_memory >= stage.memory_gb)
                    & (remaining_storage >= stage.storage_gb)
                    & ~placed
                )
                previous_overlap = (
                    float(np.mean(placed & deployment[service_id, stage_id - 1]))
                    if stage_id > 0
                    else 0.0
                )
                next_overlap = (
                    float(np.mean(placed & deployment[service_id, stage_id + 1]))
                    if stage_id + 1 < len(service.stages)
                    else 0.0
                )
                feasible_remaining = np.minimum(
                    remaining_memory / memory_capacity,
                    remaining_storage / storage_capacity,
                )
                stage_features.extend(
                    [
                        1.0,
                        float(demand[:, service_id].sum()) / maximum_stage_demand,
                        (float(np.log1p(1000.0 * stage.compute_gcycles_mean / max(np.mean([n.compute_gcycles_per_s for n in env.scenario.nodes]), 1e-9)))
                         if self.cost_context else float(stage.compute_gcycles_mean) / 8.0),
                        float(np.mean(stage.memory_gb / memory_capacity)),
                        float(np.mean(stage.storage_gb / storage_capacity)),
                        float(placed.sum()) / max(float(self.replicas_per_stage), 1.0),
                        float(np.mean(feasible)),
                        float(np.mean(feasible_remaining[feasible])) if feasible.any() else 0.0,
                        previous_overlap,
                        next_overlap,
                    ]
                )
                if self.cost_context:
                    incoming = service.input_mb_mean if stage_id == 0 else service.stages[stage_id - 1].output_mb_mean
                    stage_features.extend([float(np.log1p(incoming)), float(np.log1p(stage.output_mb_mean))])
                if self.deployment_aware:
                    stage_features.extend(cost_features[service_id * self.max_service_stages + stage_id].tolist())
        return np.concatenate(
            [
                global_and_nodes,
                np.asarray(stage_features, dtype=np.float32),
                edge_features,
            ]
        ).astype(np.float32, copy=False)

    def _nic_cost_features(self, env: EdgeComputingEnv, node: int) -> list[float]:
        capacities = env.node_nic_capacities()
        finite = capacities[np.isfinite(capacities)]
        if not np.isfinite(capacities[node]):
            return [0.0, 0.0]
        bandwidth = np.where(np.isfinite(env.scenario.bandwidth_mb_s), env.scenario.bandwidth_mb_s, 0.0)
        offered = env.link_load * bandwidth
        pressure = max(float(offered[node].sum()), float(offered[:, node].sum())) / max(capacities[node], 1e-9)
        return [float(capacities[node] / max(float(finite.max()), 1e-9)), float(np.tanh(pressure))]

    def _service_cost_features(self, env: EdgeComputingEnv) -> list[float]:
        """Explicit catalogue costs, not service IDs used as a cost proxy."""
        if not self.cost_context:
            return []
        assert env.scenario is not None
        reference_compute = max(float(np.mean([n.compute_gcycles_per_s for n in env.scenario.nodes])), 1e-9)
        memory = max(float(env.service_memory_capacities().sum()), 1e-9)
        storage = max(float(env.service_storage_capacities().sum()), 1e-9)
        features = []
        for service in env.scenario.services:
            features.extend([
                float(np.log1p(1000.0 * sum(s.compute_gcycles_mean for s in service.stages) / reference_compute)),
                float(np.log1p(service.input_mb_mean)),
                float(np.log1p(sum(s.output_mb_mean for s in service.stages[:-1]))),
                float(sum(s.memory_gb for s in service.stages) / memory),
                float(sum(s.storage_gb for s in service.stages) / storage),
            ])
        return features

    def _build_incremental_stage_mask(
        self,
        env: EdgeComputingEnv,
        remaining_memory: np.ndarray,
        remaining_storage: np.ndarray,
        deployment: np.ndarray,
    ) -> np.ndarray:
        assert env.scenario is not None
        stop_action = self.num_service_types * self.max_service_stages
        mask = np.zeros(stop_action + 1, dtype=bool)
        for service in env.scenario.services:
            for stage in service.stages:
                stage_key = service.service_id * self.max_service_stages + stage.stage_id
                below_cap = int(deployment[service.service_id, stage.stage_id].sum()) < self.replicas_per_stage
                feasible = (
                    (remaining_memory >= stage.memory_gb)
                    & (remaining_storage >= stage.storage_gb)
                    & ~deployment[service.service_id, stage.stage_id]
                )
                mask[stage_key] = bool(below_cap and feasible.any())
        mask[stop_action] = True
        return mask

    def _feedback_features(self) -> list[float]:
        feedback = self.last_window_feedback
        return [
            float(np.clip(feedback.get("avg_latency_s", 0.0), 0.0, 10.0)),
            float(np.clip(feedback.get("p95_latency_s", 0.0), 0.0, 10.0)),
            float(np.clip(feedback.get("avg_penalty_latency_s", 0.0) / 10.0, 0.0, 1.0)),
            float(np.clip(feedback.get("deadline_violation_rate", 0.0), 0.0, 1.0)),
            float(np.clip(feedback.get("invalid_action_rate", 0.0), 0.0, 1.0)),
            float(np.clip(feedback.get("max_node_compute_load", 0.0), 0.0, 1.0)),
            float(np.clip(feedback.get("max_link_load", 0.0), 0.0, 1.0)),
            float(np.clip(feedback.get("deployment_memory_fraction", 0.0), 0.0, 1.0)),
            float(np.clip(feedback.get("deployment_storage_fraction", 0.0), 0.0, 1.0)),
        ]

    def _build_edge_features(self, env: EdgeComputingEnv) -> list[float]:
        return vector_edge_features(env, include_load=True)

    def _node_service_demand(self, env: EdgeComputingEnv) -> np.ndarray:
        assert env.scenario is not None
        demand = np.zeros((self.num_nodes, self.num_service_types), dtype=np.float32)
        for user in env.scenario.users:
            demand[user.home_node] += np.asarray(user.service_weights, dtype=np.float32)
        demand /= max(float(len(env.scenario.users)), 1.0)
        demand *= float(env._arrival_rate_per_minute())
        return np.log1p(demand) / np.log1p(500.0)

    def _build_count_mask(
        self,
        stage,
        remaining_memory: np.ndarray,
        remaining_storage: np.ndarray,
        *,
        reserved_memory: float = 0.0,
        reserved_storage: float = 0.0,
    ) -> np.ndarray:
        feasible_slots = int(np.count_nonzero((remaining_memory >= stage.memory_gb) & (remaining_storage >= stage.storage_gb)))
        memory_budget = max(float(remaining_memory.sum()) - reserved_memory, 0.0)
        storage_budget = max(float(remaining_storage.sum()) - reserved_storage, 0.0)
        memory_count = int(np.floor(memory_budget / max(float(stage.memory_gb), 1e-9)))
        storage_count = int(np.floor(storage_budget / max(float(stage.storage_gb), 1e-9)))
        max_count = min(self.replicas_per_stage, feasible_slots, memory_count, storage_count)
        mask = np.zeros(self.replicas_per_stage, dtype=bool)
        if max_count > 0:
            mask[:max_count] = True
        return mask

    def _repair_with_current_or_full(self, env: EdgeComputingEnv, deployment: np.ndarray) -> np.ndarray:
        feasible, _ = env.check_deployment_feasible(deployment)
        if feasible:
            return deployment
        if env.deployment is not None:
            feasible, _ = env.check_deployment_feasible(env.deployment)
            if feasible:
                return env.deployment.copy()
        raise RuntimeError("slow PPO produced infeasible deployment and no feasible fallback exists")

    def _coverage_repair(
        self,
        env: EdgeComputingEnv,
        deployment: np.ndarray,
        remaining_memory: np.ndarray,
        remaining_storage: np.ndarray,
    ) -> None:
        """Repair uncovered service stages without overriding learned replica counts."""

        assert env.scenario is not None
        demand = self._node_service_demand(env)
        for service in env.scenario.services:
            node_order = np.argsort(-demand[:, service.service_id])
            for stage in service.stages:
                if deployment[service.service_id, stage.stage_id].any():
                    continue
                for node_id in node_order:
                    if remaining_memory[node_id] < stage.memory_gb or remaining_storage[node_id] < stage.storage_gb:
                        continue
                    deployment[service.service_id, stage.stage_id, node_id] = True
                    remaining_memory[node_id] -= stage.memory_gb
                    remaining_storage[node_id] -= stage.storage_gb
                    break


@dataclass
class FastSchedulingPPOAgent:
    num_nodes: int
    max_service_stages: int
    policy_kind: str = "gat_node_scorer"
    chain_context: str = "legacy"
    lr: float = 2e-4
    k_epochs: int = 4
    entropy_coef: float = 0.001
    entropy_target: float | None = 0.7
    entropy_max_coef: float = 0.03
    entropy_adaptation_rate: float = 2e-3
    entropy_normalized_control: bool = False
    value_coef: float = 0.5
    target_kl: float | None = 0.015
    minibatch_size: int = 512
    reservation_microbatch_size: int = 16
    load_balanced_updates: bool = True
    load_group_weights: tuple[float, ...] | None = None
    full_batch_kl_stop: bool = True
    batch_credit: bool = False
    update_chunks: int = 1
    independent_critic: bool = False
    vectorized_features: bool = True
    device: str = "cpu"
    ppo: PPOAgent = field(init=False)
    entropy_current_coef: float = field(default=0.0, init=False)
    _workload_cache_key: tuple[object, ...] | None = field(default=None, init=False, repr=False)
    _workload_cache: tuple[np.ndarray, dict[tuple[int, int], np.ndarray]] | None = field(
        default=None,
        init=False,
        repr=False,
    )
    pending_kkt_stage_costs: list[list[float]] = field(default_factory=list, init=False)
    _nic_phase_objectives: dict[int, float] = field(default_factory=dict, init=False, repr=False)
    _nic_phase_duals: dict[int, tuple[np.ndarray, np.ndarray]] = field(default_factory=dict, init=False, repr=False)

    def __post_init__(self) -> None:
        if self.batch_credit and (self.chain_context != "chain-kkt-v3" or self.policy_kind != "gat_node_scorer"):
            raise ValueError("batch credit repair requires chain-kkt-v3 and gat_node_scorer")
        if self.reservation_microbatch_size < 1:
            raise ValueError("reservation_microbatch_size must be >= 1")
        if self.entropy_coef < 0.0:
            raise ValueError("entropy_coef must be non-negative")
        if self.entropy_target is not None and self.entropy_target < 0.0:
            raise ValueError("entropy_target must be non-negative")
        if self.entropy_max_coef < self.entropy_coef:
            raise ValueError("entropy_max_coef must be at least entropy_coef")
        if self.entropy_adaptation_rate < 0.0:
            raise ValueError("entropy_adaptation_rate must be non-negative")
        global_dim, node_feature_dim = fast_feature_dims(self.chain_context, self.batch_credit)
        self.entropy_current_coef = float(self.entropy_coef)
        self.ppo = PPOAgent(
            obs_dim=fast_obs_dim(self.num_nodes, self.policy_kind, self.chain_context, self.batch_credit),
            action_dim=self.num_nodes,
            hidden_dim=128,
            lr=self.lr,
            gamma=1.0 if self.batch_credit else 0.99,
            gae_lambda=1.0 if self.batch_credit else 0.95,
            k_epochs=self.k_epochs,
            entropy_coef=self.entropy_current_coef,
            value_coef=self.value_coef,
            target_kl=self.target_kl,
            minibatch_size=self.minibatch_size,
            policy_kind=self.policy_kind,
            global_dim=global_dim,
            node_feature_dim=node_feature_dim,
            edge_feature_dim=FAST_EDGE_FEATURE_DIM,
            num_nodes=self.num_nodes,
            group_balanced_updates=self.load_balanced_updates,
            group_weight_targets=self.load_group_weights,
            full_batch_kl_stop=self.full_batch_kl_stop or self.batch_credit,
            detach_critic_backbone=self.batch_credit,
            normalize_value_targets=self.batch_credit,
            guarded_epochs=self.batch_credit,
            guarded_update_chunks=self.update_chunks,
            independent_critic=self.independent_critic,
            critic_lr=5e-4 if self.independent_critic else None,
            device=self.device,
        )

    def schedule(
        self,
        env: EdgeComputingEnv,
        request: TaskRequest | None = None,
        deterministic: bool = False,
        record: bool = True,
    ) -> list[int]:
        if request is None:
            assert env.current_request is not None
            request = env.current_request
        return self.schedule_batch(env, [request], deterministic=deterministic, record=record)[0]

    def schedule_batch(
        self,
        env: EdgeComputingEnv,
        requests: list[TaskRequest],
        deterministic: bool = False,
        record: bool = True,
    ) -> list[list[int]]:
        """Schedule requests under the selected causal decision protocol."""

        env._require_ready()
        if not requests:
            return []
        if self.chain_context == "chain-kkt-v3":
            return self._schedule_batch_kkt_v3(
                env,
                requests,
                deterministic=deterministic,
                record=record,
            )

        schedules: list[list[int]] = [[] for _ in requests]
        transition_records: list[list[tuple[np.ndarray, np.ndarray, int, float, float]]] = [
            [] for _ in requests
        ]
        max_stages = max(len(request.stage_compute_gcycles) for request in requests)
        reservation_node_delta = np.zeros(self.num_nodes, dtype=np.float64)
        reservation_stage_delta: dict[tuple[int, int], np.ndarray] = {}
        for stage_id in range(max_stages):
            active_indices = [
                request_idx
                for request_idx, request in enumerate(requests)
                if stage_id < len(request.stage_compute_gcycles)
            ]
            if not active_indices:
                continue
            for chunk_start in range(0, len(active_indices), self.reservation_microbatch_size):
                chunk = active_indices[chunk_start : chunk_start + self.reservation_microbatch_size]
                states = [
                    self._build_state(
                        env,
                        requests[request_idx],
                        stage_id,
                        schedules[request_idx],
                        reservation_node_delta=reservation_node_delta,
                        reservation_stage_delta=reservation_stage_delta,
                    )
                    for request_idx in chunk
                ]
                masks = [
                    self._build_mask(env, requests[request_idx], stage_id, schedules[request_idx])
                    for request_idx in chunk
                ]
                actions, logprobs, values = self.ppo.act_batch(states, masks, deterministic=deterministic)
                for local_idx, request_idx in enumerate(chunk):
                    action = int(actions[local_idx])
                    if not masks[local_idx][action]:
                        action = int(np.where(masks[local_idx])[0][0])
                    schedules[request_idx].append(action)
                    if record:
                        transition_records[request_idx].append(
                            (
                                states[local_idx],
                                masks[local_idx].astype(bool),
                                action,
                                float(logprobs[local_idx]),
                                float(values[local_idx]),
                            )
                        )
                for local_idx, request_idx in enumerate(chunk):
                    self._reserve_compute_work(
                        env,
                        requests[request_idx],
                        stage_id,
                        int(schedules[request_idx][-1]),
                        reservation_node_delta,
                        reservation_stage_delta,
                    )
        if record:
            # Keep transition order request-major because rollout rewards are
            # assigned after env.step in that same request order.
            for request_records in transition_records:
                for state, mask, action, logprob, value in request_records:
                    self.ppo.buffer.states.append(state)
                    self.ppo.buffer.masks.append(mask)
                    self.ppo.buffer.actions.append(action)
                    self.ppo.buffer.logprobs.append(logprob)
                    self.ppo.buffer.values.append(value)
                    load_group = env.config.demand_load_group
                    self.ppo.buffer.sample_groups.append(
                        float(env.config.demand_load_multiplier if load_group is None else load_group)
                    )
        return schedules

    def _schedule_batch_kkt_v3(
        self, env: EdgeComputingEnv, requests: list[TaskRequest],
        deterministic: bool = False, record: bool = True,
    ) -> list[list[int]]:
        # Loads stay fixed until joint settlement. Reuse immutable capacities
        # and phase port totals instead of rebuilding them for every candidate.
        self._kkt_capacity_cache = (env, self._effective_kkt_capacities(env), env.node_nic_capacities())
        self._nic_port_cache = {}
        try:
            return self._schedule_batch_kkt_v3_cached(env, requests, deterministic=deterministic, record=record)
        finally:
            self._kkt_capacity_cache = None
            self._nic_port_cache = {}

    def _schedule_batch_kkt_v3_cached(
        self,
        env: EdgeComputingEnv,
        requests: list[TaskRequest],
        *,
        deterministic: bool,
        record: bool,
    ) -> list[list[int]]:
        """Generate one complete chain at a time with an exact causal KKT ledger.

        The ledger uses the same serial phases and effective capacities as the
        environment's authoritative settlement.  A group's stored per-stage
        cost is its incremental *total* KKT objective divided by multiplicity;
        weighting it by request_count therefore telescopes exactly to the joint
        compute, wired-link, and propagation objective for the batch.
        """

        assert env.scenario is not None
        max_stages = max(len(request.stage_compute_gcycles) for request in requests)
        self._nic_phase_objectives.clear()
        self._nic_phase_duals.clear()
        compute_sqrt = np.zeros((max_stages, self.num_nodes), dtype=np.float64)
        link_sqrt = np.zeros(
            (max_stages, self.num_nodes, self.num_nodes),
            dtype=np.float64,
        )
        schedules: list[list[int]] = []
        transition_records: list[list[tuple[np.ndarray, np.ndarray, int, float, float]]] = []
        batch_costs: list[list[float]] = []
        processed_weight = 0.0
        total_weight = max(float(sum(request.request_count for request in requests)), 1.0)

        for request_index, request in enumerate(requests):
            partial: list[int] = []
            request_records: list[tuple[np.ndarray, np.ndarray, int, float, float]] = []
            request_costs: list[float] = []
            for stage_id in range(len(request.stage_compute_gcycles)):
                state = self._build_state(
                    env,
                    request,
                    stage_id,
                    partial,
                    kkt_compute_sqrt=compute_sqrt,
                    kkt_link_sqrt=link_sqrt,
                    processed_request_weight=processed_weight,
                    total_request_weight=total_weight,
                    remaining_requests=requests[request_index:],
                )
                mask = self._build_mask(env, request, stage_id, partial)
                action, logprob, value = self.ppo.act(
                    state,
                    mask,
                    deterministic=deterministic,
                )
                action = int(action)
                if not mask[action]:
                    action = int(np.flatnonzero(mask)[0])
                marginal_cost = self._kkt_stage_marginal_cost(
                    env,
                    request,
                    stage_id,
                    action,
                    partial,
                    compute_sqrt,
                    link_sqrt,
                ) if record else 0.0
                partial.append(action)
                self._reserve_kkt_stage(
                    env,
                    request,
                    stage_id,
                    action,
                    partial,
                    compute_sqrt,
                    link_sqrt,
                )
                request_costs.append(float(marginal_cost))
                if record:
                    request_records.append(
                        (state, mask.astype(bool), action, float(logprob), float(value))
                    )
            schedules.append(partial)
            transition_records.append(request_records)
            batch_costs.append(request_costs)
            processed_weight += float(request.request_count)

        if record:
            for request_records in transition_records:
                for state, mask, action, logprob, value in request_records:
                    self.ppo.buffer.states.append(state)
                    self.ppo.buffer.masks.append(mask)
                    self.ppo.buffer.actions.append(action)
                    self.ppo.buffer.logprobs.append(logprob)
                    self.ppo.buffer.values.append(value)
                    load_group = env.config.demand_load_group
                    self.ppo.buffer.sample_groups.append(
                        float(
                            env.config.demand_load_multiplier
                            if load_group is None
                            else load_group
                        )
                    )
            self.pending_kkt_stage_costs.extend(batch_costs)
        return schedules

    def consume_pending_kkt_stage_costs(self) -> list[float] | None:
        """Return the next causal KKT reward decomposition, if v3 recorded one."""

        if self.chain_context != "chain-kkt-v3" or not self.pending_kkt_stage_costs:
            return None
        return self.pending_kkt_stage_costs.pop(0)

    def schedule_with_diagnostics(
        self,
        env: EdgeComputingEnv,
        request: TaskRequest | None = None,
    ) -> tuple[list[int], list[dict[str, float | int]]]:
        env._require_ready()
        if request is None:
            assert env.current_request is not None
            request = env.current_request

        stage_nodes: list[int] = []
        diagnostics: list[dict[str, float | int]] = []
        for stage_id in range(len(request.stage_compute_gcycles)):
            state = self._build_state(env, request, stage_id, stage_nodes)
            mask = self._build_mask(env, request, stage_id, stage_nodes)
            stats = self.ppo.action_stats(state, mask)
            action = int(stats["action"])
            if not mask[action]:
                action = int(np.where(mask)[0][0])
                stats["action"] = action
            stage_nodes.append(action)
            diagnostics.append(stats)
        return stage_nodes, diagnostics

    def assign_schedule_rewards(self, rewards: list[float], done: bool, weight: float = 1.0,
                                *, batch_end: bool | None = None, multiplicity: float = 1.0) -> None:
        """Attach one additive latency reward to each stage action."""

        if self.batch_credit and (batch_end is None or not np.isfinite(multiplicity) or multiplicity <= 0):
            raise ValueError("batch credit requires an explicit batch_end and positive multiplicity")
        for stage_idx, reward in enumerate(rewards):
            self.ppo.buffer.rewards.append(float(reward) * (multiplicity if self.batch_credit else 1.0))
            self.ppo.buffer.dones.append(
                bool((done or batch_end) and stage_idx == len(rewards) - 1) if self.batch_credit
                else bool(done or stage_idx == len(rewards) - 1)
            )
            # Reward already contains physical request multiplicity. Weight
            # only the represented sampling duration, avoiding double counting.
            self.ppo.buffer.weights.append(float(weight / multiplicity if self.batch_credit else weight))

    def assign_last_schedule_reward(self, reward: float, stage_count: int, done: bool, weight: float = 1.0) -> None:
        """Compatibility wrapper using a terminal-only request reward."""

        if stage_count <= 0:
            return
        rewards = [0.0] * stage_count
        rewards[-1] = float(reward)
        self.assign_schedule_rewards(rewards, done=done, weight=weight)

    def update(self, *, progress_label: str = "", progress_interval_seconds: float = 0.0) -> dict[str, float]:
        entropy_coef = self.entropy_current_coef
        self.ppo.entropy_coef = entropy_coef
        has_samples = len(self.ppo.buffer) > 0
        metrics = self.ppo.update(
            progress_label=progress_label,
            progress_interval_seconds=progress_interval_seconds,
        )
        observed_entropy = float(metrics.get("entropy", 0.0))
        observed_control_entropy = float(
            metrics.get("normalized_entropy", observed_entropy)
            if self.entropy_normalized_control
            else observed_entropy
        )
        if not has_samples:
            next_coef = entropy_coef
        elif self.entropy_target is None or not np.isfinite(observed_control_entropy):
            next_coef = self.entropy_coef
        else:
            next_coef = entropy_coef + self.entropy_adaptation_rate * (
                float(self.entropy_target) - observed_control_entropy
            )
            next_coef = float(np.clip(next_coef, self.entropy_coef, self.entropy_max_coef))
        self.entropy_current_coef = float(next_coef)
        self.ppo.entropy_coef = self.entropy_current_coef
        metrics["entropy_coef"] = float(entropy_coef)
        metrics["entropy_next_coef"] = self.entropy_current_coef
        metrics["entropy_target"] = float(self.entropy_target) if self.entropy_target is not None else 0.0
        metrics["entropy_control_value"] = observed_control_entropy
        metrics["entropy_normalized_control"] = float(self.entropy_normalized_control)
        metrics["entropy_shortfall"] = (
            max(float(self.entropy_target or 0.0) - observed_control_entropy, 0.0)
            if has_samples
            else 0.0
        )
        metrics["entropy_saturated"] = float(
            np.isclose(self.entropy_current_coef, self.entropy_max_coef)
        )
        return metrics

    def _build_state(
        self,
        env: EdgeComputingEnv,
        request: TaskRequest,
        stage_id: int,
        partial_nodes: list[int],
        *,
        reservation_node_delta: np.ndarray | None = None,
        reservation_stage_delta: dict[tuple[int, int], np.ndarray] | None = None,
        kkt_compute_sqrt: np.ndarray | None = None,
        kkt_link_sqrt: np.ndarray | None = None,
        processed_request_weight: float = 0.0,
        total_request_weight: float = 1.0,
        remaining_requests: list[TaskRequest] | tuple[TaskRequest, ...] | None = None,
    ) -> np.ndarray:
        assert env.scenario is not None
        prev_node = request.home_node if not partial_nodes else partial_nodes[-1]
        nodes = env.scenario.nodes
        max_compute = max(n.compute_gcycles_per_s for n in nodes)
        max_bandwidth = np.nanmax(np.where(np.isfinite(env.scenario.bandwidth_mb_s), env.scenario.bandwidth_mb_s, 0.0))
        tick_request_count = float(sum(item.request_count for item in env.current_requests))
        tick_request_event_count = float(len(env.current_requests))
        tick_service_count = float(
            sum(item.request_count for item in env.current_requests if item.service_id == request.service_id)
        )
        tick_node_counts = np.zeros(self.num_nodes, dtype=np.float64)
        for item in env.current_requests:
            tick_node_counts[item.home_node] += float(item.request_count)
        expected_node_work, expected_stage_work = self._expected_current_compute_workload(env)
        if reservation_node_delta is not None:
            expected_node_work = np.maximum(expected_node_work + reservation_node_delta, 0.0)
        stage_key = (request.service_id, stage_id)
        stage_work = expected_stage_work.get(stage_key, np.zeros(self.num_nodes)).copy()
        if reservation_stage_delta is not None and stage_key in reservation_stage_delta:
            stage_work = np.maximum(stage_work + reservation_stage_delta[stage_key], 0.0)
        candidate_post_work = self._candidate_post_compute_workload(
            env,
            request,
            stage_id,
            expected_node_work,
        )
        node_features = []
        incoming_data_mb = (
            float(request.input_mb)
            if stage_id == 0
            else float(request.stage_output_mb[stage_id - 1])
        )
        current_output_mb = float(request.stage_output_mb[stage_id])
        next_stage_id = stage_id + 1
        has_next_stage = next_stage_id < len(request.stage_compute_gcycles)
        deployed = env.deployment[request.service_id, stage_id] if env.deployment is not None else np.zeros(self.num_nodes, dtype=bool)
        accelerated = self.batch_credit and self.vectorized_features
        if accelerated:
            plan = route_plan(env)
            _, effective_bandwidth = self._effective_kkt_capacities(env)
            routed_transfer = plan.sum_edges(incoming_data_mb / np.maximum(effective_bandwidth, 1e-9))[prev_node]
            kkt_features_all = self._kkt_candidate_features_all(
                env, request, stage_id, partial_nodes, kkt_compute_sqrt, kkt_link_sqrt, plan)
        for node in nodes:
            bandwidth = env.scenario.bandwidth_mb_s[prev_node, node.node_id]
            if not np.isfinite(bandwidth):
                bandwidth = 0.0
            reachable = bool(plan.reachable[prev_node, node.node_id]) if accelerated else env.shortest_path(prev_node, node.node_id) is not None
            features = [
                    float(deployed[node.node_id]),
                    float(reachable),
                    node.compute_gcycles_per_s / max_compute,
                    env.node_compute_load[node.node_id],
                    bandwidth / max(max_bandwidth, 1e-9),
                    tick_node_counts[node.node_id] / max(tick_request_count, 1.0),
                    self._normalize_compute_pressure(expected_node_work[node.node_id], node.compute_gcycles_per_s),
                    self._normalize_compute_pressure(stage_work[node.node_id], node.compute_gcycles_per_s),
                    self._normalize_compute_pressure(
                        candidate_post_work[node.node_id],
                        node.compute_gcycles_per_s * max(1.0 - 0.75 * env.node_compute_load[node.node_id], 0.10),
                    ),
                ]
            if self.chain_context in {"chain-v2", "chain-kkt-v3"}:
                if accelerated:
                    transfer_s, propagation_s = routed_transfer[node.node_id], plan.propagation[prev_node, node.node_id]
                else:
                    transfer_s, propagation_s = self._route_proxy_delay(env, prev_node, node.node_id, incoming_data_mb)
                next_stage_overlap = float(
                    has_next_stage
                    and env.deployment is not None
                    and env.deployment[request.service_id, next_stage_id, node.node_id]
                )
                features.extend(
                    [
                        float(node.node_id == prev_node),
                        float(np.tanh(transfer_s / 0.25)) if np.isfinite(transfer_s) else 1.0,
                        float(np.tanh(propagation_s / 0.05)) if np.isfinite(propagation_s) else 1.0,
                        next_stage_overlap,
                    ]
                )
            if self.chain_context == "chain-kkt-v3":
                kkt_features = kkt_features_all[node.node_id].tolist() if accelerated else self._kkt_candidate_features(
                    env,
                    request,
                    stage_id,
                    node.node_id,
                    partial_nodes,
                    kkt_compute_sqrt,
                    kkt_link_sqrt,
                )
                features.extend(kkt_features)
            node_features.extend(features)
        scalars = [
            request.service_id / max(env.config.num_service_types - 1, 1),
            stage_id / max(self.max_service_stages - 1, 1),
            prev_node / max(self.num_nodes - 1, 1),
            request.input_mb / 2.0,
            request.stage_compute_gcycles[stage_id] / 8.0,
            request.deadline_s / 0.6,
            request.request_count / 100.0,
            env.current_time_minute / max(env.config.episode_minutes, 1),
            len(request.stage_compute_gcycles) / self.max_service_stages,
            np.log1p(tick_request_count) / np.log1p(5_000.0),
            tick_request_event_count / max(env.config.num_edge_nodes * env.config.num_service_types, 1),
            tick_service_count / max(tick_request_count, 1.0),
        ]
        if self.chain_context in {"chain-v2", "chain-kkt-v3"}:
            total_compute = max(float(sum(request.stage_compute_gcycles)), 1e-9)
            remaining_compute = float(sum(request.stage_compute_gcycles[stage_id:]))
            remaining_output = float(sum(request.stage_output_mb[stage_id:]))
            scalars.extend(
                [
                    incoming_data_mb / 2.0,
                    current_output_mb / 2.0,
                    remaining_compute / total_compute,
                    float(np.tanh(remaining_output / 4.0)),
                ]
            )
        if self.chain_context == "chain-kkt-v3":
            progress = float(processed_request_weight) / max(float(total_request_weight), 1.0)
            scalars.extend([progress, 1.0 - progress])
        if self.batch_credit:
            remaining = remaining_requests if remaining_requests is not None else [request]
            count = max(float(sum(r.request_count for r in remaining)), 1.0)
            compute = sum(float(r.request_count) * sum(r.stage_compute_gcycles) for r in remaining)
            uploads = sum(float(r.request_count) * r.input_mb for r in remaining)
            outputs = sum(float(r.request_count) * sum(r.stage_output_mb[:-1]) for r in remaining)
            same_service = sum(float(r.request_count) for r in remaining if r.service_id == request.service_id)
            capacity = max(float(sum(n.compute_gcycles_per_s for n in nodes)), 1e-9)
            scalars.extend([
                count / max(float(total_request_weight), 1.0),
                float(np.log1p(compute / capacity)),
                float(np.log1p(uploads / count)), float(np.log1p(outputs / count)),
                same_service / count, float(len(remaining)) / max(len(env.current_requests), 1),
            ])
        if self.policy_kind == "gat_node_scorer":
            node_features += self._build_edge_features(env)
        return np.asarray(scalars + node_features, dtype=np.float32)

    def _effective_kkt_capacities(
        self,
        env: EdgeComputingEnv,
    ) -> tuple[np.ndarray, np.ndarray]:
        cached = getattr(self, "_kkt_capacity_cache", None)
        if cached is not None and cached[0] is env:
            return cached[1]
        assert env.scenario is not None
        compute = np.asarray(
            [node.compute_gcycles_per_s for node in env.scenario.nodes],
            dtype=np.float64,
        )
        compute *= np.clip(1.0 - 0.75 * env.node_compute_load, 0.10, 1.0)
        bandwidth = np.asarray(env.scenario.bandwidth_mb_s, dtype=np.float64).copy()
        finite = np.isfinite(bandwidth)
        bandwidth[finite] *= np.clip(1.0 - 0.75 * env.link_load[finite], 0.10, 1.0)
        return compute, bandwidth

    @staticmethod
    def _kkt_total_increment(
        previous_sqrt: float,
        size: float,
        multiplicity: float,
        capacity: float,
    ) -> float:
        if size <= 0.0:
            return 0.0
        addition = max(float(multiplicity), 0.0) * np.sqrt(max(float(size), 0.0))
        return float(
            (2.0 * max(float(previous_sqrt), 0.0) * addition + addition * addition)
            / max(float(capacity), 1e-9)
        )

    def _routed_kkt_increment(
        self,
        env: EdgeComputingEnv,
        *,
        phase: int,
        source: int,
        target: int,
        data_mb: float,
        multiplicity: float,
        link_sqrt: np.ndarray,
        exact_shared_nic: bool = False,
    ) -> tuple[float, float]:
        if int(source) == int(target):
            return 0.0, 0.0
        assert env.scenario is not None
        path = env.shortest_path(int(source), int(target))
        if path is None:
            return float("inf"), float("inf")
        _, bandwidth = self._effective_kkt_capacities(env)
        transfer_total = 0.0
        propagation_per_request = 0.0
        shared_nic = env.config.network_constraint_mode == "shared-nic"
        cached = getattr(self, "_kkt_capacity_cache", None)
        nic = (cached[2] if cached is not None and cached[0] is env else env.node_nic_capacities()) if shared_nic else None
        if shared_nic and not exact_shared_nic:
            port_cache = getattr(self, "_nic_port_cache", None)
            totals = None if port_cache is None else port_cache.get(phase)
            if totals is None:
                totals = (link_sqrt[phase].sum(axis=1), link_sqrt[phase].sum(axis=0))
                if port_cache is not None:
                    port_cache[phase] = totals
            outgoing_loads, incoming_loads = totals
        new_loads = link_sqrt[phase].copy() if shared_nic and exact_shared_nic else None
        addition = max(float(multiplicity), 0.0) * np.sqrt(max(data_mb, 0.0))
        for left, right in zip(path, path[1:]):
            capacity = bandwidth[left, right]
            if shared_nic and not exact_shared_nic:
                # A cheap port-sharing proxy for actor features, NOT the
                # authoritative reward. The selected action is solved exactly.
                own = link_sqrt[phase, left, right] + addition
                capacity = min(capacity,
                               nic[left] * own / max(outgoing_loads[left] + addition, 1e-12),
                               nic[right] * own / max(incoming_loads[right] + addition, 1e-12))
            transfer_total += self._kkt_total_increment(
                link_sqrt[phase, left, right],
                data_mb,
                multiplicity,
                capacity,
            )
            if new_loads is not None:
                new_loads[left, right] += addition
            propagation_per_request += float(env.scenario.propagation_ms[left, right]) / 1000.0
        if new_loads is not None:
            previous = self._nic_phase_objectives.get(phase)
            if previous is None:
                _, previous, _ = nic_link_rates(link_sqrt[phase], bandwidth, nic)
            _, objective, duals = nic_link_rates(new_loads, bandwidth, nic,
                                               initial_duals=self._nic_phase_duals.get(phase))
            transfer_total = objective - previous
            self._nic_phase_objectives[phase] = objective
            self._nic_phase_duals[phase] = duals
        return transfer_total, propagation_per_request

    def _kkt_stage_marginal_cost(
        self,
        env: EdgeComputingEnv,
        request: TaskRequest,
        stage_id: int,
        node_id: int,
        partial_nodes: list[int],
        compute_sqrt: np.ndarray,
        link_sqrt: np.ndarray,
    ) -> float:
        compute_capacity, _ = self._effective_kkt_capacities(env)
        multiplicity = max(float(request.request_count), 1.0)
        compute_total = self._kkt_total_increment(
            compute_sqrt[stage_id, node_id],
            float(request.stage_compute_gcycles[stage_id]),
            multiplicity,
            compute_capacity[node_id],
        )
        source = int(request.home_node) if stage_id == 0 else int(partial_nodes[-1])
        data_mb = (
            float(request.input_mb)
            if stage_id == 0
            else float(request.stage_output_mb[stage_id - 1])
        )
        link_total, propagation_per_request = self._routed_kkt_increment(
            env,
            phase=stage_id,
            source=source,
            target=int(node_id),
            data_mb=data_mb,
            multiplicity=multiplicity,
            link_sqrt=link_sqrt,
            exact_shared_nic=True,
        )
        return float((compute_total + link_total) / multiplicity + propagation_per_request)

    def _reserve_kkt_stage(
        self,
        env: EdgeComputingEnv,
        request: TaskRequest,
        stage_id: int,
        node_id: int,
        partial_nodes: list[int],
        compute_sqrt: np.ndarray,
        link_sqrt: np.ndarray,
    ) -> None:
        multiplicity = max(float(request.request_count), 1.0)
        compute_sqrt[stage_id, node_id] += multiplicity * np.sqrt(
            max(float(request.stage_compute_gcycles[stage_id]), 0.0)
        )
        source = int(request.home_node) if stage_id == 0 else int(partial_nodes[-2])
        if source == int(node_id):
            return
        path = env.shortest_path(source, int(node_id))
        if path is None:
            return
        data_mb = (
            float(request.input_mb)
            if stage_id == 0
            else float(request.stage_output_mb[stage_id - 1])
        )
        addition = multiplicity * np.sqrt(max(data_mb, 0.0))
        if hasattr(self, "_nic_port_cache"):
            self._nic_port_cache.pop(stage_id, None)
        for left, right in zip(path, path[1:]):
            link_sqrt[stage_id, left, right] += addition

    def _proxy_route_increments_all(self, env, phase, data_mb, multiplicity, link_sqrt, plan):
        """Vectorized equivalent of the scalar candidate route proxy."""
        if data_mb <= 0:
            return np.where(plan.reachable, 0.0, np.inf)
        _, bandwidth = self._effective_kkt_capacities(env)
        previous = np.maximum(link_sqrt[phase], 0.0)
        addition = max(float(multiplicity), 0.0) * np.sqrt(max(float(data_mb), 0.0))
        capacity = bandwidth.copy()
        if env.config.network_constraint_mode == "shared-nic":
            cached = getattr(self, "_kkt_capacity_cache", None)
            nic = cached[2] if cached is not None and cached[0] is env else env.node_nic_capacities()
            own = previous + addition
            outgoing = nic[:, None] * own / np.maximum(link_sqrt[phase].sum(axis=1)[:, None] + addition, 1e-12)
            incoming = nic[None, :] * own / np.maximum(link_sqrt[phase].sum(axis=0)[None, :] + addition, 1e-12)
            capacity = np.minimum(capacity, np.minimum(outgoing, incoming))
        increments = (2 * previous * addition + addition * addition) / np.maximum(capacity, 1e-9)
        return plan.sum_edges(increments)

    def _kkt_candidate_features_all(self, env, request, stage_id, partial_nodes, compute_sqrt, link_sqrt, plan):
        """Evaluate all candidates without pruning or replacing actor actions."""
        stages = len(request.stage_compute_gcycles)
        if compute_sqrt is None:
            compute_sqrt = np.zeros((stages, self.num_nodes))
        if link_sqrt is None:
            link_sqrt = np.zeros((stages, self.num_nodes, self.num_nodes))
        compute_capacity, _ = self._effective_kkt_capacities(env)
        capacity = np.maximum(compute_capacity, 1e-9)
        multiplicity = max(float(request.request_count), 1.0)
        addition = multiplicity * np.sqrt(max(float(request.stage_compute_gcycles[stage_id]), 0.0))
        compute = (2 * np.maximum(compute_sqrt[stage_id], 0) * addition + addition * addition) / capacity / multiplicity
        source = int(request.home_node) if stage_id == 0 else int(partial_nodes[-1])
        data = request.input_mb if stage_id == 0 else request.stage_output_mb[stage_id - 1]
        link = self._proxy_route_increments_all(env, stage_id, data, multiplicity, link_sqrt, plan)[source] / multiplicity
        propagation = plan.propagation[source]
        ledger = compute_sqrt[stage_id] ** 2 / capacity / multiplicity
        downstream = np.zeros(self.num_nodes)
        next_stage = stage_id + 1
        if next_stage < stages and env.deployment is not None:
            candidates = np.flatnonzero(env.deployment[request.service_id, next_stage])
            if candidates.size:
                next_addition = multiplicity * np.sqrt(max(float(request.stage_compute_gcycles[next_stage]), 0))
                next_compute = (2 * np.maximum(compute_sqrt[next_stage], 0) * next_addition + next_addition ** 2) / capacity / multiplicity
                next_link = self._proxy_route_increments_all(env, next_stage, request.stage_output_mb[stage_id], multiplicity, link_sqrt, plan)
                costs = next_compute[candidates][None, :] + next_link[:, candidates] / multiplicity + plan.propagation[:, candidates]
                downstream = np.min(costs, axis=1)
                downstream = np.where(np.isfinite(downstream), downstream, 0.0)
        return np.column_stack([np.tanh(compute), np.tanh(link), np.tanh(propagation / .05),
                                np.tanh(downstream), np.tanh(ledger)])

    def _kkt_candidate_features(
        self,
        env: EdgeComputingEnv,
        request: TaskRequest,
        stage_id: int,
        node_id: int,
        partial_nodes: list[int],
        compute_sqrt: np.ndarray | None,
        link_sqrt: np.ndarray | None,
    ) -> list[float]:
        stages = len(request.stage_compute_gcycles)
        if compute_sqrt is None:
            compute_sqrt = np.zeros((stages, self.num_nodes), dtype=np.float64)
        if link_sqrt is None:
            link_sqrt = np.zeros(
                (stages, self.num_nodes, self.num_nodes),
                dtype=np.float64,
            )
        compute_capacity, _ = self._effective_kkt_capacities(env)
        multiplicity = max(float(request.request_count), 1.0)
        compute_total = self._kkt_total_increment(
            compute_sqrt[stage_id, node_id],
            float(request.stage_compute_gcycles[stage_id]),
            multiplicity,
            compute_capacity[node_id],
        )
        source = int(request.home_node) if stage_id == 0 else int(partial_nodes[-1])
        data_mb = (
            float(request.input_mb)
            if stage_id == 0
            else float(request.stage_output_mb[stage_id - 1])
        )
        link_total, propagation = self._routed_kkt_increment(
            env,
            phase=stage_id,
            source=source,
            target=node_id,
            data_mb=data_mb,
            multiplicity=multiplicity,
            link_sqrt=link_sqrt,
        )
        compute_per_request = compute_total / multiplicity
        link_per_request = link_total / multiplicity
        ledger_delay = float(
            compute_sqrt[stage_id, node_id] ** 2 / max(compute_capacity[node_id], 1e-9)
        ) / multiplicity

        downstream = 0.0
        next_stage = stage_id + 1
        if next_stage < stages and env.deployment is not None:
            candidates = np.flatnonzero(env.deployment[request.service_id, next_stage])
            downstream_costs: list[float] = []
            for next_node in candidates:
                next_node = int(next_node)
                next_compute = self._kkt_total_increment(
                    compute_sqrt[next_stage, next_node],
                    float(request.stage_compute_gcycles[next_stage]),
                    multiplicity,
                    compute_capacity[next_node],
                ) / multiplicity
                next_link, next_prop = self._routed_kkt_increment(
                    env,
                    phase=next_stage,
                    source=node_id,
                    target=next_node,
                    data_mb=float(request.stage_output_mb[stage_id]),
                    multiplicity=multiplicity,
                    link_sqrt=link_sqrt,
                )
                if np.isfinite(next_link):
                    downstream_costs.append(next_compute + next_link / multiplicity + next_prop)
            if downstream_costs:
                downstream = min(downstream_costs)
        return [
            float(np.tanh(compute_per_request)),
            float(np.tanh(link_per_request)) if np.isfinite(link_per_request) else 1.0,
            float(np.tanh(propagation / 0.05)) if np.isfinite(propagation) else 1.0,
            float(np.tanh(downstream)),
            float(np.tanh(ledger_delay)),
        ]

    def stage_counterfactual_regrets(
        self,
        env: EdgeComputingEnv,
        request: TaskRequest,
        stage_nodes: list[int] | tuple[int, ...],
    ) -> list[float]:
        """Approximate action regret against feasible chain-aware alternatives.

        The proxy uses effective compute capacity, routed incoming data, and a
        one-stage downstream lookahead.  It is deliberately independent of the
        actor logits so it remains a useful difference-reward signal.
        """

        regrets: list[float] = []
        partial: list[int] = []
        for stage_id, selected_node in enumerate(stage_nodes):
            mask = self._build_mask(env, request, stage_id, partial)
            candidates = np.flatnonzero(mask)
            if candidates.size == 0:
                regrets.append(0.0)
            else:
                costs = [
                    self._stage_candidate_proxy_cost(
                        env,
                        request,
                        stage_id,
                        int(candidate),
                        partial,
                    )
                    for candidate in candidates
                ]
                selected_cost = self._stage_candidate_proxy_cost(
                    env,
                    request,
                    stage_id,
                    int(selected_node),
                    partial,
                )
                best_cost = min(costs)
                regrets.append(max(float(selected_cost - best_cost), 0.0))
            partial.append(int(selected_node))
        return regrets

    def stage_selected_node_marginal_values(
        self,
        env: EdgeComputingEnv,
        request: TaskRequest,
        stage_nodes: list[int] | tuple[int, ...],
    ) -> list[float]:
        """Estimate the value of keeping each selected node on the same trace.

        Positive means that forcing this stage onto its best other deployed
        replica would increase latency; negative means another deployed node
        was preferable.  Unlike the actor-logit baseline, this signal is tied
        to the actual request, chain prefix, topology, and resource state.
        """

        marginal_values: list[float] = []
        partial: list[int] = []
        for stage_id, selected_node_raw in enumerate(stage_nodes):
            selected_node = int(selected_node_raw)
            mask = self._build_mask(env, request, stage_id, partial)
            alternatives = [
                int(node_id)
                for node_id in np.flatnonzero(mask)
                if int(node_id) != selected_node
            ]
            if not alternatives:
                marginal_values.append(0.0)
            else:
                selected_cost = self._stage_candidate_proxy_cost(
                    env,
                    request,
                    stage_id,
                    selected_node,
                    partial,
                )
                alternative_cost = min(
                    self._stage_candidate_proxy_cost(
                        env,
                        request,
                        stage_id,
                        node_id,
                        partial,
                    )
                    for node_id in alternatives
                )
                marginal_values.append(
                    float(np.clip(alternative_cost - selected_cost, -2.0, 2.0))
                )
            partial.append(selected_node)
        return marginal_values

    def chain_oracle_schedule(
        self,
        env: EdgeComputingEnv,
        request: TaskRequest,
        *,
        beam_width: int = 32,
        candidates_per_stage: int = 8,
    ) -> list[int]:
        """Return a bounded beam-search oracle under the active deployment."""

        beam_width = max(int(beam_width), 1)
        candidates_per_stage = max(int(candidates_per_stage), 1)
        paths: list[tuple[list[int], float]] = [([], 0.0)]
        for stage_id in range(len(request.stage_compute_gcycles)):
            expanded: list[tuple[list[int], float]] = []
            for partial, prefix_cost in paths:
                mask = self._build_mask(env, request, stage_id, partial)
                ranked = sorted(
                    np.flatnonzero(mask).tolist(),
                    key=lambda node_id: self._stage_candidate_proxy_cost(
                        env, request, stage_id, int(node_id), partial
                    ),
                )[:candidates_per_stage]
                for node_id in ranked:
                    incremental = self._stage_candidate_proxy_cost(
                        env, request, stage_id, int(node_id), partial
                    )
                    expanded.append((partial + [int(node_id)], prefix_cost + incremental))
            if not expanded:
                return [request.home_node] * len(request.stage_compute_gcycles)
            expanded.sort(key=lambda item: item[1])
            paths = expanded[:beam_width]
        valid = [
            (path, env.evaluate_schedule(request, path))
            for path, _ in paths
        ]
        valid.sort(
            key=lambda item: (
                not bool(item[1]["valid"]),
                float(item[1]["latency_s"]),
            )
        )
        return valid[0][0]

    def _stage_candidate_proxy_cost(
        self,
        env: EdgeComputingEnv,
        request: TaskRequest,
        stage_id: int,
        node_id: int,
        partial_nodes: list[int],
    ) -> float:
        assert env.scenario is not None
        prev_node = request.home_node if not partial_nodes else partial_nodes[-1]
        incoming_data_mb = (
            float(request.input_mb)
            if stage_id == 0
            else float(request.stage_output_mb[stage_id - 1])
        )
        transfer_s, propagation_s = self._route_proxy_delay(
            env,
            prev_node,
            node_id,
            incoming_data_mb,
        )
        if not np.isfinite(transfer_s):
            return float("inf")
        node = env.scenario.nodes[node_id]
        effective_capacity = float(node.compute_gcycles_per_s) * max(
            1.0 - 0.75 * float(env.node_compute_load[node_id]),
            0.10,
        )
        compute_s = float(request.stage_compute_gcycles[stage_id]) / max(effective_capacity, 1e-9)
        downstream_s = 0.0
        next_stage_id = stage_id + 1
        if next_stage_id < len(request.stage_compute_gcycles) and env.deployment is not None:
            next_candidates = np.flatnonzero(env.deployment[request.service_id, next_stage_id])
            lookahead: list[float] = []
            for next_node_id in next_candidates:
                next_transfer, next_propagation = self._route_proxy_delay(
                    env,
                    node_id,
                    int(next_node_id),
                    float(request.stage_output_mb[stage_id]),
                )
                if not np.isfinite(next_transfer):
                    continue
                next_node = env.scenario.nodes[int(next_node_id)]
                next_capacity = float(next_node.compute_gcycles_per_s) * max(
                    1.0 - 0.75 * float(env.node_compute_load[int(next_node_id)]),
                    0.10,
                )
                next_compute = float(request.stage_compute_gcycles[next_stage_id]) / max(
                    next_capacity,
                    1e-9,
                )
                lookahead.append(next_transfer + next_propagation + next_compute)
            if lookahead:
                downstream_s = 0.5 * min(lookahead)
        return compute_s + transfer_s + propagation_s + downstream_s

    @staticmethod
    def _route_proxy_delay(
        env: EdgeComputingEnv,
        src_node: int,
        dst_node: int,
        data_mb: float,
    ) -> tuple[float, float]:
        if int(src_node) == int(dst_node):
            return 0.0, 0.0
        assert env.scenario is not None
        path = env.shortest_path(int(src_node), int(dst_node))
        if path is None:
            return float("inf"), float("inf")
        transfer_s = 0.0
        propagation_s = 0.0
        for left, right in zip(path, path[1:]):
            raw_bandwidth = float(env.scenario.bandwidth_mb_s[left, right])
            residual = max(1.0 - 0.75 * float(env.link_load[left, right]), 0.10)
            transfer_s += float(data_mb) / max(raw_bandwidth * residual, 1e-9)
            propagation_s += float(env.scenario.propagation_ms[left, right]) / 1000.0
        return transfer_s, propagation_s

    def _reserve_compute_work(
        self,
        env: EdgeComputingEnv,
        request: TaskRequest,
        stage_id: int,
        action: int,
        node_delta: np.ndarray,
        stage_deltas: dict[tuple[int, int], np.ndarray],
    ) -> None:
        """Replace the fair-share workload estimate with assignments already made.

        Unscheduled requests remain represented by the capacity-proportional
        baseline.  Once a microbatch is scheduled, its baseline share is
        removed and its work is reserved on the selected node.  Later
        microbatches therefore observe the congestion created by earlier ones.
        """

        assert env.scenario is not None
        assert env.deployment is not None
        candidates = env.deployment[request.service_id, stage_id]
        candidate_ids = np.flatnonzero(candidates)
        if candidate_ids.size == 0:
            return
        capacities = np.asarray(
            [node.compute_gcycles_per_s for node in env.scenario.nodes],
            dtype=np.float64,
        )
        shares = capacities[candidate_ids] / max(float(capacities[candidate_ids].sum()), 1e-9)
        work = float(request.stage_compute_gcycles[stage_id]) * float(request.request_count)
        delta = np.zeros(self.num_nodes, dtype=np.float64)
        delta[candidate_ids] -= work * shares
        delta[int(action)] += work
        node_delta += delta
        stage_key = (request.service_id, stage_id)
        if stage_key not in stage_deltas:
            stage_deltas[stage_key] = np.zeros(self.num_nodes, dtype=np.float64)
        stage_deltas[stage_key] += delta

    @staticmethod
    def _normalize_compute_pressure(work_gcycles: float, capacity_gcycles_per_s: float) -> float:
        """Expose instantaneous batch pressure without confusing it with EWMA load."""

        pressure = max(float(work_gcycles), 0.0) / max(float(capacity_gcycles_per_s), 1e-9)
        return float(np.tanh(pressure))

    def _expected_current_compute_workload(
        self,
        env: EdgeComputingEnv,
    ) -> tuple[np.ndarray, dict[tuple[int, int], np.ndarray]]:
        """Estimate current-second compute work under the active deployment.

        The environment settles all requests in a second jointly.  The old
        observation exposed only a one-minute EWMA, so the scheduler could not
        distinguish a lightly loaded node from a node facing a large current
        batch.  This estimate distributes each stage's work across its active
        replicas in proportion to their capacities and is cached for the
        current request tick.
        """

        env._require_ready()
        assert env.scenario is not None
        if env.deployment is None:
            return (
                np.zeros(self.num_nodes, dtype=np.float64),
                {},
            )
        cache_key = (
            id(env.current_requests),
            float(env.current_time_minute),
            float(env.metrics.get("deployment_updates", 0.0)),
        )
        if self._workload_cache_key == cache_key and self._workload_cache is not None:
            return self._workload_cache

        node_work = np.zeros(self.num_nodes, dtype=np.float64)
        stage_work: dict[tuple[int, int], np.ndarray] = {}
        capacities = np.asarray(
            [node.compute_gcycles_per_s for node in env.scenario.nodes],
            dtype=np.float64,
        )
        for current_request in env.current_requests:
            request_weight = float(current_request.request_count)
            for current_stage_id, compute_gcycles in enumerate(current_request.stage_compute_gcycles):
                key = (current_request.service_id, current_stage_id)
                candidates = env.deployment[current_request.service_id, current_stage_id]
                candidate_ids = np.flatnonzero(candidates)
                if candidate_ids.size == 0:
                    continue
                candidate_capacities = capacities[candidate_ids]
                shares = candidate_capacities / max(float(candidate_capacities.sum()), 1e-9)
                contribution = float(compute_gcycles) * request_weight * shares
                node_work[candidate_ids] += contribution
                if key not in stage_work:
                    stage_work[key] = np.zeros(self.num_nodes, dtype=np.float64)
                stage_work[key][candidate_ids] += contribution

        self._workload_cache_key = cache_key
        self._workload_cache = (node_work, stage_work)
        return self._workload_cache

    def _candidate_post_compute_workload(
        self,
        env: EdgeComputingEnv,
        request: TaskRequest,
        stage_id: int,
        expected_node_work: np.ndarray,
    ) -> np.ndarray:
        """Estimate node work if this request stage is assigned to each candidate."""

        if env.deployment is None or stage_id >= len(request.stage_compute_gcycles):
            return np.zeros(self.num_nodes, dtype=np.float64)
        candidates = env.deployment[request.service_id, stage_id]
        candidate_ids = np.flatnonzero(candidates)
        if candidate_ids.size == 0:
            return np.zeros(self.num_nodes, dtype=np.float64)

        capacities = np.asarray(
            [node.compute_gcycles_per_s for node in env.scenario.nodes],
            dtype=np.float64,
        )
        candidate_capacities = capacities[candidate_ids]
        shares = candidate_capacities / max(float(candidate_capacities.sum()), 1e-9)
        request_work = float(request.stage_compute_gcycles[stage_id]) * float(request.request_count)
        baseline_without_request = expected_node_work.copy()
        baseline_without_request[candidate_ids] -= request_work * shares
        return np.where(
            candidates,
            baseline_without_request + request_work,
            0.0,
        )

    def _build_edge_features(self, env: EdgeComputingEnv) -> list[float]:
        return vector_edge_features(env)

    def _build_mask(
        self,
        env: EdgeComputingEnv,
        request: TaskRequest,
        stage_id: int,
        partial_nodes: list[int],
    ) -> np.ndarray:
        assert env.scenario is not None
        mask = env.scheduler_candidate_mask(request)[stage_id].copy()
        prev_node = request.home_node if not partial_nodes else partial_nodes[-1]
        reachable = route_plan(env).reachable[prev_node].copy() if self.batch_credit and self.vectorized_features else np.asarray(
            [env.shortest_path(prev_node, node_id) is not None for node_id in range(self.num_nodes)],
            dtype=bool,
        )
        mask &= reachable
        if not mask.any():
            mask = env.scheduler_candidate_mask(request)[stage_id].copy()
        if not mask.any():
            mask[request.home_node] = True
        return mask.astype(bool)


def _weighted_percentile(samples: list[tuple[float, float]], percentile: float) -> float:
    if not samples:
        return 0.0
    ordered = sorted((float(value), max(float(weight), 0.0)) for value, weight in samples)
    total_weight = sum(weight for _, weight in ordered)
    if total_weight <= 0.0:
        return float(ordered[-1][0])
    threshold = total_weight * float(percentile) / 100.0
    cumulative = 0.0
    for value, weight in ordered:
        cumulative += weight
        if cumulative >= threshold:
            return value
    return float(ordered[-1][0])


@dataclass
class HierarchicalPPOAgent:
    slow_agent: SlowDeploymentPPOAgent
    fast_agent: FastSchedulingPPOAgent
    window_reward: float = 0.0
    window_steps: float = 0.0
    window_latency_samples: list[tuple[float, float]] = field(default_factory=list)
    window_penalty_latency_sum: float = 0.0
    window_deadline_violations: float = 0.0
    window_invalid_actions: float = 0.0
    window_max_node_compute_load: float = 0.0
    window_max_link_load: float = 0.0
    window_cross_stage_transitions: float = 0.0
    window_stage_transitions: float = 0.0
    window_cross_stage_data_mb: float = 0.0
    window_total_transition_data_mb: float = 0.0
    window_stage_latency_samples: dict[tuple[int, int], list[tuple[float, float]]] = field(default_factory=dict)
    window_stage_deadline_violations: dict[tuple[int, int], float] = field(default_factory=dict)
    window_stage_weights: dict[tuple[int, int], float] = field(default_factory=dict)
    window_route_history: SlowRouteHistory | None = field(default=None, repr=False)
    window_stage_cross_transitions: dict[tuple[int, int], float] = field(default_factory=dict)
    window_stage_transition_weights: dict[tuple[int, int], float] = field(default_factory=dict)
    window_stage_cross_data_mb: dict[tuple[int, int], float] = field(default_factory=dict)
    window_stage_transition_data_mb: dict[tuple[int, int], float] = field(default_factory=dict)
    window_stage_used_nodes: dict[tuple[int, int], set[int]] = field(default_factory=dict)
    window_stage_node_weights: dict[tuple[int, int], dict[int, float]] = field(default_factory=dict)
    window_stage_node_latency_samples: dict[
        tuple[int, int], dict[int, list[tuple[float, float]]]
    ] = field(default_factory=dict)
    window_stage_node_cross_transitions: dict[tuple[int, int, int], float] = field(default_factory=dict)
    window_stage_node_transition_weights: dict[tuple[int, int, int], float] = field(default_factory=dict)
    window_stage_node_cross_data_mb: dict[tuple[int, int, int], float] = field(default_factory=dict)
    window_stage_node_transition_data_mb: dict[tuple[int, int, int], float] = field(default_factory=dict)
    window_stage_node_counterfactual_values: dict[tuple[int, int, int], float] = field(
        default_factory=dict
    )
    window_stage_node_counterfactual_weights: dict[tuple[int, int, int], float] = field(
        default_factory=dict
    )
    window_replica_ablation_values: dict[tuple[int, int, int], float] = field(default_factory=dict)
    window_stop_ablation_value: float = 0.0
    window_replica_ablation_done: bool = False
    window_replica_ablation_samples: int = 0
    slow_reward_scale: float = 1.0
    slow_tail_latency_coef: float = 0.35
    slow_colocation_coef: float = 0.05
    slow_deployment_memory_coef: float = 0.03
    slow_deployment_storage_coef: float = 0.01
    slow_migration_coef: float = 0.0
    slow_idle_replica_coef: float = 0.05
    slow_count_unused_replica_coef: float = 0.0
    slow_placement_idle_coef: float = 0.02
    slow_placement_compute_coef: float = 0.20
    slow_count_shortage_coef: float = 0.25
    slow_count_latency_coef: float = 1.0
    slow_deadline_violation_coef: float = 0.10
    slow_shared_return_coef: float = 0.0
    slow_counterfactual_credit_coef: float = 0.0
    window_deployment_memory_fraction: float = 0.0
    window_deployment_storage_fraction: float = 0.0
    window_migration_fraction: float = 0.0
    last_slow_window_metrics: dict[str, float] = field(default_factory=dict)

    @classmethod
    def from_env(
        cls,
        env: EdgeComputingEnv,
        device: str = "cpu",
        replicas_per_stage: int = 5,
        slow_lr: float = 3e-4,
        slow_count_lr: float = 2e-4,
        slow_stage_lr: float | None = None,
        slow_placement_lr: float = 1.5e-4,
        fast_lr: float = 2e-4,
        slow_k_epochs: int = 3,
        slow_stage_k_epochs: int | None = None,
        slow_placement_k_epochs: int | None = None,
        fast_k_epochs: int = 4,
        slow_entropy_coef: float = 0.001,
        slow_count_entropy_coef: float | None = None,
        slow_placement_entropy_coef: float | None = 0.005,
        slow_placement_entropy_final_coef: float | None = 0.0035,
        slow_placement_entropy_hold_updates: int = 64,
        slow_placement_entropy_decay_updates: int = 64,
        slow_placement_entropy_target: float | None = 1.8,
        slow_placement_entropy_max_coef: float = 0.05,
        slow_placement_entropy_adaptation_rate: float = 2e-3,
        slow_count_global_advantage_coef: float = 0.25,
        slow_placement_global_advantage_coef: float = 0.35,
        slow_placement_global_attribution_coef: float = 0.50,
        slow_global_advantage_ev_full: float = 0.20,
        fast_entropy_coef: float = 0.001,
        fast_entropy_target: float | None = 0.7,
        fast_entropy_max_coef: float = 0.03,
        fast_entropy_adaptation_rate: float = 2e-3,
        fast_entropy_normalized_control: bool = False,
        slow_value_coef: float = 0.5,
        slow_count_value_coef: float = 0.0,
        slow_critic_lr: float | None = 5e-4,
        slow_critic_k_epochs: int = 8,
        slow_critic_replay_windows: int = 96,
        slow_critic_replay_decay: float = 0.90,
        slow_critic_holdout_windows: int = 12,
        slow_critic_holdout_episodes: int = 2,
        slow_critic_gradient_clip: float = 5.0,
        slow_window_gamma: float = 0.95,
        fast_value_coef: float = 0.5,
        slow_target_kl: float | None = 0.03,
        slow_count_target_kl: float | None = 0.015,
        slow_placement_target_kl: float | None = 0.015,
        fast_target_kl: float | None = 0.015,
        slow_minibatch_size: int = 2048,
        fast_minibatch_size: int = 512,
        fast_policy_kind: str = "gat_node_scorer",
        fast_chain_context: str = "legacy",
        fast_reservation_microbatch_size: int = 16,
        fast_load_balanced_updates: bool = True,
        fast_load_group_weights: tuple[float, ...] | None = None,
        fast_full_batch_kl_stop: bool = True,
        fast_update_chunks: int = 1,
        fast_independent_critic: bool = False,
        slow_reward_scale: float = 1.0,
        slow_tail_latency_coef: float = 0.35,
        slow_colocation_coef: float = 0.05,
        slow_deployment_memory_coef: float = 0.03,
        slow_deployment_storage_coef: float = 0.01,
        slow_migration_coef: float = 0.0,
        slow_idle_replica_coef: float = 0.05,
        slow_count_unused_replica_coef: float = 0.0,
        slow_placement_idle_coef: float = 0.02,
        slow_placement_compute_coef: float = 0.20,
        slow_count_shortage_coef: float = 0.25,
        slow_count_latency_coef: float = 1.0,
        slow_deadline_violation_coef: float = 0.10,
        slow_shared_return_coef: float = 0.0,
        slow_deterministic_count_mode: str = "expected",
        slow_allocation_mode: str = "legacy-factorized",
        slow_quota_decode: str = "auto",
        slow_counterfactual_credit_coef: float = 0.0,
        training_repair: str = "legacy",
        slow_team_value_coef: float = 0.5,
        slow_deployment_context: str = "legacy",
        slow_learning_repair: str = "none",
    ) -> "HierarchicalPPOAgent":
        if training_repair not in {"legacy", "batch-credit-v1"}:
            raise ValueError("unknown training repair version")
        repair = training_repair == "batch-credit-v1"
        # Unresolved parser metadata in legacy adapters is not authority to
        # silently change architecture. The training entry point resolves auto.
        if slow_deployment_context == "auto":
            slow_deployment_context = "legacy"
        if slow_learning_repair == "auto":
            # Only the Proposed training entry point resolves fresh-run auto.
            # Legacy/MSO/evaluation adapters may carry unresolved parser args.
            slow_learning_repair = "none"
        return cls(
            slow_agent=SlowDeploymentPPOAgent(
                num_nodes=env.config.num_edge_nodes,
                num_service_types=env.config.num_service_types,
                max_service_stages=env.config.max_service_stages,
                replicas_per_stage=replicas_per_stage,
                lr=slow_lr,
                count_lr=slow_count_lr,
                stage_lr=slow_stage_lr,
                placement_lr=slow_placement_lr,
                k_epochs=slow_k_epochs,
                stage_k_epochs=slow_stage_k_epochs,
                placement_k_epochs=slow_placement_k_epochs,
                entropy_coef=slow_entropy_coef,
                count_entropy_coef=slow_count_entropy_coef,
                placement_entropy_coef=slow_placement_entropy_coef,
                placement_entropy_final_coef=slow_placement_entropy_final_coef,
                placement_entropy_hold_updates=slow_placement_entropy_hold_updates,
                placement_entropy_decay_updates=slow_placement_entropy_decay_updates,
                placement_entropy_target=slow_placement_entropy_target,
                placement_entropy_max_coef=slow_placement_entropy_max_coef,
                placement_entropy_adaptation_rate=slow_placement_entropy_adaptation_rate,
                count_global_advantage_coef=slow_count_global_advantage_coef,
                placement_global_advantage_coef=slow_placement_global_advantage_coef,
                placement_global_attribution_coef=slow_placement_global_attribution_coef,
                global_advantage_ev_full=slow_global_advantage_ev_full,
                value_coef=slow_value_coef,
                count_value_coef=slow_count_value_coef,
                critic_lr=slow_critic_lr,
                critic_k_epochs=slow_critic_k_epochs,
                critic_replay_windows=slow_critic_replay_windows,
                critic_replay_decay=slow_critic_replay_decay,
                critic_holdout_windows=slow_critic_holdout_windows,
                critic_holdout_episodes=slow_critic_holdout_episodes,
                critic_gradient_clip=slow_critic_gradient_clip,
                window_gamma=slow_window_gamma,
                target_kl=slow_target_kl,
                count_target_kl=slow_count_target_kl,
                placement_target_kl=slow_placement_target_kl,
                minibatch_size=slow_minibatch_size,
                tail_latency_coef=slow_tail_latency_coef,
                deterministic_count_mode=slow_deterministic_count_mode,
                allocation_mode=slow_allocation_mode,
                quota_decode=slow_quota_decode,
                counterfactual_credit_coef=slow_counterfactual_credit_coef,
                cost_context=repair,
                team_window_credit=repair,
                team_value_coef=slow_team_value_coef,
                deployment_context=slow_deployment_context,
                learning_repair=slow_learning_repair,
                device=device,
            ),
            fast_agent=FastSchedulingPPOAgent(
                num_nodes=env.config.num_edge_nodes,
                max_service_stages=env.config.max_service_stages,
                policy_kind=fast_policy_kind,
                chain_context=fast_chain_context,
                lr=fast_lr,
                k_epochs=fast_k_epochs,
                entropy_coef=fast_entropy_coef,
                entropy_target=fast_entropy_target,
                entropy_max_coef=fast_entropy_max_coef,
                entropy_adaptation_rate=fast_entropy_adaptation_rate,
                entropy_normalized_control=fast_entropy_normalized_control,
                value_coef=fast_value_coef,
                target_kl=fast_target_kl,
                minibatch_size=fast_minibatch_size,
                reservation_microbatch_size=fast_reservation_microbatch_size,
                load_balanced_updates=fast_load_balanced_updates,
                load_group_weights=fast_load_group_weights,
                full_batch_kl_stop=fast_full_batch_kl_stop,
                batch_credit=repair,
                update_chunks=fast_update_chunks,
                independent_critic=fast_independent_critic,
                device=device,
            ),
            slow_reward_scale=slow_reward_scale,
            slow_tail_latency_coef=slow_tail_latency_coef,
            slow_colocation_coef=slow_colocation_coef,
            slow_deployment_memory_coef=slow_deployment_memory_coef,
            slow_deployment_storage_coef=slow_deployment_storage_coef,
            slow_migration_coef=slow_migration_coef,
            slow_idle_replica_coef=slow_idle_replica_coef,
            slow_count_unused_replica_coef=slow_count_unused_replica_coef,
            slow_placement_idle_coef=slow_placement_idle_coef,
            slow_placement_compute_coef=slow_placement_compute_coef,
            slow_count_shortage_coef=slow_count_shortage_coef,
            slow_count_latency_coef=slow_count_latency_coef,
            slow_deadline_violation_coef=slow_deadline_violation_coef,
            slow_shared_return_coef=slow_shared_return_coef,
            slow_counterfactual_credit_coef=slow_counterfactual_credit_coef,
        )

    def maybe_update_deployment(self, env: EdgeComputingEnv, deterministic: bool = False, record: bool = True) -> None:
        if not env.needs_deployment_update:
            return
        if record:
            self.flush_slow_window_reward(done=False, env=env)
        deployment = self.slow_agent.plan_deployment(env, deterministic=deterministic, record=record)
        migration_count = env.apply_deployment(deployment)
        if record:
            memory_fraction, storage_fraction = self._deployment_resource_fractions(env)
            assert env.scenario is not None
            stage_count = sum(len(service.stages) for service in env.scenario.services)
            possible_placements = max(stage_count * env.config.num_edge_nodes, 1)
            self.window_deployment_memory_fraction = memory_fraction
            self.window_deployment_storage_fraction = storage_fraction
            self.window_migration_fraction = float(migration_count / possible_placements)

    def observe_replica_ablation(self, env: EdgeComputingEnv, requests: list[TaskRequest]) -> None:
        """Probe a bounded number of Slow ADD/STOP choices on one identical request tick.

        Both deployments use the frozen deterministic Fast policy and the same
        pre-step load state; KKT is settled jointly. This is a one-tick
        estimate, not a full-window counterfactual trajectory.
        """
        if (
            self.window_replica_ablation_samples <= 0
            or self.window_replica_ablation_done
            or not requests
            or env.deployment is None
            or env.scenario is None
            or self.slow_agent.pending_window_id is None
        ):
            return
        fast = self.fast_agent
        deployment = env.deployment

        def latency() -> float:
            fast._workload_cache_key = None
            fast._workload_cache = None
            try:
                schedules = fast.schedule_batch(env, requests, deterministic=True, record=False)
                infos = env.evaluate_batch_schedules(requests, schedules)
                if not all(bool(info["valid"]) for info in infos):
                    return float("inf")
                weights = np.asarray([float(request.request_count) for request in requests])
                return float(np.average([float(info["latency_s"]) for info in infos], weights=weights))
            finally:
                # Fast's workload features depend on the temporary deployment.
                fast._workload_cache_key = None
                fast._workload_cache = None

        baseline = latency()
        if not np.isfinite(baseline):
            return
        if self.slow_agent.allocation_mode in {
            "budget-incremental",
            "budget-continuous-v2",
        }:
            pending = self.slow_agent.pending_stage_keys
            nodes = self.slow_agent.pending_stage_node_ids
        else:
            pending = self.slow_agent.pending_count_stage_keys
            nodes = self.slow_agent.pending_count_node_ids
        candidates = sorted(set(
            (service, stage, int(node))
            for (service, stage), node in zip(pending, nodes)
            if node is not None and int(deployment[service, stage].sum()) > 1
        ))
        if candidates:
            windows_per_episode = max(
                int(np.ceil(env.config.episode_minutes / env.config.deployment_interval_minutes)),
                1,
            )
            global_window = (
                self.slow_agent.critic_episode_index * windows_per_episode
                + int(env.current_time_minute // env.config.deployment_interval_minutes)
            )
            # Rotate across *episodes* too: pending_window_id restarts after
            # each optimizer update, which would repeatedly probe early IDs.
            offset = (global_window * self.window_replica_ablation_samples) % len(candidates)
            selected = (candidates[offset:] + candidates[:offset])[:self.window_replica_ablation_samples]
            for service, stage, node in selected:
                deployment[service, stage, node] = False
                try:
                    without = latency()
                finally:
                    deployment[service, stage, node] = True
                if np.isfinite(without):
                    # Positive: the added replica lowered jointly settled latency.
                    self.window_replica_ablation_values[service, stage, node] = without - baseline

        if (-1, -1) in pending:
            memory = env.service_memory_capacities().copy()
            storage = env.service_storage_capacities().copy()
            for service in env.scenario.services:
                for stage in service.stages:
                    placed = deployment[service.service_id, stage.stage_id]
                    memory -= placed * stage.memory_gb
                    storage -= placed * stage.storage_gb
            additions = []
            node_demand = self.slow_agent._node_service_demand(env)
            service_demand = node_demand.sum(axis=0)
            for service in env.scenario.services:
                for stage in service.stages:
                    available = np.flatnonzero(
                        ~deployment[service.service_id, stage.stage_id]
                        & (memory + 1e-9 >= stage.memory_gb)
                        & (storage + 1e-9 >= stage.storage_gb)
                    )
                    if available.size:
                        additions.append(
                            (-float(service_demand[service.service_id]), service.service_id, stage.stage_id)
                        )
            best_added = float("inf")
            for _, service, stage in sorted(additions)[:self.window_replica_ablation_samples]:
                mask = (
                    ~deployment[service, stage]
                    & (memory + 1e-9 >= env.scenario.services[service].stages[stage].memory_gb)
                    & (storage + 1e-9 >= env.scenario.services[service].stages[stage].storage_gb)
                )
                state = self.slow_agent._build_state(
                    env,
                    node_demand,
                    memory,
                    storage,
                    service,
                    stage,
                    int(deployment[service, stage].sum()),
                    planned_deployment=deployment,
                )
                node, _, _ = self.slow_agent.placement_ppo.act(state, mask, deterministic=True)
                node = int(node)
                if not mask[node]:
                    node = int(np.flatnonzero(mask)[0])
                deployment[service, stage, node] = True
                try:
                    best_added = min(best_added, latency())
                finally:
                    deployment[service, stage, node] = False
            if np.isfinite(best_added):
                # Positive: stopping beat each probed feasible addition.
                self.window_stop_ablation_value = best_added - baseline

        self.window_replica_ablation_done = True

    def reset_episode_context(self) -> None:
        """Drop feedback that belongs to a completed independent episode.

        PPO buffers intentionally remain intact because one optimizer update
        batches several ten-minute episodes.
        """

        self.slow_agent.last_window_feedback = {}
        self.slow_agent.last_route_history = {}
        self.window_route_history = None
        self.last_slow_window_metrics = {}
        self.fast_agent.pending_kkt_stage_costs.clear()
        clear_batch_context = getattr(
            self.fast_agent,
            "clear_batch_reward_context",
            None,
        )
        if clear_batch_context is not None:
            clear_batch_context()

    def act(self, env: EdgeComputingEnv, deterministic: bool = False, record: bool = True) -> list[int]:
        self.maybe_update_deployment(env, deterministic=deterministic, record=record)
        return self.fast_agent.schedule(env, deterministic=deterministic, record=record)

    def act_batch(
        self,
        env: EdgeComputingEnv,
        deterministic: bool = False,
        record: bool = True,
    ) -> list[list[int]]:
        self.maybe_update_deployment(env, deterministic=deterministic, record=record)
        return self.fast_agent.schedule_batch(
            env,
            list(env.current_requests),
            deterministic=deterministic,
            record=record,
        )

    def observe_step_reward(
        self,
        reward: float,
        stage_count: int,
        done: bool,
        weight: float = 1.0,
        fast_stage_rewards: list[float] | None = None,
        slow_reward: float | None = None,
        latency_s: float | None = None,
        penalty_latency_s: float | None = None,
        deadline_s: float | None = None,
        invalid: bool = False,
        max_node_compute_load: float | None = None,
        max_link_load: float | None = None,
        cross_stage_transitions: float = 0.0,
        stage_transitions: float = 0.0,
        stage_transition_data_mb: list[float] | tuple[float, ...] | None = None,
        service_id: int | None = None,
        stage_nodes: list[int] | tuple[int, ...] | None = None,
        slow_stage_costs: list[float] | None = None,
        settlement_info: dict | None = None,
        slow_stage_marginal_values: list[float] | None = None,
        env: EdgeComputingEnv | None = None,
        record_fast: bool = True,
        record_slow: bool = True,
        fast_batch_end: bool | None = None,
        fast_multiplicity: float = 1.0,
    ) -> None:
        if record_fast:
            if fast_stage_rewards is None:
                if self.fast_agent.batch_credit:
                    raise ValueError("repaired Fast requires exact KKT incremental stage rewards")
                self.fast_agent.assign_last_schedule_reward(reward, stage_count, done, weight=weight)
            else:
                if len(fast_stage_rewards) != stage_count:
                    raise ValueError("fast_stage_rewards must match stage_count")
                if self.fast_agent.batch_credit:
                    self.fast_agent.assign_schedule_rewards(
                        fast_stage_rewards, done=done, weight=weight,
                        batch_end=fast_batch_end, multiplicity=fast_multiplicity)
                else:
                    self.fast_agent.assign_schedule_rewards(fast_stage_rewards, done=done, weight=weight)
        if not record_slow:
            return
        if self.slow_agent.tail_reallocation and settlement_info is not None and service_id is not None and stage_nodes is not None:
            if self.window_route_history is None:
                self.window_route_history = SlowRouteHistory(self.slow_agent.num_nodes)
            self.window_route_history.add(service_id,stage_nodes,settlement_info,weight)
        self.window_reward += (reward if slow_reward is None else slow_reward) * weight
        self.window_steps += weight
        if latency_s is not None:
            self.window_latency_samples.append((float(latency_s), float(weight)))
            self.window_penalty_latency_sum += float(penalty_latency_s or 0.0) * weight
            self.window_deadline_violations += float(
                bool(deadline_s is not None and float(latency_s) > float(deadline_s))
            ) * weight
            self.window_invalid_actions += float(bool(invalid)) * weight
            if max_node_compute_load is not None:
                self.window_max_node_compute_load = max(self.window_max_node_compute_load, float(max_node_compute_load))
            if max_link_load is not None:
                self.window_max_link_load = max(self.window_max_link_load, float(max_link_load))
        self.window_cross_stage_transitions += max(float(cross_stage_transitions), 0.0)
        self.window_stage_transitions += max(float(stage_transitions), 0.0)
        if service_id is not None and stage_nodes is not None and slow_stage_costs is not None:
            if len(stage_nodes) != len(slow_stage_costs):
                raise ValueError("slow_stage_costs must match stage_nodes")
            if slow_stage_marginal_values is not None and len(stage_nodes) != len(
                slow_stage_marginal_values
            ):
                raise ValueError("slow_stage_marginal_values must match stage_nodes")
            violated = float(bool(deadline_s is not None and latency_s is not None and latency_s > deadline_s))
            for stage_id, (node_id, stage_cost) in enumerate(zip(stage_nodes, slow_stage_costs)):
                stage_key = (int(service_id), int(stage_id))
                self.window_stage_latency_samples.setdefault(stage_key, []).append((float(stage_cost), float(weight)))
                self.window_stage_deadline_violations[stage_key] = (
                    self.window_stage_deadline_violations.get(stage_key, 0.0) + violated * weight
                )
                self.window_stage_weights[stage_key] = self.window_stage_weights.get(stage_key, 0.0) + weight
                self.window_stage_used_nodes.setdefault(stage_key, set()).add(int(node_id))
                node_weights = self.window_stage_node_weights.setdefault(stage_key, {})
                node_weights[int(node_id)] = node_weights.get(int(node_id), 0.0) + float(weight)
                node_samples = self.window_stage_node_latency_samples.setdefault(stage_key, {})
                node_samples.setdefault(int(node_id), []).append((float(stage_cost), float(weight)))
                if slow_stage_marginal_values is not None:
                    node_key = (int(service_id), int(stage_id), int(node_id))
                    self.window_stage_node_counterfactual_values[node_key] = (
                        self.window_stage_node_counterfactual_values.get(node_key, 0.0)
                        + float(slow_stage_marginal_values[stage_id]) * float(weight)
                    )
                    self.window_stage_node_counterfactual_weights[node_key] = (
                        self.window_stage_node_counterfactual_weights.get(node_key, 0.0)
                        + float(weight)
                    )
            # Give the placement actions that own each adjacent pair a local
            # cross-node credit.  The previous global window penalty never
            # reached factorized Placement returns, so the actor could not
            # learn colocation even though the diagnostic reported it.
            transition_data = list(stage_transition_data_mb or [])
            if transition_data and len(transition_data) != max(len(stage_nodes) - 1, 0):
                raise ValueError("stage_transition_data_mb must match adjacent stage transitions")
            for transition_id in range(1, len(stage_nodes)):
                crossed = float(int(stage_nodes[transition_id - 1]) != int(stage_nodes[transition_id]))
                data_mb = float(transition_data[transition_id - 1]) if transition_data else 1.0
                weighted_data = max(data_mb, 0.0) * float(weight)
                self.window_cross_stage_data_mb += crossed * weighted_data
                self.window_total_transition_data_mb += weighted_data
                for endpoint_stage_id in (transition_id - 1, transition_id):
                    stage_key = (int(service_id), int(endpoint_stage_id))
                    endpoint_node_id = int(stage_nodes[endpoint_stage_id])
                    self.window_stage_cross_transitions[stage_key] = (
                        self.window_stage_cross_transitions.get(stage_key, 0.0) + crossed * float(weight)
                    )
                    self.window_stage_transition_weights[stage_key] = (
                        self.window_stage_transition_weights.get(stage_key, 0.0) + float(weight)
                    )
                    self.window_stage_cross_data_mb[stage_key] = (
                        self.window_stage_cross_data_mb.get(stage_key, 0.0)
                        + crossed * weighted_data
                    )
                    self.window_stage_transition_data_mb[stage_key] = (
                        self.window_stage_transition_data_mb.get(stage_key, 0.0)
                        + weighted_data
                    )
                    node_key = (stage_key[0], stage_key[1], endpoint_node_id)
                    self.window_stage_node_cross_transitions[node_key] = (
                        self.window_stage_node_cross_transitions.get(node_key, 0.0)
                        + crossed * float(weight)
                    )
                    self.window_stage_node_transition_weights[node_key] = (
                        self.window_stage_node_transition_weights.get(node_key, 0.0)
                        + float(weight)
                    )
                    self.window_stage_node_cross_data_mb[node_key] = (
                        self.window_stage_node_cross_data_mb.get(node_key, 0.0)
                        + crossed * weighted_data
                    )
                    self.window_stage_node_transition_data_mb[node_key] = (
                        self.window_stage_node_transition_data_mb.get(node_key, 0.0)
                        + weighted_data
                    )
        if done:
            self.flush_slow_window_reward(done=True, env=env)

    def flush_slow_window_reward(self, done: bool, env: EdgeComputingEnv | None = None) -> None:
        total_weight = float(sum(weight for _, weight in self.window_latency_samples))
        if total_weight > 0.0:
            mean_latency = float(
                sum(latency * weight for latency, weight in self.window_latency_samples) / total_weight
            )
            p95_latency = _weighted_percentile(self.window_latency_samples, 95.0)
            tail_latency = (
                (1.0 - self.slow_tail_latency_coef) * mean_latency
                + self.slow_tail_latency_coef * p95_latency
            )
            latency_return = -self.slow_reward_scale * tail_latency
            feedback = {
                "avg_latency_s": mean_latency,
                "p95_latency_s": p95_latency,
                "avg_penalty_latency_s": self.window_penalty_latency_sum / total_weight,
                "deadline_violation_rate": self.window_deadline_violations / total_weight,
                "invalid_action_rate": self.window_invalid_actions / total_weight,
                "max_node_compute_load": self.window_max_node_compute_load,
                "max_link_load": self.window_max_link_load,
                "deployment_memory_fraction": self.window_deployment_memory_fraction,
                "deployment_storage_fraction": self.window_deployment_storage_fraction,
            }
        else:
            latency_return = self.window_reward / float(self.window_steps) if self.window_steps > 0 else 0.0
            feedback = {}
        cross_stage_rate = self.window_cross_stage_transitions / max(self.window_stage_transitions, 1e-9)
        data_weighted_cross_stage_rate = self.window_cross_stage_data_mb / max(
            self.window_total_transition_data_mb,
            1e-9,
        )
        colocation_rate_for_credit = (
            data_weighted_cross_stage_rate
            if self.window_total_transition_data_mb > 0.0
            else cross_stage_rate
        )
        colocation_cost = self.slow_colocation_coef * colocation_rate_for_credit
        if total_weight > 0.0:
            feedback.update(
                {
                    "cross_stage_transition_rate": cross_stage_rate,
                    "colocation_rate": 1.0 - cross_stage_rate,
                    "data_weighted_cross_stage_rate": data_weighted_cross_stage_rate,
                }
            )
        deployment_memory_cost = self.slow_deployment_memory_coef * self.window_deployment_memory_fraction
        deployment_storage_cost = self.slow_deployment_storage_coef * self.window_deployment_storage_fraction
        migration_cost = self.slow_migration_coef * self.window_migration_fraction
        deadline_cost = self.slow_deadline_violation_coef * float(feedback.get("deadline_violation_rate", 0.0))
        operating_cost = self.slow_reward_scale * (
            deployment_memory_cost + deployment_storage_cost + migration_cost + colocation_cost + deadline_cost
        )
        window_return = latency_return - operating_cost
        count_stage_returns, placement_stage_returns, count_credit_metrics = self._factorized_stage_returns(env)
        shared_return_credit = self.slow_shared_return_coef * window_return
        if shared_return_credit != 0.0:
            count_stage_returns = {
                key: value + shared_return_credit
                for key, value in count_stage_returns.items()
            }
            placement_stage_returns = {
                key: value + shared_return_credit
                for key, value in placement_stage_returns.items()
            }
        incremental_add_actions = (
            len(self.slow_agent.pending_stage_node_ids)
            if self.slow_agent.allocation_mode in {
                "budget-incremental",
                "budget-continuous-v2",
            }
            else sum(
                node_id is not None for node_id in self.slow_agent.pending_count_node_ids
            )
        )
        incremental_stop_actions = sum(
            stage_key == (-1, -1)
            for stage_key in self.slow_agent.pending_count_stage_keys
        )
        if self.slow_agent.allocation_mode in {"stage-budget-v3", "stage-budget-v4", "stage-budget-v5", "stage-budget-v6"}:
            incremental_add_actions = self.slow_agent.pending_budget_requested_replicas
        budget_fraction = 0.0
        budget_feasible_capacity = 0.0
        budget_replica_slot_upper_bound = 0.0
        budget_extra_replicas = 0.0
        budget_available_memory_gb = 0.0
        budget_available_storage_gb = 0.0
        budget_target_memory_gb = 0.0
        budget_target_storage_gb = 0.0
        budget_used_memory_gb = 0.0
        budget_used_storage_gb = 0.0
        if (
            self.slow_agent.allocation_mode in {
                "budget-incremental",
                "budget-continuous-v2",
                "stage-budget-v3",
                "stage-budget-v4",
                "stage-budget-v5",
            "stage-budget-v6",
            }
            and self.slow_agent.pending_count_indices
        ):
            budget_fraction = float(self.slow_agent.pending_budget_fraction)
            budget_feasible_capacity = float(
                self.slow_agent.pending_budget_feasible_capacity
            )
            budget_replica_slot_upper_bound = float(
                self.slow_agent.pending_budget_replica_slot_upper_bound
            )
            budget_extra_replicas = float(
                self.slow_agent.pending_budget_requested_replicas
            )
            budget_available_memory_gb = float(
                self.slow_agent.pending_budget_available_memory_gb
            )
            budget_available_storage_gb = float(
                self.slow_agent.pending_budget_available_storage_gb
            )
            budget_target_memory_gb = float(
                self.slow_agent.pending_budget_target_memory_gb
            )
            budget_target_storage_gb = float(
                self.slow_agent.pending_budget_target_storage_gb
            )
            budget_used_memory_gb = float(
                self.slow_agent.pending_budget_used_memory_gb
            )
            budget_used_storage_gb = float(
                self.slow_agent.pending_budget_used_storage_gb
            )
        budget_execution_ratio = (
            float(incremental_add_actions) / budget_extra_replicas
            if budget_extra_replicas > 0.0
            else 1.0
        )
        budget_memory_fill_ratio = (
            budget_used_memory_gb / budget_target_memory_gb
            if budget_target_memory_gb > 0.0
            else 1.0
        )
        budget_storage_fill_ratio = (
            budget_used_storage_gb / budget_target_storage_gb
            if budget_target_storage_gb > 0.0
            else 1.0
        )
        self.slow_agent.assign_pending_reward(
            window_return,
            done=done,
            count_stage_returns=count_stage_returns,
            placement_stage_returns=placement_stage_returns,
        )
        self.slow_agent.last_window_feedback = feedback
        if self.slow_agent.tail_reallocation:
            self.slow_agent.last_route_history = self.window_route_history.snapshot() if self.window_route_history is not None else {}
            self.window_route_history = None
        self.last_slow_window_metrics = {
            "slow_window_return": float(window_return),
            "slow_window_latency_return": float(latency_return),
            "slow_window_avg_latency": float(feedback.get("avg_latency_s", 0.0)),
            "slow_window_p95_latency": float(feedback.get("p95_latency_s", 0.0)),
            "slow_tail_latency_cost": float(
                -latency_return / max(self.slow_reward_scale, 1e-9)
                if total_weight > 0.0
                else 0.0
            ),
            "slow_colocation_credit_coef": float(self.slow_colocation_coef),
            "slow_colocation_cost": float(self.slow_reward_scale * colocation_cost),
            "slow_cross_stage_transition_rate": float(cross_stage_rate),
            "slow_colocation_rate": float(1.0 - cross_stage_rate),
            "slow_data_weighted_cross_stage_rate": float(data_weighted_cross_stage_rate),
            "slow_shared_return_credit": float(shared_return_credit),
            "slow_incremental_add_actions": float(incremental_add_actions),
            "slow_incremental_stop_actions": float(incremental_stop_actions),
            "slow_budget_fraction": budget_fraction,
            "slow_budget_feasible_capacity": budget_feasible_capacity,
            "slow_budget_replica_slot_upper_bound": budget_replica_slot_upper_bound,
            "slow_budget_extra_replicas": budget_extra_replicas,
            "slow_budget_allocated_replicas": float(incremental_add_actions),
            "slow_budget_execution_ratio": budget_execution_ratio,
            "slow_budget_available_memory_gb": budget_available_memory_gb,
            "slow_budget_available_storage_gb": budget_available_storage_gb,
            "slow_budget_target_memory_gb": budget_target_memory_gb,
            "slow_budget_target_storage_gb": budget_target_storage_gb,
            "slow_budget_used_memory_gb": budget_used_memory_gb,
            "slow_budget_used_storage_gb": budget_used_storage_gb,
            "slow_budget_memory_fill_ratio": budget_memory_fill_ratio,
            "slow_budget_storage_fill_ratio": budget_storage_fill_ratio,
            "slow_replica_ablation_samples": float(len(self.window_replica_ablation_values)),
            "slow_replica_ablation_mean_s": (
                float(np.mean(list(self.window_replica_ablation_values.values())))
                if self.window_replica_ablation_values else 0.0
            ),
            "slow_stop_ablation_value_s": float(self.window_stop_ablation_value),
            "slow_deployment_memory_cost": float(self.slow_reward_scale * deployment_memory_cost),
            "slow_deployment_storage_cost": float(self.slow_reward_scale * deployment_storage_cost),
            "slow_migration_cost": float(self.slow_reward_scale * migration_cost),
            "slow_deadline_violation_cost": float(self.slow_reward_scale * deadline_cost),
            "slow_factorized_stage_return_mean": (
                float(np.mean([value for key, value in placement_stage_returns.items() if len(key) == 2]))
                if placement_stage_returns
                else 0.0
            ),
            "slow_factorized_stage_return_std": (
                float(np.std([value for key, value in placement_stage_returns.items() if len(key) == 2]))
                if placement_stage_returns
                else 0.0
            ),
            "slow_factorized_count_return_mean": (
                float(np.mean(list(count_stage_returns.values()))) if count_stage_returns else 0.0
            ),
            "slow_factorized_count_return_std": (
                float(np.std(list(count_stage_returns.values()))) if count_stage_returns else 0.0
            ),
            **count_credit_metrics,
            "slow_deployment_memory_fraction": float(self.window_deployment_memory_fraction),
            "slow_deployment_storage_fraction": float(self.window_deployment_storage_fraction),
            "slow_migration_fraction": float(self.window_migration_fraction),
        }
        self.window_reward = 0.0
        self.window_steps = 0
        self.window_latency_samples.clear()
        self.window_penalty_latency_sum = 0.0
        self.window_deadline_violations = 0.0
        self.window_invalid_actions = 0.0
        self.window_max_node_compute_load = 0.0
        self.window_max_link_load = 0.0
        self.window_cross_stage_transitions = 0.0
        self.window_stage_transitions = 0.0
        self.window_cross_stage_data_mb = 0.0
        self.window_total_transition_data_mb = 0.0
        self.window_stage_latency_samples.clear()
        self.window_stage_deadline_violations.clear()
        self.window_stage_weights.clear()
        self.window_stage_cross_transitions.clear()
        self.window_stage_transition_weights.clear()
        self.window_stage_cross_data_mb.clear()
        self.window_stage_transition_data_mb.clear()
        self.window_stage_used_nodes.clear()
        self.window_stage_node_weights.clear()
        self.window_stage_node_latency_samples.clear()
        self.window_stage_node_cross_transitions.clear()
        self.window_stage_node_transition_weights.clear()
        self.window_stage_node_cross_data_mb.clear()
        self.window_stage_node_transition_data_mb.clear()
        self.window_stage_node_counterfactual_values.clear()
        self.window_stage_node_counterfactual_weights.clear()
        self.window_replica_ablation_values.clear()
        self.window_stop_ablation_value = 0.0
        self.window_replica_ablation_done = False
        self.window_deployment_memory_fraction = 0.0
        self.window_deployment_storage_fraction = 0.0
        self.window_migration_fraction = 0.0

    def _factorized_stage_returns(
        self,
        env: EdgeComputingEnv | None,
    ) -> tuple[dict[tuple[int, ...], float], dict[tuple[int, ...], float], dict[str, float]]:
        """Build distinct Count efficiency and Placement latency returns."""

        if env is None or env.scenario is None or env.deployment is None:
            return {}, {}, {
                "slow_count_effective_replicas_per_stage": 0.0,
                "slow_count_redundant_replica_fraction": 0.0,
                "slow_count_unused_replica_fraction": 0.0,
                "slow_count_unused_replica_cost": 0.0,
                "slow_count_replica_imbalance_fraction": 0.0,
                "slow_count_replica_efficiency_cost": 0.0,
                "slow_placement_node_compute_load": 0.0,
                "slow_placement_node_compute_cost": 0.0,
                "slow_counterfactual_marginal_value": 0.0,
                "slow_counterfactual_samples": 0.0,
                "slow_stage_ablation_covered_stages": 0.0,
                "slow_stage_ablation_credit_actions": 0.0,
                "slow_stage_ablation_credit_fraction": 0.0,
            }
        # Replica-removal probes measure whether another replica of a service
        # stage was useful. That is Stage credit, not node-selection credit.
        # The bounded probe budget is far smaller than the number of Stage
        # actions, so share each measured value with every action for the same
        # service stage. Keep the exact node value where it exists; Placement
        # continues to receive its separate node-local routing credit below.
        stage_ablation_samples: dict[tuple[int, int], list[float]] = {}
        for (service_id, stage_id, _), value in self.window_replica_ablation_values.items():
            stage_ablation_samples.setdefault((service_id, stage_id), []).append(
                float(value)
            )
        stage_ablation_means = {
            stage_key: float(np.mean(values))
            for stage_key, values in stage_ablation_samples.items()
        }
        pending_stage_action_count = len(self.slow_agent.pending_stage_keys)
        stage_ablation_credit_actions = sum(
            stage_key in stage_ablation_means
            for stage_key in self.slow_agent.pending_stage_keys
        )
        memory_capacity = max(float(env.service_memory_capacities().sum()), 1e-9)
        storage_capacity = max(float(env.service_storage_capacities().sum()), 1e-9)
        count_returns: dict[tuple[int, ...], float] = {}
        placement_returns: dict[tuple[int, ...], float] = {}
        effective_replica_counts: list[float] = []
        redundant_replica_fractions: list[float] = []
        unused_replica_fractions: list[float] = []
        replica_imbalance_fractions: list[float] = []
        placement_node_compute_loads: list[float] = []
        counterfactual_values: list[float] = []
        for service in env.scenario.services:
            for stage in service.stages:
                stage_key = (service.service_id, stage.stage_id)
                samples = self.window_stage_latency_samples.get(stage_key, [])
                if not samples:
                    continue
                total_weight = max(float(sum(weight for _, weight in samples)), 1e-9)
                mean_cost = float(sum(cost * weight for cost, weight in samples) / total_weight)
                p95_cost = _weighted_percentile(samples, 95.0)
                tail_cost = (1.0 - self.slow_tail_latency_coef) * mean_cost + self.slow_tail_latency_coef * p95_cost
                placed = env.deployment[service.service_id, stage.stage_id]
                replica_count = int(placed.sum())
                placed_nodes = set(np.flatnonzero(placed).tolist())
                node_weights = self.window_stage_node_weights.get(stage_key, {})
                placed_weights = np.asarray(
                    [max(float(node_weights.get(node_id, 0.0)), 0.0) for node_id in placed_nodes],
                    dtype=np.float64,
                )
                assigned_weight = float(placed_weights.sum())
                if assigned_weight > 0.0:
                    shares = placed_weights / assigned_weight
                    effective_replicas = min(
                        1.0 / max(float(np.square(shares).sum()), 1e-9),
                        float(replica_count),
                    )
                else:
                    effective_replicas = 0.0
                redundant_replica_fraction = 1.0 - effective_replicas / max(float(replica_count), 1.0)
                used_replica_count = sum(
                    float(node_weights.get(node_id, 0.0)) > 0.0
                    for node_id in placed_nodes
                )
                unused_replica_fraction = 1.0 - used_replica_count / max(
                    float(replica_count),
                    1.0,
                )
                # Total redundancy contains two disjoint causes:
                #   unused: deployed nodes that served no sampled traffic;
                #   imbalance: concentration among nodes that did serve it.
                # When the explicit unused coefficient is enabled, charge the
                # disjoint components instead of adding unused on top of total
                # redundancy.  The zero-coefficient branch preserves legacy
                # checkpoint/configuration semantics.
                replica_imbalance_fraction = max(
                    redundant_replica_fraction - unused_replica_fraction,
                    0.0,
                )
                if self.slow_count_unused_replica_coef > 0.0:
                    replica_efficiency_cost = (
                        self.slow_idle_replica_coef * replica_imbalance_fraction
                        + self.slow_count_unused_replica_coef * unused_replica_fraction
                    )
                else:
                    replica_efficiency_cost = (
                        self.slow_idle_replica_coef * redundant_replica_fraction
                    )
                effective_replica_counts.append(effective_replicas)
                redundant_replica_fractions.append(redundant_replica_fraction)
                unused_replica_fractions.append(unused_replica_fraction)
                replica_imbalance_fractions.append(replica_imbalance_fraction)
                memory_fraction = replica_count * float(stage.memory_gb) / memory_capacity
                storage_fraction = replica_count * float(stage.storage_gb) / storage_capacity
                violation_rate = self.window_stage_deadline_violations.get(stage_key, 0.0) / max(
                    self.window_stage_weights.get(stage_key, 0.0), 1e-9
                )
                stage_cross_transition_rate = self.window_stage_cross_transitions.get(stage_key, 0.0) / max(
                    self.window_stage_transition_weights.get(stage_key, 0.0), 1e-9
                )
                stage_transition_data = self.window_stage_transition_data_mb.get(stage_key, 0.0)
                if stage_transition_data > 0.0:
                    stage_cross_transition_rate = self.window_stage_cross_data_mb.get(
                        stage_key,
                        0.0,
                    ) / stage_transition_data
                count_cost = (
                    self.slow_count_latency_coef * tail_cost
                    + self.slow_deployment_memory_coef * memory_fraction
                    + self.slow_deployment_storage_coef * storage_fraction
                    + replica_efficiency_cost
                    + self.slow_count_shortage_coef * violation_rate
                )
                placement_cost = (
                    tail_cost
                    + self.slow_deadline_violation_coef * violation_rate
                    + self.slow_colocation_coef * stage_cross_transition_rate
                )
                count_returns[stage_key] = -self.slow_reward_scale * float(count_cost)
                node_returns: list[float] = []
                node_sample_groups = self.window_stage_node_latency_samples.get(stage_key, {})
                for node_id in placed_nodes:
                    node_key = (service.service_id, stage.stage_id, int(node_id))
                    node_samples = node_sample_groups.get(int(node_id), [])
                    node_weight = float(sum(weight for _, weight in node_samples))
                    if node_weight > 0.0:
                        node_mean_cost = float(
                            sum(cost * weight for cost, weight in node_samples) / node_weight
                        )
                        node_p95_cost = _weighted_percentile(node_samples, 95.0)
                        node_tail_cost = (
                            (1.0 - self.slow_tail_latency_coef) * node_mean_cost
                            + self.slow_tail_latency_coef * node_p95_cost
                        )
                        idle_cost = 0.0
                    else:
                        node_tail_cost = tail_cost
                        idle_cost = self.slow_placement_idle_coef
                    node_transition_weight = self.window_stage_node_transition_weights.get(node_key, 0.0)
                    if node_transition_weight > 0.0:
                        node_cross_rate = self.window_stage_node_cross_transitions.get(node_key, 0.0) / max(
                            node_transition_weight,
                            1e-9,
                        )
                    else:
                        adjacent_stage_ids = [
                            adjacent_stage_id
                            for adjacent_stage_id in (stage.stage_id - 1, stage.stage_id + 1)
                            if 0 <= adjacent_stage_id < len(service.stages)
                        ]
                        node_cross_rate = (
                            float(
                                np.mean(
                                    [
                                        not bool(
                                            env.deployment[
                                                service.service_id,
                                                adjacent_stage_id,
                                                int(node_id),
                                            ]
                                        )
                                        for adjacent_stage_id in adjacent_stage_ids
                                    ]
                                )
                            )
                            if adjacent_stage_ids
                            else 0.0
                        )
                    node_transition_data = self.window_stage_node_transition_data_mb.get(node_key, 0.0)
                    if node_transition_data > 0.0:
                        node_cross_rate = self.window_stage_node_cross_data_mb.get(
                            node_key,
                            0.0,
                        ) / node_transition_data
                    counterfactual_weight = self.window_stage_node_counterfactual_weights.get(
                        node_key,
                        0.0,
                    )
                    marginal_value = (
                        self.window_stage_node_counterfactual_values.get(node_key, 0.0)
                        / counterfactual_weight
                        if counterfactual_weight > 0.0
                        else 0.0
                    )
                    if counterfactual_weight > 0.0:
                        counterfactual_values.append(float(marginal_value))
                    node_cost = (
                        node_tail_cost
                        + self.slow_deadline_violation_coef * violation_rate
                        + self.slow_colocation_coef * node_cross_rate
                        + self.slow_placement_compute_coef * float(env.node_compute_load[int(node_id)])
                        + idle_cost
                    )
                    placement_node_compute_loads.append(float(env.node_compute_load[int(node_id)]))
                    node_return = self.slow_reward_scale * (
                        -float(node_cost)
                        + self.slow_counterfactual_credit_coef * float(marginal_value)
                    )
                    placement_returns[node_key] = node_return
                    node_returns.append(node_return)
                    if self.slow_agent.allocation_mode in {
                        "global-incremental",
                        "budget-incremental",
                        "budget-continuous-v2",
                    }:
                        per_replica_resource_cost = (
                            self.slow_deployment_memory_coef
                            * float(stage.memory_gb)
                            / memory_capacity
                            + self.slow_deployment_storage_coef
                            * float(stage.storage_gb)
                            / storage_capacity
                        )
                        unused_cost = (
                            self.slow_count_unused_replica_coef
                            if node_weight <= 0.0
                            else 0.0
                        )
                        count_marginal_value = (
                            self.window_replica_ablation_values.get(
                                node_key,
                                stage_ablation_means.get(stage_key, 0.0),
                            )
                            if self.window_replica_ablation_samples > 0
                            else float(marginal_value)
                        )
                        count_returns[node_key] = self.slow_reward_scale * (
                            self.slow_counterfactual_credit_coef * count_marginal_value
                            - per_replica_resource_cost
                            - unused_cost
                        )
                placement_returns[stage_key] = (
                    float(np.mean(node_returns))
                    if node_returns
                    else -self.slow_reward_scale * float(placement_cost)
                )
        if self.slow_agent.allocation_mode == "global-incremental":
            # The legacy STOP local credit is zero. With ablation enabled,
            # compare it with the best of a bounded set of feasible additions.
            # The shared window return is added to both action types below.
            count_returns[(-1, -1)] = (
                self.slow_reward_scale * self.slow_counterfactual_credit_coef
                * self.window_stop_ablation_value
                if self.window_replica_ablation_samples > 0 else 0.0
            )
        return count_returns, placement_returns, {
            "slow_count_effective_replicas_per_stage": (
                float(np.mean(effective_replica_counts)) if effective_replica_counts else 0.0
            ),
            "slow_count_redundant_replica_fraction": (
                float(np.mean(redundant_replica_fractions)) if redundant_replica_fractions else 0.0
            ),
            "slow_count_unused_replica_fraction": (
                float(np.mean(unused_replica_fractions)) if unused_replica_fractions else 0.0
            ),
            "slow_count_unused_replica_cost": (
                self.slow_reward_scale
                * self.slow_count_unused_replica_coef
                * (float(np.mean(unused_replica_fractions)) if unused_replica_fractions else 0.0)
            ),
            "slow_count_replica_imbalance_fraction": (
                float(np.mean(replica_imbalance_fractions))
                if replica_imbalance_fractions
                else 0.0
            ),
            "slow_count_replica_efficiency_cost": (
                self.slow_reward_scale
                * (
                    self.slow_idle_replica_coef
                    * (
                        float(np.mean(replica_imbalance_fractions))
                        if replica_imbalance_fractions
                        else 0.0
                    )
                    + self.slow_count_unused_replica_coef
                    * (
                        float(np.mean(unused_replica_fractions))
                        if unused_replica_fractions
                        else 0.0
                    )
                )
                if self.slow_count_unused_replica_coef > 0.0
                else self.slow_reward_scale
                * self.slow_idle_replica_coef
                * (
                    float(np.mean(redundant_replica_fractions))
                    if redundant_replica_fractions
                    else 0.0
                )
            ),
            "slow_placement_node_compute_load": (
                float(np.mean(placement_node_compute_loads)) if placement_node_compute_loads else 0.0
            ),
            "slow_placement_node_compute_cost": (
                self.slow_reward_scale
                * self.slow_placement_compute_coef
                * (float(np.mean(placement_node_compute_loads)) if placement_node_compute_loads else 0.0)
            ),
            "slow_counterfactual_marginal_value": (
                float(np.mean(counterfactual_values)) if counterfactual_values else 0.0
            ),
            "slow_counterfactual_samples": float(len(counterfactual_values)),
            "slow_stage_ablation_covered_stages": float(
                len(stage_ablation_means)
            ),
            "slow_stage_ablation_credit_actions": float(
                stage_ablation_credit_actions
            ),
            "slow_stage_ablation_credit_fraction": (
                float(stage_ablation_credit_actions)
                / float(pending_stage_action_count)
                if pending_stage_action_count > 0
                else 0.0
            ),
        }

    def _deployment_resource_fractions(self, env: EdgeComputingEnv) -> tuple[float, float]:
        assert env.scenario is not None
        assert env.deployment is not None
        memory_used = np.zeros(env.config.num_edge_nodes, dtype=np.float64)
        storage_used = np.zeros(env.config.num_edge_nodes, dtype=np.float64)
        for service in env.scenario.services:
            for stage in service.stages:
                placed = env.deployment[service.service_id, stage.stage_id]
                memory_used += placed * stage.memory_gb
                storage_used += placed * stage.storage_gb
        memory_fraction = float(memory_used.sum() / max(float(env.service_memory_capacities().sum()), 1e-9))
        storage_fraction = float(storage_used.sum() / max(float(env.service_storage_capacities().sum()), 1e-9))
        return memory_fraction, storage_fraction

    def update(self, *, progress_label: str = "", progress_interval_seconds: float = 0.0) -> dict[str, dict[str, float]]:
        return {
            "slow": self.update_slow(
                progress_label=f"{progress_label} slow PPO",
                progress_interval_seconds=progress_interval_seconds,
            ),
            "fast": self.update_fast(
                progress_label=f"{progress_label} fast PPO",
                progress_interval_seconds=progress_interval_seconds,
            ),
        }

    @property
    def completed_slow_windows(self) -> int:
        return len(self.slow_agent.window_returns)

    def update_slow(self, *, progress_label: str = "", progress_interval_seconds: float = 0.0) -> dict[str, float]:
        return self.slow_agent.update(
            progress_label=progress_label,
            progress_interval_seconds=progress_interval_seconds,
        )

    def update_fast(self, *, progress_label: str = "", progress_interval_seconds: float = 0.0) -> dict[str, float]:
        return self.fast_agent.update(
            progress_label=progress_label,
            progress_interval_seconds=progress_interval_seconds,
        )
