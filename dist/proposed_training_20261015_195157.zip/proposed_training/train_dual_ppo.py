from __future__ import annotations

import argparse
import csv
import json
import sys
import time
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
try:
    from tqdm.auto import tqdm
except ImportError:  # pragma: no cover - exercised only when tqdm is absent.
    tqdm = None

from edge_drl.agents.hierarchical import FastGreedyScheduler, SlowGreedyDeploymentPolicy, build_baseline_agent
from edge_drl.agents.drl import HierarchicalPPOAgent
from edge_drl.env.environment import EdgeComputingEnv, EdgeEnvConfig
from edge_drl.env import latency200


PRESSURE_PROFILE_DEFAULTS: dict[str, dict[str, float | str | bool]] = {
    "baseline": {},
    # Keep topology and physical seed fixed while moving the operating point
    # into a moderate MEC stress regime.
    "mec-moderate": {
        "training_design": "trajectory-simultaneous",
        "active_user_ratio": 0.20,
        "active_user_request_rate_per_minute": 1.75,
        "traffic_scale": 1.0,
        "load_multipliers": "0.8,1.1,1.4,1.7",
        "load_sampling_mode": "distribution-random",
        "load_strata": "0.75:0.95,0.95:1.20,1.20:1.50,1.50:1.85",
        "load_stratum_probabilities": "0.20,0.50,0.25,0.05",
        "task_compute_scale": 1.65,
        "task_data_scale": 2.5,
        "node_compute_capacity_scale": 0.65,
        "wired_link_bandwidth_scale": 0.15,
        "service_resource_fraction": 0.25,
        "deadline_scale": 2.75,
    },
    # Validate moderate pressure first; this profile is a bounded stress case
    # rather than a saturation-first experiment.
    "mec-stress": {
        "training_design": "trajectory-simultaneous",
        "active_user_ratio": 0.30,
        "active_user_request_rate_per_minute": 2.0,
        "traffic_scale": 1.0,
        "load_multipliers": "0.8,1.1,1.4,1.7",
        "load_sampling_mode": "distribution-random",
        "load_strata": "0.75:0.95,0.95:1.20,1.20:1.50,1.50:1.85",
        "load_stratum_probabilities": "0.20,0.50,0.25,0.05",
        "task_compute_scale": 2.75,
        "task_data_scale": 4.0,
        "node_compute_capacity_scale": 0.35,
        "wired_link_bandwidth_scale": 0.04,
        "service_resource_fraction": 0.20,
        "deadline_scale": 3.0,
    },
    # Opt-in AI-edge candidate; hardware/payload references and unmeasured
    # effective-compute budgets are separated in docs/LATENCY200_SCENARIO.md.
    "mec-latency200": {
        "training_design": "trajectory-simultaneous",
        "edge_node_profile": latency200.NODE_PROFILE,
        "service_workload_profile": latency200.SERVICE_PROFILE,
        "num_users": 12_000,
        "num_edge_nodes": 32,
        "num_service_types": 10,
        "episode_minutes": 60,
        "deployment_interval_minutes": 10,
        "arrival_profile": "stationary",
        "active_user_ratio": 0.20,
        "active_user_request_rate_per_minute": 1.75,
        "traffic_scale": 1.0,
        "load_multipliers": "0.7,0.9,1.1,1.35",
        "load_sampling_mode": "distribution-random",
        "load_strata": "0.65:0.80,0.80:1.00,1.00:1.20,1.20:1.45",
        "load_stratum_probabilities": "0.20,0.45,0.25,0.10",
        "task_compute_scale": 1.0,
        "task_data_scale": 1.0,
        "node_compute_capacity_scale": 1.0,
        "wired_link_bandwidth_scale": 0.80,
        "topology_k_nearest": 6,
        "service_resource_fraction": 0.60,
        "wireless_uplink_mbps": 300.0,
        "radio_rtt_ms": 10.0,
        "sampled_load_update_mode": "interval-average",
        "network_constraint_mode": "shared-nic",
        "service_calibration_mode": "audited-v1",
        "temporal_sampling_mode": "stratified-jitter",
        "sampling_max_interval_seconds": 15.0,
        # Keep deadline semantics identical to the archived constrained run.
        # Lower physical latency is never manufactured by relaxing deadlines.
        "deadline_scale": 2.75,
    },
    # Preserve the archived constrained scenario without numerical changes.
    "mec-realistic-constrained": {
        "training_design": "trajectory-simultaneous",
        "edge_node_profile": "hardware-constrained",
        "service_workload_profile": "edge-ai-pipelines",
        "active_user_ratio": 0.20,
        "active_user_request_rate_per_minute": 1.75,
        "traffic_scale": 1.0,
        "load_multipliers": "0.7,0.9,1.1,1.35",
        "load_sampling_mode": "distribution-random",
        "load_strata": "0.65:0.80,0.80:1.00,1.00:1.20,1.20:1.45",
        "load_stratum_probabilities": "0.20,0.45,0.25,0.10",
        # The selected service catalogue already contains calibrated per-stage
        # edge-AI demand, so no second global inflation is applied.
        "task_compute_scale": 1.0,
        "task_data_scale": 1.0,
        "node_compute_capacity_scale": 1.0,
        "wired_link_bandwidth_scale": 0.75,
        # Raw hardware memory is far below the legacy 64/128/256 GB tiers.
        # Reserving 60% still leaves a materially smaller service pool while
        # keeping every service stage feasible on at least one node class.
        "service_resource_fraction": 0.60,
        "deadline_scale": 2.75,
    },
}


def apply_pressure_profile(args: argparse.Namespace, argv: list[str] | None = None) -> argparse.Namespace:
    """Apply a reproducible demand/capacity profile without changing topology."""

    profile = PRESSURE_PROFILE_DEFAULTS[args.pressure_profile]
    if not profile:
        return args
    explicit_options = {
        token.split("=", 1)[0]
        for token in (sys.argv[1:] if argv is None else argv)
        if token.startswith("--")
    }
    for field, value in profile.items():
        option = "--" + field.replace("_", "-")
        if (
            field in {"load_strata", "load_stratum_probabilities"}
            and ({"--load-multipliers", "--load-strata"} & explicit_options)
            and option not in explicit_options
        ):
            # Custom anchors should not silently inherit ranges calibrated for
            # the profile's original anchors.
            continue
        if option not in explicit_options:
            setattr(args, field, value)
    return args


def use_deterministic_fast_collection(slow_phase: bool, collection_mode: str) -> bool:
    """Choose Fast sampling semantics while its parameters are frozen for Slow."""

    if collection_mode not in {"stochastic", "deterministic"}:
        raise ValueError("collection_mode must be 'stochastic' or 'deterministic'")
    return bool(slow_phase and collection_mode == "deterministic")


def apply_training_design(
    args: argparse.Namespace,
    argv: list[str] | None = None,
) -> argparse.Namespace:
    """Expand the selected training semantics while preserving explicit overrides."""

    if args.training_design != "trajectory-simultaneous":
        return args
    explicit_options = {
        token.split("=", 1)[0]
        for token in (sys.argv[1:] if argv is None else argv)
        if token.startswith("--")
    }
    defaults = {
        "episode_minutes": 60,
        "joint_training_schedule": "simultaneous",
        "fast_windows_per_update": 12,
        # Fast and Slow learn from the same two complete trajectories.  Their
        # timescale difference is represented by optimizer strength rather
        # than by withholding every other Slow update.
        "slow_windows_per_update": 12,
        "fast_warmup_updates": 0,
        "slow_warmup_updates": 0,
        "slow_count_lr": 1e-4,
        # Count is already moving over the useful resource-budget range. Stage
        # and Placement had much smaller KL and need independent optimization
        # strength instead of inheriting Count's conservative settings.
        "slow_stage_lr": 2e-4,
        "slow_placement_lr": 1e-4,
        "slow_k_epochs": 2,
        "slow_stage_k_epochs": 3,
        "slow_placement_k_epochs": 3,
        "slow_placement_entropy_target": 1.10,
        # Once Placement has collapsed, the old 0.015 ceiling cannot reopen
        # exploration even though the controller is fully saturated.
        "slow_placement_entropy_max_coef": 0.030,
        "slow_placement_entropy_adaptation_rate": 0.004,
        # Cross-stage latency is already present in the end-to-end return.
        # Retain explicit locality credit only as early guidance, then remove
        # the duplicate incentive before it creates compute hot spots.
        "slow_colocation_final_coef": 0.0,
        "slow_colocation_hold_updates": 64,
        "slow_colocation_decay_updates": 96,
        "slow_lr_decay": True,
        # Slow actors see only twelve window decisions per update.  A longer,
        # KL-gated horizon prevents a Fast-dominated plateau from freezing
        # Count and Placement before they have moved appreciably.
        "slow_lr_decay_patience": 40,
        "slow_lr_decay_factor": 0.7,
        "slow_count_min_lr": 5e-5,
        "slow_placement_min_lr": 3.75e-5,
        "slow_lr_max_reductions": 1,
        "slow_lr_kl_floor_fraction": 0.10,
        # Tiny per-update KL does not make cumulative low-entropy drift safe.
        # Permit the Placement LR guard to act after sustained degradation.
        "slow_lr_low_entropy_override": True,
        "fast_entropy_normalized_control": True,
        "fast_entropy_target": 0.18,
        "fast_entropy_max_coef": 0.02,
        # Keep chain-locality guidance through the early Slow-policy movement;
        # the previous 0.20 endpoint coincided with a sharp link-latency rise.
        "fast_counterfactual_credit_final_coef": 0.40,
        "fast_counterfactual_credit_hold_updates": 80,
        "fast_counterfactual_credit_decay_updates": 120,
        # Unused replicas are credited separately from imbalance among the
        # replicas that actually served traffic, so the two costs do not stack.
        "slow_count_unused_replica_coef": 0.015,
    }
    for field, value in defaults.items():
        option = "--" + field.replace("_", "-")
        if field == "episode_minutes" and "--episode-hours" in explicit_options:
            continue
        negative_option = "--no-" + field.replace("_", "-")
        if option not in explicit_options and negative_option not in explicit_options:
            setattr(args, field, value)
    return args


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train hierarchical dual-agent PPO for edge services.")
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument(
        "--physical-seed",
        type=int,
        default=None,
        help="Seed for fixed physical edge infrastructure: nodes, capacities, service catalogue, and wired links.",
    )
    parser.add_argument("--fixed-scenario", action="store_true")
    parser.add_argument(
        "--training-design",
        choices=["legacy-alternating", "trajectory-simultaneous"],
        default="legacy-alternating",
        help=(
            "trajectory-simultaneous collects complete multi-window on-policy trajectories for both "
            "controllers; legacy-alternating preserves the earlier one-window episode schedule."
        ),
    )
    parser.add_argument(
        "--scenario-refresh-episodes",
        type=int,
        default=1,
        help="Without --fixed-scenario, reuse one scenario instance for this many training episodes.",
    )
    parser.add_argument(
        "--demand-sampling-mode",
        choices=["episode", "rollout"],
        default="episode",
        help=(
            "episode keeps the demand scenario for --scenario-refresh-episodes training episodes; "
            "rollout samples a new demand scenario for every PPO rollout while keeping physical_seed fixed."
        ),
    )
    parser.add_argument("--num-users", type=int, default=10_000)
    parser.add_argument("--num-edge-nodes", type=int, default=32)
    parser.add_argument("--num-service-types", type=int, default=10)
    parser.add_argument(
        "--pressure-profile",
        choices=sorted(PRESSURE_PROFILE_DEFAULTS),
        default="baseline",
        help=(
            "Reproducible MEC demand/capacity preset. The profile changes demand and fixed per-run "
            "capacity scales only; explicit scale flags override it."
        ),
    )
    parser.add_argument(
        "--demand-scenario-schedule",
        choices=["stream", "sequential", "shuffled-pool"],
        default="stream",
        help=(
            "stream draws fresh procedural demand seeds from one advancing RNG derived from --seed. "
            "sequential and shuffled-pool are compatibility ablations."
        ),
    )
    parser.add_argument(
        "--demand-scenario-pool-size",
        type=int,
        default=32,
        help="Number of demand-only scenarios in the shuffled training pool.",
    )
    parser.add_argument(
        "--episode-minutes",
        type=int,
        default=10,
        help="Environment episode horizon in minutes. The default aligns one episode with one Slow window.",
    )
    parser.add_argument(
        "--episode-hours",
        type=float,
        default=None,
        help="Deprecated compatibility override for legacy multi-hour trajectories.",
    )
    parser.add_argument(
        "--deployment-interval-minutes",
        type=int,
        default=10,
        help="Slow deployment period. The default 10 minutes equals 600 environment steps.",
    )
    parser.add_argument(
        "--arrival-profile",
        choices=["stationary", "daily"],
        default="stationary",
        help="Use stationary demand for independent episodes, or the legacy daily profile.",
    )
    parser.add_argument("--mean-requests-per-minute", type=float, default=None)
    parser.add_argument("--active-user-ratio", type=float, default=0.15)
    parser.add_argument("--active-user-request-rate-per-minute", type=float, default=1.5)
    parser.add_argument("--traffic-scale", type=float, default=1.0)
    parser.add_argument(
        "--load-multipliers",
        type=str,
        default="1.0",
        help=(
            "Comma-separated fixed load anchors used by cyclic sampling and deterministic evaluation. "
            "They also define zero-width strata when --load-strata is empty."
        ),
    )
    parser.add_argument(
        "--load-sampling-mode",
        choices=["cyclic", "stratified-random", "distribution-random"],
        default="distribution-random",
        help=(
            "Use the legacy fixed cycle, force balanced strata per update, or independently sample "
            "traffic strata from --load-stratum-probabilities using one advancing RNG."
        ),
    )
    parser.add_argument(
        "--load-strata",
        type=str,
        default="",
        help=(
            "Comma-separated low:high training ranges, e.g. "
            "0.75:0.95,0.95:1.20,1.20:1.50,1.50:1.85. "
            "Empty uses the fixed --load-multipliers as zero-width strata."
        ),
    )
    parser.add_argument(
        "--load-stratum-probabilities",
        type=str,
        default="",
        help=(
            "Target probability of each load stratum. MEC profiles use 0.20,0.50,0.25,0.05; "
            "the same probabilities weight Fast PPO groups without forcing uniform traffic. "
            "Empty selects a uniform distribution over the configured strata."
        ),
    )
    parser.add_argument(
        "--rollout-start-mode",
        choices=["beginning", "cycle-window", "random-window"],
        default="beginning",
        help="Initial time for each training rollout. Nonzero starts only affect the legacy daily arrival profile.",
    )
    parser.add_argument(
        "--eval-rollout-start-mode",
        choices=["same", "beginning", "cycle-window", "random-window"],
        default="same",
        help="Initial time for eval rollouts. same reuses --rollout-start-mode.",
    )
    parser.add_argument("--task-compute-scale", type=float, default=1.0)
    parser.add_argument("--task-data-scale", type=float, default=1.0)
    parser.add_argument(
        "--edge-node-profile",
        choices=["synthetic-tiered", "hardware-constrained", latency200.NODE_PROFILE],
        default="synthetic-tiered",
        help=(
            "Physical node catalogue. hardware-constrained uses Raspberry Pi 5, "
            "Jetson Orin Nano, and PowerEdge XR4000 inspired resource tiers. "
            "jetson-ai-edge selects Orin Nano 8GB, NX 16GB, and AGX Orin 32GB."
        ),
    )
    parser.add_argument(
        "--service-workload-profile",
        choices=["legacy-random", "edge-ai-pipelines", latency200.SERVICE_PROFILE],
        default="legacy-random",
        help=(
            "Service resource catalogue. edge-ai-pipelines uses staged speech, "
            "vision, robotics, and connected-vehicle workload demands. "
            "edge-ai-latency200 selects the opt-in, pending-calibration candidate."
        ),
    )
    parser.add_argument(
        "--node-compute-capacity-scale",
        type=float,
        default=1.0,
        help="Scale fixed edge-node compute capacities for this run. Values below 1.0 create a heavier compute bottleneck.",
    )
    parser.add_argument(
        "--wired-link-bandwidth-scale",
        type=float,
        default=1.0,
        help="Scale fixed wired-link bandwidths for this run. Values below 1.0 create stronger link bottlenecks.",
    )
    parser.add_argument(
        "--topology-k-nearest",
        type=int,
        default=6,
        help="Connect each edge node to this many geographic neighbors, then repair connectivity.",
    )
    parser.add_argument(
        "--deadline-scale",
        type=float,
        default=1.0,
        help="Scale service deadlines without changing task compute or data demand.",
    )
    parser.add_argument(
        "--service-resource-fraction",
        type=float,
        default=0.5,
        help="Fixed fraction of each node's memory/storage available to this service-placement controller.",
    )
    parser.add_argument(
        "--request-aggregation-window-seconds",
        type=float,
        default=1.0,
        help="Legacy name; fixed at 1 second so one env.step settles all individual requests arriving in that second.",
    )
    parser.add_argument(
        "--sampled-seconds-per-window",
        type=int,
        default=60,
        help=(
            "Training-only temporal sampling budget for each deployment window. "
            "Default 60 represents a 10-minute window with 60 weighted settlement steps; use 0 for a full rollout."
        ),
    )
    parser.add_argument("--load-ewma-tau-minutes", type=float, default=1.0)
    parser.add_argument(
        "--sampled-load-update-mode",
        choices=["legacy-repeat", "interval-average"],
        default="legacy-repeat",
        help=(
            "Advance sparse-rollout EWMA loads by the legacy repeated sampled second or by a "
            "bounded interval-average utilization estimate."
        ),
    )
    parser.add_argument("--wireless-uplink-mbps", type=float, default=150.0)
    parser.add_argument("--radio-rtt-ms", type=float, default=10.0)
    parser.add_argument("--updates", type=int, default=20)
    parser.add_argument("--requests-per-update", type=int, default=4096)
    parser.add_argument(
        "--rollout-unit",
        choices=["requests", "window", "episode"],
        default="window",
        help=(
            "Collect each PPO rollout by request count, one slow-deployment window, or one full environment episode."
        ),
    )
    parser.add_argument("--reward-scale", type=float, default=10.0)
    parser.add_argument("--reward-mode", choices=["latency"], default="latency")
    parser.add_argument("--train-mode", choices=["joint", "fast-only"], default="joint")
    parser.add_argument(
        "--replicas-per-stage",
        "--max-replicas-per-stage",
        dest="replicas_per_stage",
        type=int,
        default=0,
        help="Maximum replicas the slow count PPO may choose per service stage. Use 0 for no artificial cap, i.e. num_edge_nodes.",
    )
    parser.add_argument("--compute-hotspot-threshold", type=float, default=0.60)
    parser.add_argument("--link-hotspot-threshold", type=float, default=0.60)
    parser.add_argument("--resource-active-load-threshold", type=float, default=0.01)
    parser.add_argument("--compute-hotspot-coef", type=float, default=0.0)
    parser.add_argument("--link-hotspot-coef", type=float, default=0.0)
    parser.add_argument("--compute-imbalance-coef", type=float, default=0.0)
    parser.add_argument("--link-imbalance-coef", type=float, default=0.0)
    parser.add_argument("--idle-deployed-node-coef", type=float, default=0.0)
    parser.add_argument("--fast-policy-kind", choices=["node_scorer", "gat_node_scorer"], default="gat_node_scorer")
    parser.add_argument(
        "--training-repair", choices=["auto", "legacy", "batch-credit-v1"], default="auto",
        help="auto enables repaired credit for fresh mec-latency200 runs; checkpoints retain their saved version",
    )
    parser.add_argument("--slow-team-value-coef", type=float, default=0.5,
                        help="detached normalized conditional critic loss weight in repaired mode")
    parser.add_argument("--slow-deployment-context", choices=["auto", "legacy", "deployment-aware-v2", "deployment-chain-v3"], default="auto",
                        help="auto preserves checkpoint architecture; fresh repaired latency200 budget runs use deployment-aware-v2")
    parser.add_argument("--slow-learning-repair", choices=["auto", "none", "conditional-replay-v1", "prefix-credit-v2", "prefix-structured-v3"], default="auto",
                        help="fresh deployment-aware runs use conditional value replay and guarded minibatch epochs; resume preserves saved training semantics")
    parser.add_argument("--network-constraint-mode", choices=["edge-only", "shared-nic"], default="edge-only")
    parser.add_argument("--service-calibration-mode", choices=["legacy", "audited-v1"], default="legacy")
    parser.add_argument("--service-calibration-file", default=None, help="schema-1 measured/estimated budget JSON")
    parser.add_argument("--temporal-sampling-mode", choices=["left-hold", "stratified-jitter"], default="left-hold")
    parser.add_argument("--sampling-max-interval-seconds", type=float, default=0.0,
                        help="0 disables cap; otherwise limit holding one sampled second over skipped time")
    parser.add_argument(
        "--fast-chain-context",
        choices=["auto", "legacy", "chain-v2", "chain-kkt-v3"],
        default="auto",
        help=(
            "chain-v2 adds routed incoming-data cost, previous-node colocation, "
            "remaining-chain demand, and next-stage overlap; chain-kkt-v3 additionally "
            "uses per-request causal KKT ledgers, exact marginal features, and downstream lookahead"
        ),
    )
    parser.add_argument("--slow-lr", type=float, default=3e-4)
    parser.add_argument(
        "--slow-count-lr",
        type=float,
        default=2e-4,
        help="Independent Count actor learning rate; raised to use the large observed Count KL margin.",
    )
    parser.add_argument(
        "--slow-stage-lr",
        type=float,
        default=None,
        help="Independent Stage actor learning rate; defaults to --slow-count-lr when omitted.",
    )
    parser.add_argument(
        "--slow-placement-lr",
        type=float,
        default=1.5e-4,
        help="Independent Placement actor learning rate; conservative by default to avoid node-policy collapse.",
    )
    parser.add_argument("--fast-lr", type=float, default=2e-4)
    parser.add_argument("--slow-k-epochs", type=int, default=3)
    parser.add_argument(
        "--slow-stage-k-epochs",
        type=int,
        default=None,
        help="Independent Stage PPO epochs; defaults to --slow-k-epochs when omitted.",
    )
    parser.add_argument(
        "--slow-placement-k-epochs",
        type=int,
        default=None,
        help="Independent Placement PPO epochs; defaults to --slow-k-epochs when omitted.",
    )
    parser.add_argument("--fast-k-epochs", type=int, default=4)
    parser.add_argument("--slow-entropy-coef", type=float, default=0.001)
    parser.add_argument("--slow-count-entropy-coef", type=float, default=None)
    parser.add_argument("--slow-placement-entropy-coef", type=float, default=0.005)
    parser.add_argument(
        "--slow-placement-entropy-final-coef",
        type=float,
        default=0.0035,
        help="Final Placement entropy coefficient after the Slow-update decay schedule.",
    )
    parser.add_argument(
        "--slow-placement-entropy-hold-updates",
        type=int,
        default=64,
        help="Completed Slow PPO updates that retain the initial Placement entropy floor before decay.",
    )
    parser.add_argument(
        "--slow-placement-entropy-decay-updates",
        type=int,
        default=64,
        help="Completed Slow PPO updates over which Placement entropy decays after the hold period.",
    )
    parser.add_argument("--slow-placement-entropy-target", type=float, default=1.8)
    parser.add_argument("--slow-placement-entropy-max-coef", type=float, default=0.05)
    parser.add_argument("--slow-placement-entropy-adaptation-rate", type=float, default=2e-3)
    parser.add_argument(
        "--slow-count-global-advantage-coef",
        type=float,
        default=0.25,
        help="Window-critic residual mixed into each stage-centered Count advantage.",
    )
    parser.add_argument(
        "--slow-placement-global-advantage-coef",
        type=float,
        default=0.35,
        help="Window-critic residual mixed into each stage-centered Placement advantage.",
    )
    parser.add_argument(
        "--slow-placement-global-attribution-coef",
        type=float,
        default=0.50,
        help="Action-level redistribution of each window residual using node-local Placement quality.",
    )
    parser.add_argument(
        "--slow-global-advantage-ev-full",
        type=float,
        default=0.20,
        help="Holdout explained variance at which Slow global credit reaches its configured coefficient.",
    )
    parser.add_argument(
        "--slow-tail-latency-coef",
        type=float,
        default=0.35,
        help="Weight of the window P95 latency in the Slow deployment return; 0 uses mean latency only.",
    )
    parser.add_argument(
        "--slow-colocation-coef",
        type=float,
        default=0.05,
        help="Penalty in seconds-equivalent for cross-node transitions between adjacent stages in the Slow return.",
    )
    parser.add_argument(
        "--slow-colocation-final-coef",
        type=float,
        default=None,
        help=(
            "Final explicit cross-stage transition coefficient. None preserves the initial coefficient; "
            "trajectory-simultaneous training anneals it to zero because measured link latency already "
            "provides the long-run communication signal."
        ),
    )
    parser.add_argument(
        "--slow-colocation-hold-updates",
        type=int,
        default=0,
        help="Completed updates that retain the initial explicit Slow colocation coefficient.",
    )
    parser.add_argument(
        "--slow-colocation-decay-updates",
        type=int,
        default=1,
        help="Updates over which explicit Slow colocation credit reaches its final coefficient.",
    )
    parser.add_argument("--fast-entropy-coef", type=float, default=0.001)
    parser.add_argument("--fast-entropy-target", type=float, default=0.7)
    parser.add_argument("--fast-entropy-max-coef", type=float, default=0.03)
    parser.add_argument("--fast-entropy-adaptation-rate", type=float, default=2e-3)
    parser.add_argument(
        "--fast-congestion-credit-coef",
        type=float,
        default=1.0,
        help="Weight of exact KKT marginal congestion externality in each Fast stage reward.",
    )
    parser.add_argument(
        "--fast-reservation-microbatch-size",
        type=int,
        default=16,
        help="Requests per Fast inference microbatch before virtual compute reservations are updated.",
    )
    parser.add_argument("--slow-value-coef", type=float, default=0.5)
    parser.add_argument(
        "--slow-count-value-coef",
        type=float,
        default=0.0,
        help="Count critic loss coefficient. Keep at 0 when the actor uses direct stage-centered returns.",
    )
    parser.add_argument("--slow-critic-lr", type=float, default=5e-4)
    parser.add_argument("--slow-critic-k-epochs", type=int, default=8)
    parser.add_argument("--slow-critic-replay-windows", type=int, default=96)
    parser.add_argument("--slow-critic-replay-decay", type=float, default=0.90)
    parser.add_argument("--slow-critic-holdout-windows", type=int, default=12)
    parser.add_argument(
        "--slow-critic-holdout-episodes",
        type=int,
        default=2,
        help="Newest complete 60-minute episodes reserved from Slow critic optimization.",
    )
    parser.add_argument(
        "--fast-counterfactual-credit-coef",
        type=float,
        default=0.50,
        help="Penalty weight for Fast chain-aware regret relative to feasible candidate nodes.",
    )
    parser.add_argument(
        "--fast-counterfactual-credit-final-coef",
        type=float,
        default=0.50,
        help="Final Fast counterfactual-credit weight after the training schedule.",
    )
    parser.add_argument(
        "--fast-counterfactual-credit-hold-updates",
        type=int,
        default=40,
        help="Completed updates that retain the initial counterfactual-credit weight.",
    )
    parser.add_argument(
        "--fast-counterfactual-credit-decay-updates",
        type=int,
        default=60,
        help="Updates used to linearly reach the final counterfactual-credit weight.",
    )
    parser.add_argument(
        "--fast-controllable-latency-credit",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Exclude policy-invariant radio access delay from Fast and factorized Slow credit.",
    )
    parser.add_argument(
        "--fast-oracle-diagnostic-requests",
        type=int,
        default=1,
        help="Requests per rollout compared with the bounded chain beam oracle; 0 disables it.",
    )
    parser.add_argument("--fast-oracle-beam-width", type=int, default=32)
    parser.add_argument("--fast-oracle-candidates-per-stage", type=int, default=8)
    parser.add_argument(
        "--fast-entropy-normalized-control",
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            "Adapt Fast entropy from H/log(number of feasible actions) while retaining raw entropy logs."
        ),
    )
    parser.add_argument("--slow-critic-gradient-clip", type=float, default=5.0)
    parser.add_argument(
        "--slow-window-gamma",
        type=float,
        default=0.95,
        help="Discount factor between consecutive ten-minute Slow decisions in a multi-window episode.",
    )
    parser.add_argument("--slow-deployment-memory-coef", type=float, default=0.03)
    parser.add_argument("--slow-deployment-storage-coef", type=float, default=0.01)
    parser.add_argument(
        "--slow-migration-coef",
        type=float,
        default=0.0,
        help="Slow-return migration penalty. Disabled by default; deployment changes remain logged.",
    )
    parser.add_argument(
        "--slow-idle-replica-coef",
        type=float,
        default=0.05,
        help=(
            "Count penalty for replica-use imbalance; with unused-replica credit disabled, "
            "retains the legacy total-redundancy penalty."
        ),
    )
    parser.add_argument(
        "--slow-count-unused-replica-coef",
        type=float,
        default=0.0,
        help=(
            "Count penalty for deployed replicas receiving no sampled Fast traffic; when enabled, "
            "unused and served-replica imbalance are disjoint costs."
        ),
    )
    parser.add_argument(
        "--slow-placement-idle-coef",
        type=float,
        default=0.02,
        help="Node-local Placement penalty for a selected replica that receives no frozen-Fast traffic.",
    )
    parser.add_argument(
        "--slow-placement-compute-coef",
        type=float,
        default=0.20,
        help="Seconds-equivalent node-local compute-load penalty in each Placement return.",
    )
    parser.add_argument("--slow-count-shortage-coef", type=float, default=0.25)
    parser.add_argument(
        "--slow-count-latency-coef",
        type=float,
        default=1.0,
        help="Dense stage tail-latency weight in the Slow Count return.",
    )
    parser.add_argument("--slow-deadline-violation-coef", type=float, default=0.10)
    parser.add_argument(
        "--slow-shared-return-coef",
        type=float,
        default=0.25,
        help=(
            "Direct window-level end-to-end return mixed into Count and Placement action returns, "
            "independent of Slow critic reliability."
        ),
    )
    parser.add_argument(
        "--slow-deterministic-count-mode",
        choices=["expected", "mode"],
        default="expected",
        help="Decode ordered Count actions by conservative posterior mean or categorical mode.",
    )
    parser.add_argument(
        "--slow-quota-decode", choices=["auto", "mean", "integer-mode", "categorical-mode", "categorical-mean"],
        default="auto", help="Versioned stage quota decoder; auto restores the checkpoint's rule.",
    )
    parser.add_argument(
        "--slow-allocation-mode",
        choices=[
            "legacy-factorized",
            "global-incremental",
            "budget-incremental",
            "budget-continuous-v2",
            "stage-budget-v3",
            "stage-budget-v4",
            "stage-budget-v5",
            "stage-budget-v6",
        ],
        default="legacy-factorized",
        help=(
            "Keep per-stage target counts for checkpoint compatibility, or allocate mandatory "
            "coverage followed by globally competing add-replica/STOP actions; budget-incremental "
            "chooses one ordinal extra-replica budget and allocates it with separate Stage/Placement PPO heads; "
            "budget-continuous-v2 emits a continuous [0,1] fraction of the live remaining service-resource budget; "
            "actual stage sizes determine how many replicas are placed."
        ),
    )
    parser.add_argument(
        "--slow-counterfactual-credit-coef",
        type=float,
        default=0.0,
        help=(
            "Weight of same-trace selected-node versus best-alternative marginal value in Slow "
            "Count and Placement returns."
        ),
    )
    parser.add_argument(
        "--slow-replica-ablation-samples",
        type=int,
        default=0,
        help=(
            "For incremental Slow allocation, test this many removable ADD replicas "
            "on one sampled request tick with frozen Fast and joint KKT; global mode "
            "also probes STOP against feasible additions. Zero keeps legacy credit."
        ),
    )
    parser.add_argument("--fast-value-coef", type=float, default=0.5)
    parser.add_argument("--slow-target-kl", type=float, default=0.03)
    parser.add_argument("--slow-count-target-kl", type=float, default=0.015)
    parser.add_argument("--slow-placement-target-kl", type=float, default=0.015)
    parser.add_argument("--fast-target-kl", type=float, default=0.015)
    parser.add_argument("--slow-minibatch-size", type=int, default=2048)
    parser.add_argument("--fast-minibatch-size", type=int, default=512)
    parser.add_argument(
        "--fast-load-balanced-updates",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Stratify Fast minibatches by load and apply configured target group weights.",
    )
    parser.add_argument(
        "--fast-full-batch-kl-stop",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Check Fast KL after a complete epoch over the full buffer instead of stopping on one minibatch.",
    )
    parser.add_argument(
        "--fast-windows-per-update",
        "--rollouts-per-update",
        dest="fast_windows_per_update",
        type=int,
        default=1,
        help=(
            "Collect this many ten-minute windows before each Fast PPO update. "
            "--rollouts-per-update is retained as a compatibility alias."
        ),
    )
    parser.add_argument(
        "--slow-windows-per-update",
        type=int,
        default=32,
        help="Accumulate this many completed ten-minute Slow windows before each update.",
    )
    parser.add_argument(
        "--joint-training-schedule",
        choices=["alternating", "simultaneous"],
        default="alternating",
        help="Alternate frozen Fast/Slow collection phases or retain legacy simultaneous updates.",
    )
    parser.add_argument(
        "--fast-updates-per-cycle",
        type=int,
        default=3,
        help="Number of Fast-only updates before one frozen-Fast Slow update in alternating mode.",
    )
    parser.add_argument(
        "--fast-warmup-updates",
        type=int,
        default=4,
        help="Number of deterministic-Slow Fast updates before Slow warm-up starts.",
    )
    parser.add_argument(
        "--slow-warmup-updates",
        type=int,
        default=4,
        help="Number of frozen-Fast Slow updates after Fast warm-up and before alternating training.",
    )
    parser.add_argument(
        "--slow-fast-collection-mode",
        choices=["stochastic", "deterministic"],
        default="stochastic",
        help="Use a frozen stochastic Fast policy for Slow credit by default; deterministic is an ablation.",
    )
    parser.add_argument(
        "--synchronized-window-block",
        type=int,
        default=0,
        help="When positive, collect this many windows and update Fast and Slow PPO together each block.",
    )
    parser.add_argument("--device", type=str, default="cpu")
    parser.add_argument("--load-checkpoint", type=str, default="")
    parser.add_argument("--init-fast-checkpoint", type=str, default="",
                        help="initialize only Fast weights/value scale from compatible environment; fresh Slow and optimizer/RNG streams")
    parser.add_argument("--init-slow-checkpoint", type=str, default="",
                        help="initialize compatible Slow actors; fresh critics/optimizers, zero additional observation weights")
    parser.add_argument("--init-slow-actor-scope", choices=["all", "stage-placement"], default="all",
                        help="stage-placement permits a fresh Count architecture and compatible pretrained remaining actors")
    parser.add_argument("--deterministic-eval", action="store_true")
    parser.add_argument("--eval-baseline", action="store_true")
    parser.add_argument(
        "--eval-before-training",
        action="store_true",
        help="Run the eval sweep at update 0 before training starts. Disabled by default for long episode runs.",
    )
    parser.add_argument("--eval-requests", type=int, default=128)
    parser.add_argument("--eval-interval", type=int, default=0)
    parser.add_argument(
        "--eval-rollout-unit",
        choices=["requests", "window", "episode", "same"],
        default="requests",
        help="Use request-count eval, full-episode eval, or the same unit as training.",
    )
    parser.add_argument(
        "--eval-seeds",
        type=int,
        default=1,
        help="Number of held-out demand seeds per eval point. Default 1 performs one eval rollout.",
    )
    parser.add_argument("--fast-bc-requests", type=int, default=0)
    parser.add_argument("--fast-bc-epochs", type=int, default=3)
    parser.add_argument("--run-root", type=str, default="runs")
    parser.add_argument("--run-name", type=str, default="")
    parser.add_argument("--log-dir", type=str, default="")
    parser.add_argument("--save-dir", type=str, default="")
    parser.add_argument(
        "--save-best",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Save robust rolling-best checkpoints (enabled by default).",
    )
    parser.add_argument(
        "--best-checkpoint-window",
        type=int,
        default=10,
        help="Updates in the load-adjusted rolling score used for best.pt.",
    )
    parser.add_argument(
        "--checkpoint-interval",
        type=int,
        default=20,
        help="Save a resumable snapshots/update_NNNN.pt every N updates; 0 disables snapshots.",
    )
    parser.add_argument(
        "--slow-lr-decay",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Halve Slow actor learning rates after a sustained rolling-latency plateau.",
    )
    parser.add_argument(
        "--slow-lr-decay-patience",
        type=int,
        default=10,
        help="Completed Slow PPO updates without sufficient improvement before reducing its learning rates.",
    )
    parser.add_argument("--slow-lr-decay-factor", type=float, default=0.5)
    parser.add_argument(
        "--slow-lr-decay-min-delta",
        type=float,
        default=5e-4,
        help="Minimum rolling latency improvement in seconds that resets Slow LR patience.",
    )
    parser.add_argument("--slow-min-lr", type=float, default=1e-5)
    parser.add_argument("--slow-count-min-lr", type=float, default=1e-5)
    parser.add_argument("--slow-placement-min-lr", type=float, default=1e-5)
    parser.add_argument(
        "--slow-lr-kl-floor-fraction",
        type=float,
        default=0.10,
        help="Block an actor LR reduction while its KL is below this fraction of target KL.",
    )
    parser.add_argument(
        "--slow-lr-low-entropy-override",
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            "Allow sustained performance degradation to reduce Placement LR even at low KL when "
            "Placement entropy is below target."
        ),
    )
    parser.add_argument("--slow-lr-max-reductions", type=int, default=1)
    parser.add_argument("--slow-lr-cooldown-updates", type=int, default=20)
    parser.add_argument("--append-log", action="store_true")
    parser.add_argument("--proposed-design", choices=["auto", "legacy", "joint-credit-v2", "joint-credit-v3", "joint-credit-v4", "joint-credit-v5"], default="auto",
                        help="Explicit joint PPO repair preset; auto preserves saved/legacy behavior")
    parser.add_argument("--fast-update-chunks", type=int, default=1)
    parser.add_argument("--fast-independent-critic", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--checkpoint-probe-interval", type=int, default=10)
    parser.add_argument("--init-fast-actor-only", action="store_true",
                        help="Explicitly transfer only Fast actor/backbone; reset changed critic and all optimizers")
    parser.add_argument(
        "--progress-interval-seconds",
        type=float,
        default=10.0,
        help="Print in-rollout terminal progress every N seconds. Use 0 to disable.",
    )
    args = parser.parse_args()
    if args.episode_hours is not None:
        args.episode_minutes = int(round(float(args.episode_hours) * 60.0))
    args = apply_pressure_profile(args)
    args = apply_training_design(args)
    if args.synchronized_window_block > 0:
        args.fast_windows_per_update = args.synchronized_window_block
        args.slow_windows_per_update = args.synchronized_window_block
        args.joint_training_schedule = "simultaneous"
    if args.fast_windows_per_update < 1:
        parser.error("--fast-windows-per-update must be >= 1")
    if args.slow_windows_per_update < 1:
        parser.error("--slow-windows-per-update must be >= 1")
    if args.eval_seeds < 1:
        parser.error("--eval-seeds must be >= 1")
    if args.demand_scenario_pool_size < 1:
        parser.error("--demand-scenario-pool-size must be >= 1")
    if args.replicas_per_stage < 0:
        parser.error("--replicas-per-stage must be >= 0")
    if not 0.0 < args.service_resource_fraction <= 1.0:
        parser.error("--service-resource-fraction must be in (0, 1]")
    if not 1 <= args.topology_k_nearest < args.num_edge_nodes:
        parser.error("--topology-k-nearest must be in [1, num-edge-nodes)")
    if args.deadline_scale <= 0.0:
        parser.error("--deadline-scale must be positive")
    if args.fast_congestion_credit_coef < 0.0:
        parser.error("--fast-congestion-credit-coef must be >= 0")
    if args.fast_counterfactual_credit_coef < 0.0:
        parser.error("--fast-counterfactual-credit-coef must be >= 0")
    if args.fast_counterfactual_credit_final_coef < 0.0:
        parser.error("--fast-counterfactual-credit-final-coef must be >= 0")
    if args.fast_counterfactual_credit_hold_updates < 0:
        parser.error("--fast-counterfactual-credit-hold-updates must be >= 0")
    if args.fast_counterfactual_credit_decay_updates < 1:
        parser.error("--fast-counterfactual-credit-decay-updates must be >= 1")
    if args.fast_oracle_diagnostic_requests < 0:
        parser.error("--fast-oracle-diagnostic-requests must be >= 0")
    if args.fast_oracle_beam_width < 1 or args.fast_oracle_candidates_per_stage < 1:
        parser.error("Fast oracle beam width and candidates per stage must be >= 1")
    if args.fast_reservation_microbatch_size < 1:
        parser.error("--fast-reservation-microbatch-size must be >= 1")
    if (
        args.slow_idle_replica_coef < 0.0
        or args.slow_count_unused_replica_coef < 0.0
        or args.slow_placement_idle_coef < 0.0
        or args.slow_placement_compute_coef < 0.0
        or args.slow_count_shortage_coef < 0.0
        or args.slow_count_latency_coef < 0.0
        or args.slow_deadline_violation_coef < 0.0
        or args.slow_shared_return_coef < 0.0
        or args.slow_counterfactual_credit_coef < 0.0
    ):
        parser.error("Slow shaping coefficients must be >= 0")
    if args.slow_replica_ablation_samples < 0:
        parser.error("--slow-replica-ablation-samples must be >= 0")
    if args.slow_replica_ablation_samples > 0 and args.slow_allocation_mode not in {
        "global-incremental",
        "budget-incremental",
        "budget-continuous-v2",
            "stage-budget-v3",
            "stage-budget-v4",
            "stage-budget-v5",
            "stage-budget-v6",
    }:
        parser.error(
            "--slow-replica-ablation-samples requires --slow-allocation-mode "
            "global-incremental, budget-incremental, or budget-continuous-v2"
        )
    if args.slow_replica_ablation_samples > 0 and args.slow_counterfactual_credit_coef <= 0.0:
        parser.error("--slow-replica-ablation-samples requires positive --slow-counterfactual-credit-coef")
    if args.fast_updates_per_cycle < 1:
        parser.error("--fast-updates-per-cycle must be >= 1")
    if args.fast_update_chunks < 1 or args.checkpoint_probe_interval < 1:
        parser.error("Fast update chunks and checkpoint probe interval must be positive")
    if args.fast_warmup_updates < 0 or args.slow_warmup_updates < 0:
        parser.error("--fast-warmup-updates and --slow-warmup-updates must be >= 0")
    if args.joint_training_schedule == "alternating" and args.rollout_unit != "window":
        args.joint_training_schedule = "simultaneous"
    if args.slow_critic_k_epochs < 1:
        parser.error("--slow-critic-k-epochs must be >= 1")
    if args.slow_critic_replay_windows < 1:
        parser.error("--slow-critic-replay-windows must be >= 1")
    if args.slow_critic_holdout_windows < 1:
        parser.error("--slow-critic-holdout-windows must be >= 1")
    if args.slow_critic_holdout_episodes < 1:
        parser.error("--slow-critic-holdout-episodes must be >= 1")
    if args.slow_critic_replay_windows <= args.slow_critic_holdout_windows:
        parser.error("--slow-critic-replay-windows must exceed --slow-critic-holdout-windows")
    if not 0.0 < args.slow_critic_replay_decay <= 1.0:
        parser.error("--slow-critic-replay-decay must be in (0, 1]")
    if args.slow_critic_gradient_clip <= 0.0:
        parser.error("--slow-critic-gradient-clip must be positive")
    if not 0.0 <= args.slow_window_gamma <= 1.0:
        parser.error("--slow-window-gamma must be in [0, 1]")
    if not 0.0 <= args.slow_tail_latency_coef <= 1.0:
        parser.error("--slow-tail-latency-coef must be in [0, 1]")
    if args.slow_colocation_coef < 0.0:
        parser.error("--slow-colocation-coef must be >= 0")
    if args.slow_colocation_final_coef is not None:
        if args.slow_colocation_final_coef < 0.0:
            parser.error("--slow-colocation-final-coef must be >= 0")
        if args.slow_colocation_final_coef > args.slow_colocation_coef:
            parser.error("--slow-colocation-final-coef must not exceed --slow-colocation-coef")
    if args.slow_colocation_hold_updates < 0:
        parser.error("--slow-colocation-hold-updates must be >= 0")
    if args.slow_colocation_decay_updates < 1:
        parser.error("--slow-colocation-decay-updates must be >= 1")
    if args.slow_count_value_coef < 0.0:
        parser.error("--slow-count-value-coef must be >= 0")
    if args.slow_count_lr <= 0.0 or args.slow_count_target_kl <= 0.0:
        parser.error("--slow-count-lr and --slow-count-target-kl must be positive")
    if args.slow_stage_lr is not None and args.slow_stage_lr <= 0.0:
        parser.error("--slow-stage-lr must be positive when provided")
    if args.slow_placement_lr <= 0.0 or args.slow_placement_target_kl <= 0.0:
        parser.error("--slow-placement-lr and --slow-placement-target-kl must be positive")
    if args.slow_stage_k_epochs is not None and args.slow_stage_k_epochs < 1:
        parser.error("--slow-stage-k-epochs must be >= 1 when provided")
    if args.slow_placement_k_epochs is not None and args.slow_placement_k_epochs < 1:
        parser.error("--slow-placement-k-epochs must be >= 1 when provided")
    if args.slow_placement_entropy_coef < 0.0 or args.slow_placement_entropy_final_coef < 0.0:
        parser.error("Placement entropy coefficients must be non-negative")
    if args.slow_placement_entropy_final_coef > args.slow_placement_entropy_coef:
        parser.error("--slow-placement-entropy-final-coef must not exceed the initial coefficient")
    if args.slow_placement_entropy_hold_updates < 0:
        parser.error("--slow-placement-entropy-hold-updates must be >= 0")
    if args.slow_placement_entropy_decay_updates < 1:
        parser.error("--slow-placement-entropy-decay-updates must be >= 1")
    if args.slow_placement_entropy_target < 0.0:
        parser.error("--slow-placement-entropy-target must be >= 0")
    if args.slow_placement_entropy_max_coef < args.slow_placement_entropy_coef:
        parser.error("--slow-placement-entropy-max-coef must be at least the initial coefficient")
    if args.slow_placement_entropy_adaptation_rate < 0.0:
        parser.error("--slow-placement-entropy-adaptation-rate must be >= 0")
    if args.slow_placement_global_attribution_coef < 0.0:
        parser.error("--slow-placement-global-attribution-coef must be >= 0")
    if args.slow_count_global_advantage_coef < 0.0 or args.slow_placement_global_advantage_coef < 0.0:
        parser.error("Slow global advantage coefficients must be >= 0")
    if args.slow_global_advantage_ev_full <= 0.0:
        parser.error("--slow-global-advantage-ev-full must be positive")
    if args.fast_entropy_coef < 0.0 or args.fast_entropy_target < 0.0:
        parser.error("Fast entropy coefficient and target must be >= 0")
    if args.fast_entropy_max_coef < args.fast_entropy_coef:
        parser.error("--fast-entropy-max-coef must be at least --fast-entropy-coef")
    if args.fast_entropy_adaptation_rate < 0.0:
        parser.error("--fast-entropy-adaptation-rate must be >= 0")
    if args.best_checkpoint_window < 1:
        parser.error("--best-checkpoint-window must be >= 1")
    if args.checkpoint_interval < 0:
        parser.error("--checkpoint-interval must be >= 0")
    if args.slow_lr_decay_patience < 1:
        parser.error("--slow-lr-decay-patience must be >= 1")
    if not 0.0 < args.slow_lr_decay_factor < 1.0:
        parser.error("--slow-lr-decay-factor must be in (0, 1)")
    if args.slow_lr_decay_min_delta < 0.0:
        parser.error("--slow-lr-decay-min-delta must be >= 0")
    if (
        args.slow_min_lr <= 0.0
        or args.slow_count_min_lr <= 0.0
        or args.slow_placement_min_lr <= 0.0
    ):
        parser.error("Slow minimum learning rates must be positive")
    if not 0.0 <= args.slow_lr_kl_floor_fraction <= 1.0:
        parser.error("--slow-lr-kl-floor-fraction must be in [0, 1]")
    if args.slow_lr_max_reductions < 0:
        parser.error("--slow-lr-max-reductions must be >= 0")
    if args.slow_lr_cooldown_updates < 0:
        parser.error("--slow-lr-cooldown-updates must be >= 0")
    if args.synchronized_window_block < 0:
        parser.error("--synchronized-window-block must be >= 0")
    if args.episode_minutes < 1:
        parser.error("--episode-minutes must be >= 1")
    if args.deployment_interval_minutes < 1:
        parser.error("--deployment-interval-minutes must be >= 1")
    if not np.isclose(args.request_aggregation_window_seconds, 1.0):
        parser.error("--request-aggregation-window-seconds must remain exactly 1.0")
    if args.sampled_seconds_per_window < 0:
        parser.error("--sampled-seconds-per-window must be >= 0")
    if not np.isfinite(args.sampling_max_interval_seconds) or (args.sampling_max_interval_seconds != 0 and args.sampling_max_interval_seconds < 1):
        parser.error("--sampling-max-interval-seconds must be 0 or finite and >= 1")
    if not np.isfinite(args.slow_team_value_coef) or args.slow_team_value_coef <= 0:
        parser.error("--slow-team-value-coef must be positive and finite")
    if args.train_mode == "joint" and args.rollout_unit == "requests":
        parser.error("joint training requires --rollout-unit window or episode so each slow action receives a complete return")
    if args.training_design == "trajectory-simultaneous":
        if args.rollout_unit != "window":
            parser.error("trajectory-simultaneous training requires --rollout-unit window")
        if args.joint_training_schedule != "simultaneous":
            parser.error("trajectory-simultaneous training requires --joint-training-schedule simultaneous")
        if args.episode_minutes % args.deployment_interval_minutes != 0:
            parser.error("trajectory episode length must be divisible by the deployment interval")
        trajectory_windows = args.episode_minutes // args.deployment_interval_minutes
        if args.fast_windows_per_update % trajectory_windows != 0:
            parser.error("Fast windows per update must contain a whole number of complete trajectories")
        if args.slow_windows_per_update % trajectory_windows != 0:
            parser.error("Slow windows per update must contain a whole number of complete trajectories")
        if args.fast_windows_per_update != args.slow_windows_per_update:
            parser.error("trajectory-simultaneous training requires one shared Fast/Slow window batch")
    try:
        load_anchors = _parse_float_list(args.load_multipliers, "--load-multipliers")
        load_strata = _load_strata_for_args(args)
        load_probabilities = _load_probabilities_for_args(args, len(load_strata))
        if args.load_strata:
            if len(load_anchors) != len(load_strata):
                raise ValueError("--load-multipliers must provide one deterministic anchor per --load-strata range")
            if any(not low <= anchor <= high for anchor, (low, high) in zip(load_anchors, load_strata)):
                raise ValueError("each --load-multipliers anchor must lie inside its corresponding --load-strata range")
        if len(load_probabilities) != len(load_strata):
            raise ValueError("--load-stratum-probabilities must provide one value per load stratum")
    except ValueError as exc:
        parser.error(str(exc))
    return args


def effective_replicas_per_stage(args: argparse.Namespace) -> int:
    if int(args.replicas_per_stage) == 0:
        return int(args.num_edge_nodes)
    return min(int(args.replicas_per_stage), int(args.num_edge_nodes))


def _parse_float_list(raw: str, name: str) -> tuple[float, ...]:
    try:
        values = tuple(float(part.strip()) for part in raw.split(",") if part.strip())
    except ValueError as exc:
        raise ValueError(f"{name} must be a comma-separated list of positive numbers") from exc
    if not values or any(value <= 0 for value in values):
        raise ValueError(f"{name} must contain at least one positive number")
    return values


def load_multiplier_for_rollout(args: argparse.Namespace, rollout_idx: int) -> float:
    multipliers = _parse_float_list(getattr(args, "load_multipliers", "1.0"), "--load-multipliers")
    return multipliers[int(rollout_idx) % len(multipliers)]


def _parse_load_strata(raw: str, name: str = "--load-strata") -> tuple[tuple[float, float], ...]:
    strata: list[tuple[float, float]] = []
    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        try:
            low_raw, high_raw = part.split(":", 1)
            low, high = float(low_raw), float(high_raw)
        except ValueError as exc:
            raise ValueError(f"{name} must contain comma-separated low:high pairs") from exc
        if low <= 0.0 or high <= 0.0 or high < low:
            raise ValueError(f"{name} bounds must be positive and satisfy low <= high")
        strata.append((low, high))
    if not strata:
        raise ValueError(f"{name} must contain at least one low:high pair")
    return tuple(strata)


def _load_strata_for_args(args: argparse.Namespace) -> tuple[tuple[float, float], ...]:
    raw = str(getattr(args, "load_strata", "")).strip()
    if raw:
        return _parse_load_strata(raw)
    return tuple(
        (value, value)
        for value in _parse_float_list(getattr(args, "load_multipliers", "1.0"), "--load-multipliers")
    )


def _load_probabilities_for_args(args: argparse.Namespace, stratum_count: int) -> tuple[float, ...]:
    raw = str(getattr(args, "load_stratum_probabilities", "")).strip()
    if not raw:
        return tuple(1.0 / stratum_count for _ in range(stratum_count))
    values = _parse_float_list(raw, "--load-stratum-probabilities")
    if len(values) != stratum_count:
        raise ValueError("--load-stratum-probabilities must provide one value per load stratum")
    total = float(sum(values))
    return tuple(value / total for value in values)


class TrainingRandomStreams:
    """Independent, advancing RNG streams derived once from the run seed."""

    def __init__(self, master_seed: int):
        scenario_seed, environment_seed, load_seed = np.random.SeedSequence(int(master_seed)).spawn(3)
        self.scenario_rng = np.random.default_rng(scenario_seed)
        self.environment_rng = np.random.default_rng(environment_seed)
        self.load_rng = np.random.default_rng(load_seed)
        self._episode_scenario_group: int | None = None
        self._episode_demand_seed: int | None = None

    @staticmethod
    def _draw_seed(rng: np.random.Generator) -> int:
        return int(rng.integers(0, np.iinfo(np.int32).max, endpoint=False))

    def next_demand_seed(self) -> int:
        return self._draw_seed(self.scenario_rng)

    def demand_seed_for_episode(self, episode_idx: int, refresh_episodes: int = 1) -> int:
        scenario_group = int(episode_idx) // max(int(refresh_episodes), 1)
        if scenario_group != self._episode_scenario_group:
            self._episode_scenario_group = scenario_group
            self._episode_demand_seed = self.next_demand_seed()
        assert self._episode_demand_seed is not None
        return self._episode_demand_seed

    def next_environment_seed(self) -> int:
        return self._draw_seed(self.environment_rng)

    def state_dict(self) -> dict[str, object]:
        return {
            "scenario_rng_json": json.dumps(self.scenario_rng.bit_generator.state),
            "environment_rng_json": json.dumps(self.environment_rng.bit_generator.state),
            "load_rng_json": json.dumps(self.load_rng.bit_generator.state),
            "episode_scenario_group": self._episode_scenario_group,
            "episode_demand_seed": self._episode_demand_seed,
        }

    def load_state_dict(self, state: dict[str, object]) -> None:
        self.scenario_rng.bit_generator.state = json.loads(str(state["scenario_rng_json"]))
        self.environment_rng.bit_generator.state = json.loads(str(state["environment_rng_json"]))
        self.load_rng.bit_generator.state = json.loads(str(state["load_rng_json"]))
        scenario_group = state.get("episode_scenario_group")
        demand_seed = state.get("episode_demand_seed")
        self._episode_scenario_group = None if scenario_group is None else int(scenario_group)
        self._episode_demand_seed = None if demand_seed is None else int(demand_seed)


def load_group_for_rollout(args: argparse.Namespace, rollout_idx: int) -> int:
    return int(rollout_idx) % len(_load_strata_for_args(args))


def load_probability_for_group(args: argparse.Namespace, group_id: int) -> float:
    probabilities = _load_probabilities_for_args(args, len(_load_strata_for_args(args)))
    return float(probabilities[int(group_id)])


def load_assignments_for_update(
    args: argparse.Namespace,
    update_idx: int,
    rollouts: int,
    *,
    rollout_start_idx: int = 0,
    rng: np.random.Generator | None = None,
) -> list[tuple[float, int]]:
    """Return reproducible load values and stable PPO credit groups for one update."""

    if rollouts < 1:
        raise ValueError("rollouts must be positive")
    mode = getattr(args, "load_sampling_mode", "cyclic")
    if mode == "cyclic":
        return [
            (
                load_multiplier_for_rollout(args, rollout_start_idx + offset),
                load_group_for_rollout(args, rollout_start_idx + offset),
            )
            for offset in range(rollouts)
        ]
    if mode not in {"stratified-random", "distribution-random"}:
        raise ValueError(
            "load_sampling_mode must be 'cyclic', 'stratified-random', or 'distribution-random'"
        )

    strata = _load_strata_for_args(args)
    sample_rng = rng or np.random.default_rng(int(args.seed) + 910_001 + int(update_idx))
    if mode == "stratified-random":
        group_ids = np.arange(rollouts, dtype=np.int64) % len(strata)
        sample_rng.shuffle(group_ids)
    else:
        probabilities = _load_probabilities_for_args(args, len(strata))
        group_ids = sample_rng.choice(
            len(strata),
            size=rollouts,
            replace=True,
            p=np.asarray(probabilities, dtype=np.float64),
        )
    assignments: list[tuple[float, int]] = []
    for group_id_raw in group_ids:
        group_id = int(group_id_raw)
        low, high = strata[group_id]
        multiplier = low if np.isclose(low, high) else float(sample_rng.uniform(low, high))
        assignments.append((float(multiplier), group_id))
    return assignments


def episode_minutes_for_args(args: argparse.Namespace) -> int:
    minutes = getattr(args, "episode_minutes", None)
    if minutes is not None:
        return max(int(minutes), 1)
    hours = getattr(args, "episode_hours", None)
    if hours is not None:
        return max(int(round(float(hours) * 60.0)), 1)
    return 10


def rollout_start_minute(args: argparse.Namespace, rollout_idx: int, *, eval_mode: bool = False) -> float:
    if getattr(args, "arrival_profile", "daily") == "stationary":
        return 0.0
    mode = getattr(args, "rollout_start_mode", "beginning")
    if eval_mode:
        eval_mode_value = getattr(args, "eval_rollout_start_mode", "same")
        mode = mode if eval_mode_value == "same" else eval_mode_value
    if mode == "beginning":
        return 0.0
    interval = int(getattr(args, "deployment_interval_minutes", 10))
    total_minutes = episode_minutes_for_args(args)
    starts = list(range(0, max(total_minutes - interval + 1, 1), interval))
    if not starts:
        return 0.0
    if mode == "cycle-window":
        return float(starts[int(rollout_idx) % len(starts)])
    rng = np.random.default_rng(int(getattr(args, "seed", 2026)) + 100_000 + int(rollout_idx))
    return float(starts[int(rng.integers(0, len(starts)))])


def start_env_at_minute(env: EdgeComputingEnv, start_minute: float) -> None:
    if start_minute <= 0.0:
        return
    env.current_time_minute = float(start_minute)
    env.next_deployment_update_minute = float(start_minute)
    env.last_load_update_minute = float(start_minute)
    env.current_requests = env._generate_current_second_requests()
    env.current_request = env.current_requests[0] if env.current_requests else None


def scenario_seed_for_offset(args: argparse.Namespace, seed_offset: int = 0, *, group_by_refresh: bool = False) -> int:
    if getattr(args, "fixed_scenario", False):
        return int(args.seed)
    refresh = max(int(getattr(args, "scenario_refresh_episodes", 1)), 1)
    scenario_offset = seed_offset // refresh if group_by_refresh else seed_offset
    return int(args.seed + scenario_offset)


def demand_seed_for_training_rollout(args: argparse.Namespace, rollout_idx: int, episode_idx: int) -> int:
    if getattr(args, "fixed_scenario", False):
        return int(args.seed)
    if getattr(args, "demand_sampling_mode", "episode") == "rollout":
        scenario_group = int(rollout_idx)
    else:
        refresh = max(int(getattr(args, "scenario_refresh_episodes", 1)), 1)
        scenario_group = int(episode_idx) // refresh
    schedule = getattr(args, "demand_scenario_schedule", "sequential")
    if schedule == "sequential":
        scenario_offset = scenario_group
        return int(args.seed) + scenario_offset
    if schedule == "stream":
        scenario_seed = np.random.SeedSequence(int(args.seed)).spawn(3)[0]
        scenario_rng = np.random.default_rng(scenario_seed)
        draws = scenario_rng.integers(
            0,
            np.iinfo(np.int32).max,
            size=scenario_group + 1,
            endpoint=False,
        )
        return int(draws[-1])
    if schedule == "shuffled-pool":
        pool_size = max(int(getattr(args, "demand_scenario_pool_size", 32)), 1)
        pool_cycle, pool_position = divmod(scenario_group, pool_size)
        pool_rng = np.random.default_rng(int(args.seed) + 730_001 + pool_cycle)
        scenario_offset = int(pool_rng.permutation(pool_size)[pool_position])
        return int(args.seed) + scenario_offset
    raise ValueError("unknown demand_scenario_schedule")


def build_env(args: argparse.Namespace, seed_offset: int = 0, *, group_scenario_by_refresh: bool = False) -> EdgeComputingEnv:
    return EdgeComputingEnv(
        EdgeEnvConfig(
            seed=args.seed + seed_offset,
            physical_seed=args.seed if args.physical_seed is None else args.physical_seed,
            scenario_seed=scenario_seed_for_offset(args, seed_offset, group_by_refresh=group_scenario_by_refresh),
            num_users=args.num_users,
            num_edge_nodes=args.num_edge_nodes,
            num_service_types=args.num_service_types,
            episode_minutes=episode_minutes_for_args(args),
            deployment_interval_minutes=args.deployment_interval_minutes,
            arrival_profile=args.arrival_profile,
            mean_requests_per_minute=args.mean_requests_per_minute,
            active_user_ratio=args.active_user_ratio,
            active_user_request_rate_per_minute=args.active_user_request_rate_per_minute,
            traffic_scale=args.traffic_scale,
            demand_load_multiplier=load_multiplier_for_rollout(args, seed_offset),
            demand_load_group=load_group_for_rollout(args, seed_offset),
            task_compute_scale=args.task_compute_scale,
            task_data_scale=args.task_data_scale,
            edge_node_profile=getattr(args, "edge_node_profile", "synthetic-tiered"),
            service_workload_profile=getattr(args, "service_workload_profile", "legacy-random"),
            node_compute_capacity_scale=args.node_compute_capacity_scale,
            wired_link_bandwidth_scale=args.wired_link_bandwidth_scale,
            topology_k_nearest=args.topology_k_nearest,
            deadline_scale=args.deadline_scale,
            service_resource_fraction=args.service_resource_fraction,
            request_aggregation_window_seconds=args.request_aggregation_window_seconds,
            load_ewma_tau_minutes=args.load_ewma_tau_minutes,
            sampled_load_update_mode=getattr(args, "sampled_load_update_mode", "legacy-repeat"),
            network_constraint_mode=getattr(args, "network_constraint_mode", "edge-only"),
            service_calibration_mode=getattr(args, "service_calibration_mode", "legacy"),
            service_calibration_file=getattr(args, "service_calibration_file", None),
            service_calibration_document=getattr(args, "service_calibration_document", None),
            temporal_sampling_mode=getattr(args, "temporal_sampling_mode", "left-hold"),
            wireless_uplink_mbps=args.wireless_uplink_mbps,
            radio_rtt_ms=args.radio_rtt_ms,
        )
    )


def build_training_env(
    args: argparse.Namespace,
    *,
    rollout_idx: int,
    episode_idx: int,
    load_multiplier: float | None = None,
    load_group: int | None = None,
    demand_seed: int | None = None,
    environment_seed: int | None = None,
) -> EdgeComputingEnv:
    selected_demand_seed = (
        demand_seed_for_training_rollout(args, rollout_idx, episode_idx)
        if demand_seed is None
        else int(demand_seed)
    )
    selected_multiplier = (
        load_multiplier_for_rollout(args, rollout_idx)
        if load_multiplier is None
        else float(load_multiplier)
    )
    selected_group = (
        load_group_for_rollout(args, rollout_idx)
        if load_group is None
        else int(load_group)
    )
    return EdgeComputingEnv(
        EdgeEnvConfig(
            seed=args.seed + rollout_idx if environment_seed is None else int(environment_seed),
            physical_seed=args.seed if args.physical_seed is None else args.physical_seed,
            scenario_seed=selected_demand_seed,
            num_users=args.num_users,
            num_edge_nodes=args.num_edge_nodes,
            num_service_types=args.num_service_types,
            episode_minutes=episode_minutes_for_args(args),
            deployment_interval_minutes=args.deployment_interval_minutes,
            arrival_profile=args.arrival_profile,
            mean_requests_per_minute=args.mean_requests_per_minute,
            active_user_ratio=args.active_user_ratio,
            active_user_request_rate_per_minute=args.active_user_request_rate_per_minute,
            traffic_scale=args.traffic_scale,
            demand_load_multiplier=selected_multiplier,
            demand_load_group=selected_group,
            task_compute_scale=args.task_compute_scale,
            task_data_scale=args.task_data_scale,
            edge_node_profile=getattr(args, "edge_node_profile", "synthetic-tiered"),
            service_workload_profile=getattr(args, "service_workload_profile", "legacy-random"),
            node_compute_capacity_scale=args.node_compute_capacity_scale,
            wired_link_bandwidth_scale=args.wired_link_bandwidth_scale,
            topology_k_nearest=args.topology_k_nearest,
            deadline_scale=args.deadline_scale,
            service_resource_fraction=args.service_resource_fraction,
            request_aggregation_window_seconds=args.request_aggregation_window_seconds,
            load_ewma_tau_minutes=args.load_ewma_tau_minutes,
            sampled_load_update_mode=getattr(args, "sampled_load_update_mode", "legacy-repeat"),
            network_constraint_mode=getattr(args, "network_constraint_mode", "edge-only"),
            service_calibration_mode=getattr(args, "service_calibration_mode", "legacy"),
            service_calibration_file=getattr(args, "service_calibration_file", None),
            service_calibration_document=getattr(args, "service_calibration_document", None),
            temporal_sampling_mode=getattr(args, "temporal_sampling_mode", "left-hold"),
            wireless_uplink_mbps=args.wireless_uplink_mbps,
            radio_rtt_ms=args.radio_rtt_ms,
        )
    )


def traffic_rate_summary(env: EdgeComputingEnv) -> dict[str, float]:
    rates = []
    original_time = env.current_time_minute
    episode_minutes = max(int(env.config.episode_minutes), 1)
    for minute in range(episode_minutes):
        env.current_time_minute = float(minute)
        rates.append(env._arrival_rate_per_minute())
    env.current_time_minute = original_time
    values = np.asarray(rates, dtype=np.float64)
    return {
        "avg_requests_per_second": float(values.mean() / 60.0),
        "min_requests_per_second": float(values.min() / 60.0),
        "max_requests_per_second": float(values.max() / 60.0),
        "expected_requests_per_episode": float(values.sum()),
    }


def demand_profile_summary(env: EdgeComputingEnv) -> dict[str, float]:
    """Describe demand difficulty independently of either learned policy."""

    env._require_ready()
    assert env.scenario is not None
    popularity = np.mean(
        np.asarray([user.service_weights for user in env.scenario.users], dtype=np.float64),
        axis=0,
    )
    service_compute = np.asarray(
        [sum(stage.compute_gcycles_mean for stage in service.stages) for service in env.scenario.services],
        dtype=np.float64,
    ) * float(env.config.task_compute_scale)
    service_data = np.asarray(
        [
            service.input_mb_mean + sum(stage.output_mb_mean for stage in service.stages)
            for service in env.scenario.services
        ],
        dtype=np.float64,
    ) * float(env.config.task_data_scale)
    service_deadline = np.asarray(
        [service.deadline_s_mean for service in env.scenario.services],
        dtype=np.float64,
    )
    positive = popularity[popularity > 0.0]
    return {
        "demand_expected_compute_gcycles": float(popularity @ service_compute),
        "demand_expected_data_mb": float(popularity @ service_data),
        "demand_expected_deadline_s": float(popularity @ service_deadline),
        "demand_service_popularity_entropy": float(-np.sum(positive * np.log(positive))),
    }


class RolloutProgress:
    def __init__(
        self,
        *,
        label: str,
        target_requests: int | None,
        interval_seconds: float,
        episode_minutes: int,
        rollout_unit: str,
        deployment_interval_minutes: int,
        rollout_start_minute: float = 0.0,
        start_requests: float = 0.0,
        start_request_events: float = 0.0,
    ):
        self.label = label
        self.target_requests = target_requests
        self.interval_seconds = max(interval_seconds, 0.0) if tqdm is not None else 0.0
        self.episode_minutes = episode_minutes
        self.rollout_unit = rollout_unit
        self.deployment_interval_minutes = deployment_interval_minutes
        self.rollout_start_minute = rollout_start_minute
        self.start_requests = start_requests
        self.start_request_events = start_request_events
        self.started_at = time.monotonic()
        self.last_print_at = self.started_at
        self.printed = False
        self.progress_units = 0.0
        self.tqdm_bar = None
        if self.interval_seconds > 0:
            total_units = self._total_progress_units()
            self.tqdm_bar = tqdm(
                total=total_units,
                desc=self.label,
                unit="min" if self.rollout_unit in {"episode", "window"} else "req",
                dynamic_ncols=True,
                mininterval=self.interval_seconds,
                leave=True,
                bar_format="{desc}: {percentage:5.1f}%|{bar}| [{elapsed}<{remaining}, {rate_fmt}] {postfix}",
                file=sys.stdout,
            )

    def should_print(self) -> bool:
        if self.interval_seconds <= 0:
            return False
        now = time.monotonic()
        return not self.printed or now - self.last_print_at >= self.interval_seconds

    def maybe_print(
        self,
        env: EdgeComputingEnv,
        *,
        avg_reward: float = float("nan"),
        avg_train_reward: float = float("nan"),
        avg_latency_s: float | None = None,
        avg_valid_latency_s: float | None = None,
        avg_penalty_latency_s: float | None = None,
    ) -> None:
        if self.should_print():
            self._print_tqdm(
                env,
                now=time.monotonic(),
                avg_reward=avg_reward,
                avg_train_reward=avg_train_reward,
                avg_latency_s=avg_latency_s,
                avg_valid_latency_s=avg_valid_latency_s,
                avg_penalty_latency_s=avg_penalty_latency_s,
            )

    def finish(
        self,
        env: EdgeComputingEnv,
        *,
        avg_reward: float = float("nan"),
        avg_train_reward: float = float("nan"),
        avg_latency_s: float | None = None,
        avg_valid_latency_s: float | None = None,
        avg_penalty_latency_s: float | None = None,
    ) -> None:
        if self.interval_seconds <= 0 or self.tqdm_bar is None:
            return
        self._print_tqdm(
            env,
            now=time.monotonic(),
            final=True,
            avg_reward=avg_reward,
            avg_train_reward=avg_train_reward,
            avg_latency_s=avg_latency_s,
            avg_valid_latency_s=avg_valid_latency_s,
            avg_penalty_latency_s=avg_penalty_latency_s,
        )

    def _print_tqdm(
        self,
        env: EdgeComputingEnv,
        *,
        now: float,
        final: bool = False,
        avg_reward: float = float("nan"),
        avg_train_reward: float = float("nan"),
        avg_latency_s: float | None = None,
        avg_valid_latency_s: float | None = None,
        avg_penalty_latency_s: float | None = None,
    ) -> None:
        assert self.tqdm_bar is not None
        requests = max(float(env.metrics.get("requests", 0.0)) - self.start_requests, 0.0)
        request_events = int(max(float(env.metrics.get("request_events", 0.0)) - self.start_request_events, 0.0))
        episode_fraction = env.current_time_minute / max(float(self.episode_minutes), 1e-9)
        if self.rollout_unit == "episode":
            progress = min(episode_fraction, 1.0)
        elif self.rollout_unit == "window":
            elapsed_window_minutes = max(env.current_time_minute - self.rollout_start_minute, 0.0)
            progress = min(elapsed_window_minutes / max(float(self.deployment_interval_minutes), 1e-9), 1.0)
        else:
            progress = min(requests / max(float(self.target_requests or 1), 1.0), 1.0)
        if avg_latency_s is None:
            avg_latency_s = env.metrics["total_latency_s"] / max(requests, 1.0)
        if avg_valid_latency_s is None:
            avg_valid_latency_s = env.metrics["total_valid_latency_s"] / max(env.metrics["valid_requests"], 1.0)
        if avg_penalty_latency_s is None:
            avg_penalty_latency_s = env.metrics["total_penalty_latency_s"] / max(requests, 1.0)
        elapsed = max(now - self.started_at, 1e-9)
        total_windows = max(int(np.ceil(self.episode_minutes / max(self.deployment_interval_minutes, 1))), 1)
        current_window = min(int(env.current_time_minute // max(self.deployment_interval_minutes, 1)) + 1, total_windows)
        wall_event_rate = request_events / elapsed
        units = self._progress_units(env)
        delta = max(units - self.progress_units, 0.0)
        if delta > 0:
            self.tqdm_bar.update(delta)
            self.progress_units = units
        request_target = self.target_requests or requests or 1
        postfix = (
            f"R={_format_metric(avg_reward, 4)} "
            f"trainR={_format_metric(avg_train_reward, 4)} "
            f"Lat={avg_latency_s * 1000:.1f}ms "
            f"VLat={avg_valid_latency_s * 1000:.1f}ms "
            f"Pen={avg_penalty_latency_s * 1000:.1f}ms "
            f"win={current_window}/{total_windows} "
            f"t={env.current_time_minute:.1f}/{self.episode_minutes}min "
            f"req={_format_count(requests)}/{_format_count(request_target)} "
            f"speed={wall_event_rate:.1f}ev/s"
        )
        self.tqdm_bar.set_postfix_str(postfix, refresh=True)
        self.printed = True
        self.last_print_at = now
        if final:
            self.tqdm_bar.close()

    def _total_progress_units(self) -> float:
        if self.rollout_unit == "episode":
            return max(float(self.episode_minutes), 1.0)
        if self.rollout_unit == "window":
            return max(float(self.deployment_interval_minutes), 1e-9)
        return max(float(self.target_requests or 1), 1.0)

    def _progress_units(self, env: EdgeComputingEnv) -> float:
        if self.rollout_unit == "episode":
            return min(max(env.current_time_minute, 0.0), self._total_progress_units())
        if self.rollout_unit == "window":
            elapsed_window_minutes = max(env.current_time_minute - self.rollout_start_minute, 0.0)
            return min(elapsed_window_minutes, self._total_progress_units())
        return min(float(env.metrics.get("requests", 0.0)), self._total_progress_units())


def _format_metric(value: float, precision: int) -> str:
    if not np.isfinite(value):
        return "--"
    return f"{value:.{precision}f}"


def _format_count(value: float) -> str:
    value = float(value)
    if abs(value) >= 1_000_000:
        return f"{value / 1_000_000:.1f}M"
    if abs(value) >= 1_000:
        return f"{value / 1_000:.1f}K"
    return str(int(round(value)))


def estimate_episode_requests(env: EdgeComputingEnv) -> int:
    original_time = env.current_time_minute
    expected = 0.0
    total_minutes = int(env.config.episode_minutes)
    for minute in range(total_minutes):
        env.current_time_minute = float(minute)
        expected += env._arrival_rate_per_minute()
    env.current_time_minute = original_time
    return max(int(round(expected)), 1)


def _rollout_active(
    env: EdgeComputingEnv,
    *,
    max_requests: int,
    rollout_unit: str,
    stop_time_minute: float | None = None,
) -> bool:
    if env.done:
        return False
    if stop_time_minute is not None and env.current_time_minute >= stop_time_minute:
        return False
    if rollout_unit == "episode":
        return True
    if rollout_unit == "window":
        return True
    return env.metrics["requests"] < max_requests


def rollout(
    env: EdgeComputingEnv,
    agent: HierarchicalPPOAgent,
    max_requests: int,
    args: argparse.Namespace | None = None,
    deterministic: bool = False,
    record: bool = True,
    record_fast: bool | None = None,
    record_slow: bool | None = None,
    deterministic_fast: bool | None = None,
    deterministic_slow: bool | None = None,
    reward_scale: float = 1.0,
    train_mode: str = "joint",
    frozen_slow_policy: SlowGreedyDeploymentPolicy | None = None,
    progress_label: str = "",
    progress_interval_seconds: float = 0.0,
    rollout_unit: str = "requests",
    reset_env: bool = True,
) -> dict[str, float]:
    if args is None:
        args = argparse.Namespace(
            reward_mode="latency",
            compute_hotspot_threshold=0.60,
            link_hotspot_threshold=0.60,
            resource_active_load_threshold=0.01,
            compute_hotspot_coef=0.0,
            link_hotspot_coef=0.0,
            compute_imbalance_coef=0.0,
            link_imbalance_coef=0.0,
            idle_deployed_node_coef=0.0,
            fast_congestion_credit_coef=1.0,
        )
    record_fast = record if record_fast is None else bool(record_fast)
    record_slow = record if record_slow is None else bool(record_slow)
    deterministic_fast = deterministic if deterministic_fast is None else bool(deterministic_fast)
    deterministic_slow = deterministic if deterministic_slow is None else bool(deterministic_slow)
    if reset_env:
        env.reset()
    if env.current_time_minute <= 1e-9:
        agent.reset_episode_context()
    if record:
        agent.last_slow_window_metrics = {}
    if frozen_slow_policy is None:
        frozen_slow_policy = SlowGreedyDeploymentPolicy()
    rewards: list[float] = []
    train_rewards: list[float] = []
    train_latency_costs: list[float] = []
    train_resource_penalties: list[float] = []
    diagnostic_resource_penalties: list[float] = []
    compute_hotspot_penalties: list[float] = []
    link_hotspot_penalties: list[float] = []
    compute_imbalance_penalties: list[float] = []
    link_imbalance_penalties: list[float] = []
    idle_deployed_node_penalties: list[float] = []
    fast_externality_costs: list[float] = []
    fast_counterfactual_regret_costs: list[float] = []
    fast_kkt_reward_residuals: list[float] = []
    fast_oracle_latency_gaps: list[float] = []
    fast_oracle_relative_gaps: list[float] = []
    fast_oracle_weights: list[float] = []
    latencies: list[float] = []
    compute_latencies: list[float] = []
    link_latencies: list[float] = []
    access_latencies: list[float] = []
    propagation_latencies: list[float] = []
    instantaneous_compute_work: list[float] = []
    instantaneous_avg_compute_pressures: list[float] = []
    instantaneous_max_compute_pressures: list[float] = []
    instantaneous_p95_compute_pressures: list[float] = []
    valid_latencies: list[float] = []
    valid_weights: list[float] = []
    penalty_latencies: list[float] = []
    weights: list[float] = []
    window_latencies: dict[int, list[tuple[float, float]]] = {}
    scheduled_replica_counts: dict[tuple[int, int, int], float] = {}
    cross_node_stage_transitions = 0.0
    total_stage_transitions = 0.0
    start_metrics = dict(env.metrics)
    rollout_start_minute = env.current_time_minute
    planning_wall_s = scheduling_wall_s = settlement_wall_s = 0.0
    stop_time_minute = None
    if rollout_unit == "window":
        stop_time_minute = min(
            rollout_start_minute + float(env.config.deployment_interval_minutes),
            float(env.config.episode_minutes),
        )
    represented_seconds = 1.0
    if record and rollout_unit == "window":
        from edge_drl.sampling import interval_seconds
        sampled_seconds = int(getattr(args, "sampled_seconds_per_window", 0))
        window_seconds = float(env.config.deployment_interval_minutes * 60)
        represented_seconds = interval_seconds(window_seconds, sampled_seconds,
                                               float(getattr(args, "sampling_max_interval_seconds", 0.)))
    if rollout_unit == "requests":
        target_requests = max_requests
    elif rollout_unit == "window":
        target_requests = max(
            int(round(estimate_episode_requests(env) * env.config.deployment_interval_minutes / max(env.config.episode_minutes, 1.0))),
            1,
        )
    else:
        target_requests = estimate_episode_requests(env)
    progress = RolloutProgress(
        label=progress_label,
        target_requests=target_requests,
        interval_seconds=progress_interval_seconds,
        episode_minutes=env.config.episode_minutes,
        rollout_unit=rollout_unit,
        deployment_interval_minutes=env.config.deployment_interval_minutes,
        rollout_start_minute=rollout_start_minute,
        start_requests=float(start_metrics.get("requests", 0.0)),
        start_request_events=float(start_metrics.get("request_events", 0.0)),
    )
    oracle_requests_remaining = (
        int(getattr(args, "fast_oracle_diagnostic_requests", 0))
        if record
        else 0
    )
    fast_counterfactual_coef = float(
        getattr(
            args,
            "fast_counterfactual_credit_current_coef",
            getattr(args, "fast_counterfactual_credit_coef", 0.0),
        )
    )
    while _rollout_active(env, max_requests=max_requests, rollout_unit=rollout_unit, stop_time_minute=stop_time_minute):
        step_represented_seconds = represented_seconds
        if stop_time_minute is not None:
            remaining_seconds = max((stop_time_minute - env.current_time_minute) * 60.0, 0.0)
            if remaining_seconds < 1.0 - 1e-9:
                env.current_time_minute = stop_time_minute
                break
            step_represented_seconds = min(step_represented_seconds, remaining_seconds)
        if record:
            env.sample_interval_requests(step_represented_seconds)
        requests = list(env.current_requests)
        if train_mode == "fast-only":
            started = time.perf_counter()
            if env.needs_deployment_update:
                env.apply_deployment(frozen_slow_policy.act(env))
            planning_wall_s += time.perf_counter()-started
            started = time.perf_counter()
            actions = agent.fast_agent.schedule_batch(
                env,
                requests,
                deterministic=deterministic_fast,
                record=record_fast,
            )
            scheduling_wall_s += time.perf_counter()-started
        else:
            started = time.perf_counter()
            agent.maybe_update_deployment(env, deterministic=deterministic_slow, record=record_slow)
            planning_wall_s += time.perf_counter()-started
            started = time.perf_counter()
            actions = agent.fast_agent.schedule_batch(
                env,
                requests,
                deterministic=deterministic_fast,
                record=record_fast,
            )
            scheduling_wall_s += time.perf_counter()-started
        batch_counterfactual_regrets = (
            [
                agent.fast_agent.stage_counterfactual_regrets(env, request, schedule)
                for request, schedule in zip(requests, actions)
            ]
            if record_fast and not agent.fast_agent.batch_credit and fast_counterfactual_coef > 0.0
            else [[] for _ in requests]
        )
        batch_slow_marginal_values = (
            [
                agent.fast_agent.stage_selected_node_marginal_values(
                    env,
                    request,
                    schedule,
                )
                for request, schedule in zip(requests, actions)
            ]
            if record_slow
            and not agent.slow_agent.team_window_credit
            and float(getattr(args, "slow_counterfactual_credit_coef", 0.0)) > 0.0
            else [None for _ in requests]
        )
        if record_slow and not agent.slow_agent.team_window_credit and getattr(args, "slow_replica_ablation_samples", 0) > 0:
            agent.observe_replica_ablation(env, requests)
        if oracle_requests_remaining > 0:
            for request, schedule in zip(requests, actions):
                if oracle_requests_remaining <= 0:
                    break
                oracle_schedule = agent.fast_agent.chain_oracle_schedule(
                    env,
                    request,
                    beam_width=int(getattr(args, "fast_oracle_beam_width", 32)),
                    candidates_per_stage=int(
                        getattr(args, "fast_oracle_candidates_per_stage", 8)
                    ),
                )
                policy_isolated = env.evaluate_schedule(request, schedule)
                oracle_isolated = env.evaluate_schedule(request, oracle_schedule)
                policy_latency = float(policy_isolated["latency_s"])
                oracle_latency = float(oracle_isolated["latency_s"])
                gap = max(policy_latency - oracle_latency, 0.0)
                fast_oracle_latency_gaps.append(gap)
                fast_oracle_relative_gaps.append(gap / max(policy_latency, 1e-9))
                fast_oracle_weights.append(float(request.request_count))
                oracle_requests_remaining -= 1
        deployment_window = int(env.metrics["deployment_updates"])
        started = time.perf_counter()
        _, _, done, batch_info = env.step(actions, represented_seconds=step_represented_seconds)
        settlement_wall_s += time.perf_counter()-started
        group_infos = batch_info["group_infos"]
        tick_kkt_predicted_total = 0.0
        tick_kkt_actual_total = 0.0
        tick_has_kkt_credit = False
        for group_idx, (request, info) in enumerate(zip(requests, group_infos)):
            request_count = float(info.get("request_count", request.request_count))
            train_reward_info = _training_reward_components(info, env, args)
            train_reward = train_reward_info["train_reward"]
            stage_latency_costs = _stage_latency_costs(
                info,
                env,
                request,
                include_access=not bool(
                    getattr(args, "fast_controllable_latency_credit", False)
                ),
            )
            stage_externality_costs = _stage_congestion_externality_costs(info, env, request)
            fast_externality_costs.append(float(sum(stage_externality_costs)))
            stage_counterfactual_regrets = batch_counterfactual_regrets[group_idx]
            fast_counterfactual_regret_costs.append(
                float(sum(stage_counterfactual_regrets))
            )
            causal_kkt_costs = (
                agent.fast_agent.consume_pending_kkt_stage_costs()
                if record_fast
                else None
            )
            if causal_kkt_costs is not None:
                if len(causal_kkt_costs) != len(stage_latency_costs):
                    raise RuntimeError("causal KKT stage costs do not match the request stage count")
                fast_stage_rewards = [
                    -float(cost) * reward_scale for cost in causal_kkt_costs
                ]
                tick_has_kkt_credit = True
                tick_kkt_predicted_total += request_count * float(sum(causal_kkt_costs))
                tick_kkt_actual_total += request_count * float(
                    info["compute_delay_s"]
                    + info["link_delay_s"]
                    + info["propagation_delay_s"]
                )
            else:
                fast_stage_rewards = [
                    -float(
                        latency_cost
                        + args.fast_congestion_credit_coef * externality_cost
                        + fast_counterfactual_coef * counterfactual_regret
                    )
                    * reward_scale
                    for latency_cost, externality_cost, counterfactual_regret in zip(
                        stage_latency_costs,
                        stage_externality_costs,
                        stage_counterfactual_regrets or [0.0] * len(stage_latency_costs),
                    )
                ]
            stage_transitions = float(max(len(info["stage_nodes"]) - 1, 0) * request_count)
            cross_stage_transitions = float(
                sum(
                    previous_node != next_node
                    for previous_node, next_node in zip(info["stage_nodes"], info["stage_nodes"][1:])
                )
                * request_count
            )
            if record_fast or record_slow:
                agent.observe_step_reward(
                    train_reward * reward_scale,
                    stage_count=len(request.stage_compute_gcycles),
                    done=bool(done and group_idx == len(group_infos) - 1),
                    weight=request_count,
                    fast_stage_rewards=fast_stage_rewards,
                    fast_batch_end=group_idx == len(group_infos) - 1,
                    fast_multiplicity=float(request.request_count),
                    slow_reward=-float(info["latency_s"]) * reward_scale,
                    latency_s=float(info["latency_s"]),
                    penalty_latency_s=float(info["penalty_latency_s"]),
                    deadline_s=float(request.deadline_s),
                    invalid=not bool(info["valid"]),
                    max_node_compute_load=float(np.max(env.node_compute_load)),
                    max_link_load=float(np.max(env.link_load[np.isfinite(env.link_load)]))
                    if np.any(np.isfinite(env.link_load))
                    else 0.0,
                    cross_stage_transitions=cross_stage_transitions,
                    stage_transitions=stage_transitions,
                    stage_transition_data_mb=list(
                        request.stage_output_mb[: max(len(request.stage_compute_gcycles) - 1, 0)]
                    ),
                    service_id=int(request.service_id),
                    stage_nodes=[int(node_id) for node_id in info["stage_nodes"]],
                    slow_stage_costs=stage_latency_costs,
                    settlement_info=info,
                    slow_stage_marginal_values=batch_slow_marginal_values[group_idx],
                    env=env,
                    record_fast=record_fast,
                    record_slow=record_slow,
                )
            rewards.append(float(info["reward"]))
            train_rewards.append(float(train_reward))
            train_latency_costs.append(float(train_reward_info["train_latency_cost_s"]))
            train_resource_penalties.append(float(train_reward_info["train_resource_penalty"]))
            diagnostic_resource_penalties.append(float(train_reward_info["diagnostic_resource_penalty"]))
            compute_hotspot_penalties.append(float(train_reward_info["compute_hotspot_penalty"]))
            link_hotspot_penalties.append(float(train_reward_info["link_hotspot_penalty"]))
            compute_imbalance_penalties.append(float(train_reward_info["compute_imbalance_penalty"]))
            link_imbalance_penalties.append(float(train_reward_info["link_imbalance_penalty"]))
            idle_deployed_node_penalties.append(float(train_reward_info["idle_deployed_node_penalty"]))
            latencies.append(float(info["latency_s"]))
            compute_latencies.append(float(info["compute_delay_s"]))
            link_latencies.append(float(info["link_delay_s"]))
            access_latencies.append(float(info["access_delay_s"]))
            propagation_latencies.append(float(info["propagation_delay_s"]))
            instantaneous_compute_work.append(float(info["instantaneous_compute_work_gcycles"]))
            instantaneous_avg_compute_pressures.append(float(info["instantaneous_avg_compute_pressure"]))
            instantaneous_max_compute_pressures.append(float(info["instantaneous_max_compute_pressure"]))
            instantaneous_p95_compute_pressures.append(float(info["instantaneous_p95_compute_pressure"]))
            penalty_latencies.append(float(info["penalty_latency_s"]))
            if info["valid"]:
                valid_latencies.append(float(info["physical_latency_s"]))
                valid_weights.append(request_count)
                _accumulate_schedule_usage(
                    scheduled_replica_counts,
                    request.service_id,
                    info["stage_nodes"],
                    request_count,
                )
                for previous_node, next_node in zip(info["stage_nodes"], info["stage_nodes"][1:]):
                    total_stage_transitions += request_count
                    if previous_node != next_node:
                        cross_node_stage_transitions += request_count
            weights.append(request_count)
            window_latencies.setdefault(deployment_window, []).append((float(info["latency_s"]), request_count))
        if tick_has_kkt_credit:
            fast_kkt_reward_residuals.append(
                float(tick_kkt_predicted_total - tick_kkt_actual_total)
            )
        if record_slow and done and not group_infos:
            agent.flush_slow_window_reward(done=True, env=env)
        if progress.should_print():
            progress.maybe_print(
                env,
                avg_reward=_weighted_mean(rewards, weights),
                avg_train_reward=_weighted_mean(train_rewards, weights),
                avg_latency_s=_weighted_mean(latencies, weights),
                avg_valid_latency_s=_weighted_mean(valid_latencies, valid_weights),
                avg_penalty_latency_s=_weighted_mean(penalty_latencies, weights),
            )
    progress.finish(
        env,
        avg_reward=_weighted_mean(rewards, weights),
        avg_train_reward=_weighted_mean(train_rewards, weights),
        avg_latency_s=_weighted_mean(latencies, weights),
        avg_valid_latency_s=_weighted_mean(valid_latencies, valid_weights),
        avg_penalty_latency_s=_weighted_mean(penalty_latencies, weights),
    )
    if (
        record_slow
        and agent.slow_agent.pending_window_id is not None
        and (env.done or env.needs_deployment_update)
    ):
        agent.flush_slow_window_reward(done=env.done, env=env)
    slow_window_metrics = {
        "slow_window_return": float("nan"),
        "slow_window_latency_return": float("nan"),
        "slow_window_avg_latency": float("nan"),
        "slow_window_p95_latency": float("nan"),
        "slow_tail_latency_cost": float("nan"),
        "slow_colocation_credit_coef": float("nan"),
        "slow_colocation_cost": float("nan"),
        "slow_cross_stage_transition_rate": float("nan"),
        "slow_colocation_rate": float("nan"),
        "slow_data_weighted_cross_stage_rate": float("nan"),
        "slow_shared_return_credit": float("nan"),
        "slow_incremental_add_actions": 0.0,
        "slow_incremental_stop_actions": 0.0,
        "slow_budget_fraction": 0.0,
        "slow_budget_feasible_capacity": 0.0,
        "slow_budget_replica_slot_upper_bound": 0.0,
        "slow_budget_extra_replicas": 0.0,
        "slow_budget_allocated_replicas": 0.0,
        "slow_budget_execution_ratio": 1.0,
        "slow_budget_available_memory_gb": 0.0,
        "slow_budget_available_storage_gb": 0.0,
        "slow_budget_target_memory_gb": 0.0,
        "slow_budget_target_storage_gb": 0.0,
        "slow_budget_used_memory_gb": 0.0,
        "slow_budget_used_storage_gb": 0.0,
        "slow_budget_memory_fill_ratio": 1.0,
        "slow_budget_storage_fill_ratio": 1.0,
        "slow_replica_ablation_samples": 0.0,
        "slow_replica_ablation_mean_s": 0.0,
        "slow_stop_ablation_value_s": 0.0,
        "slow_deployment_memory_cost": float("nan"),
        "slow_deployment_storage_cost": float("nan"),
        "slow_migration_cost": float("nan"),
        "slow_deadline_violation_cost": float("nan"),
        "slow_factorized_stage_return_mean": float("nan"),
        "slow_factorized_stage_return_std": float("nan"),
        "slow_factorized_count_return_mean": float("nan"),
        "slow_factorized_count_return_std": float("nan"),
        "slow_count_effective_replicas_per_stage": float("nan"),
        "slow_count_redundant_replica_fraction": float("nan"),
        "slow_count_unused_replica_fraction": float("nan"),
        "slow_count_unused_replica_cost": float("nan"),
        "slow_count_replica_imbalance_fraction": float("nan"),
        "slow_count_replica_efficiency_cost": float("nan"),
        "slow_placement_node_compute_load": float("nan"),
        "slow_placement_node_compute_cost": float("nan"),
        "slow_counterfactual_marginal_value": float("nan"),
        "slow_counterfactual_samples": 0.0,
        "slow_stage_ablation_covered_stages": 0.0,
        "slow_stage_ablation_credit_actions": 0.0,
        "slow_stage_ablation_credit_fraction": 0.0,
        "slow_deployment_memory_fraction": float("nan"),
        "slow_deployment_storage_fraction": float("nan"),
        "slow_migration_fraction": float("nan"),
        **(agent.last_slow_window_metrics if record else {}),
    }
    window_stats = _deployment_window_latency_stats(window_latencies)
    replica_stats = _deployment_replica_stats(env)
    resource_stats = _resource_usage_stats(env, args)
    schedule_usage_stats = _schedule_usage_stats(
        env,
        scheduled_replica_counts,
        cross_node_stage_transitions=cross_node_stage_transitions,
        total_stage_transitions=total_stage_transitions,
    )
    demand_stats = demand_profile_summary(env)
    rollout_requests = float(env.metrics["requests"] - start_metrics.get("requests", 0.0))
    rollout_request_events = float(env.metrics["request_events"] - start_metrics.get("request_events", 0.0))
    rollout_invalid_actions = float(env.metrics["invalid_actions"] - start_metrics.get("invalid_actions", 0.0))
    rollout_valid_requests = float(env.metrics["valid_requests"] - start_metrics.get("valid_requests", 0.0))
    rollout_deadline_violations = float(env.metrics["deadline_violations"] - start_metrics.get("deadline_violations", 0.0))
    rollout_deployment_updates = float(env.metrics["deployment_updates"] - start_metrics.get("deployment_updates", 0.0))
    rollout_settlement_steps = float(env.metrics["settlement_steps"] - start_metrics.get("settlement_steps", 0.0))
    rollout_logical_steps = float(env.metrics["time_steps"] - start_metrics.get("time_steps", 0.0))
    rollout_duration_minutes = max(env.current_time_minute - rollout_start_minute, 0.0)
    return {
        "requests": rollout_requests,
        "slow_planning_wall_s":planning_wall_s,
        "fast_scheduling_wall_s":scheduling_wall_s,
        "environment_settlement_wall_s":settlement_wall_s,
        "request_events": rollout_request_events,
        "sampled_request_events": float(env.metrics.get("sampled_request_events", 0.) - start_metrics.get("sampled_request_events", 0.)),
        "settlement_steps": rollout_settlement_steps,
        "logical_steps": rollout_logical_steps,
        "temporal_sampling_fraction": float(rollout_settlement_steps / max(rollout_logical_steps, 1.0)),
        "simulated_hours": float(rollout_duration_minutes / 60.0),
        "episode_fraction": float(env.current_time_minute / max(env.config.episode_minutes, 1e-9)),
        "episode_complete": float(env.done),
        "avg_reward": _weighted_mean(rewards, weights),
        "avg_train_reward": _weighted_mean(train_rewards, weights),
        "avg_train_latency_cost_s": _weighted_mean(train_latency_costs, weights),
        "avg_fast_externality_cost_s": _weighted_mean(fast_externality_costs, weights),
        "avg_fast_counterfactual_regret_s": _weighted_mean(
            fast_counterfactual_regret_costs,
            weights,
        ),
        "avg_fast_kkt_reward_residual_s": (
            float(np.mean(np.abs(fast_kkt_reward_residuals)))
            if fast_kkt_reward_residuals
            else 0.0
        ),
        "max_fast_kkt_reward_residual_s": (
            float(np.max(np.abs(fast_kkt_reward_residuals)))
            if fast_kkt_reward_residuals
            else 0.0
        ),
        "fast_counterfactual_credit_coef": fast_counterfactual_coef,
        "fast_oracle_samples": float(len(fast_oracle_latency_gaps)),
        "avg_fast_oracle_latency_gap_s": _weighted_mean(
            fast_oracle_latency_gaps,
            fast_oracle_weights,
        ),
        "avg_fast_oracle_relative_gap": _weighted_mean(
            fast_oracle_relative_gaps,
            fast_oracle_weights,
        ),
        "avg_train_resource_penalty": _weighted_mean(train_resource_penalties, weights),
        "avg_diagnostic_resource_penalty": _weighted_mean(diagnostic_resource_penalties, weights),
        "avg_compute_hotspot_penalty": _weighted_mean(compute_hotspot_penalties, weights),
        "avg_link_hotspot_penalty": _weighted_mean(link_hotspot_penalties, weights),
        "avg_compute_imbalance_penalty": _weighted_mean(compute_imbalance_penalties, weights),
        "avg_link_imbalance_penalty": _weighted_mean(link_imbalance_penalties, weights),
        "avg_idle_deployed_node_penalty": _weighted_mean(idle_deployed_node_penalties, weights),
        "avg_latency_s": _weighted_mean(latencies, weights),
        "p95_latency_s": _weighted_percentile(latencies, weights, 95.0),
        "avg_compute_latency_s": _weighted_mean(compute_latencies, weights),
        "avg_link_latency_s": _weighted_mean(link_latencies, weights),
        "avg_access_latency_s": _weighted_mean(access_latencies, weights),
        "avg_propagation_latency_s": _weighted_mean(propagation_latencies, weights),
        "avg_instantaneous_compute_work_gcycles": _weighted_mean(instantaneous_compute_work, weights),
        "avg_instantaneous_compute_pressure": _weighted_mean(instantaneous_avg_compute_pressures, weights),
        "avg_max_instantaneous_compute_pressure": _weighted_mean(instantaneous_max_compute_pressures, weights),
        "avg_p95_instantaneous_compute_pressure": _weighted_mean(instantaneous_p95_compute_pressures, weights),
        "avg_valid_latency_s": _weighted_mean(valid_latencies, valid_weights),
        "p95_valid_latency_s": _weighted_percentile(valid_latencies, valid_weights, 95.0),
        "valid_requests": rollout_valid_requests,
        "avg_penalty_latency_s": _weighted_mean(penalty_latencies, weights),
        "penalty_latency_share": _weighted_mean(penalty_latencies, weights) / max(_weighted_mean(latencies, weights), 1e-9),
        "invalid_actions": rollout_invalid_actions,
        "invalid_action_rate": float(rollout_invalid_actions / max(rollout_requests, 1.0)),
        "deadline_violation_rate": float(rollout_deadline_violations / max(rollout_requests, 1.0)),
        "deployment_updates": rollout_deployment_updates,
        **demand_stats,
        **slow_window_metrics,
        **window_stats,
        **replica_stats,
        **resource_stats,
        **schedule_usage_stats,
    }


def _weighted_mean(values: list[float], weights: list[float]) -> float:
    if not values:
        return 0.0
    values_np = np.asarray(values, dtype=np.float64)
    weights_np = np.asarray(weights, dtype=np.float64)
    return float(np.average(values_np, weights=weights_np))


def _weighted_percentile(values: list[float], weights: list[float], percentile: float) -> float:
    if not values:
        return 0.0
    values_np = np.asarray(values, dtype=np.float64)
    weights_np = np.asarray(weights, dtype=np.float64)
    order = np.argsort(values_np)
    sorted_values = values_np[order]
    sorted_weights = weights_np[order]
    cumulative = np.cumsum(sorted_weights)
    threshold = percentile / 100.0 * cumulative[-1]
    return float(sorted_values[np.searchsorted(cumulative, threshold, side="left")])


def _deployment_window_latency_stats(window_latencies: dict[int, list[tuple[float, float]]]) -> dict[str, float]:
    non_empty = [(window, values) for window, values in sorted(window_latencies.items()) if values]
    if not non_empty:
        return {
            "first_window_avg_latency_s": float("nan"),
            "last_window_avg_latency_s": float("nan"),
            "window_latency_delta_s": float("nan"),
        }
    first_values, first_weights = zip(*non_empty[0][1])
    last_values, last_weights = zip(*non_empty[-1][1])
    first_avg = _weighted_mean(list(first_values), list(first_weights))
    last_avg = _weighted_mean(list(last_values), list(last_weights))
    return {
        "first_window_avg_latency_s": first_avg,
        "last_window_avg_latency_s": last_avg,
        "window_latency_delta_s": last_avg - first_avg,
    }


def _deployment_replica_stats(env: EdgeComputingEnv) -> dict[str, float]:
    if env.deployment is None or env.scenario is None:
        return {
            "avg_replicas_per_stage": float("nan"),
            "min_replicas_per_stage": float("nan"),
            "max_replicas_per_stage": float("nan"),
            "single_replica_stage_rate": float("nan"),
            "total_deployed_replicas": float("nan"),
        }
    counts = []
    for service in env.scenario.services:
        for stage in service.stages:
            counts.append(float(env.deployment[service.service_id, stage.stage_id].sum()))
    if not counts:
        return {
            "avg_replicas_per_stage": float("nan"),
            "min_replicas_per_stage": float("nan"),
            "max_replicas_per_stage": float("nan"),
            "single_replica_stage_rate": float("nan"),
            "total_deployed_replicas": float("nan"),
        }
    counts_np = np.asarray(counts, dtype=np.float64)
    return {
        "avg_replicas_per_stage": float(counts_np.mean()),
        "min_replicas_per_stage": float(counts_np.min()),
        "max_replicas_per_stage": float(counts_np.max()),
        "single_replica_stage_rate": float(np.mean(counts_np <= 1.0)),
        "total_deployed_replicas": float(counts_np.sum()),
    }


def _accumulate_schedule_usage(
    usage: dict[tuple[int, int, int], float],
    service_id: int,
    stage_nodes: list[int] | tuple[int, ...],
    request_count: float,
) -> None:
    for stage_id, node_id in enumerate(stage_nodes):
        key = (int(service_id), int(stage_id), int(node_id))
        usage[key] = usage.get(key, 0.0) + float(request_count)


def _schedule_usage_stats(
    env: EdgeComputingEnv,
    usage: dict[tuple[int, int, int], float],
    *,
    cross_node_stage_transitions: float,
    total_stage_transitions: float,
) -> dict[str, float]:
    if env.scenario is None or env.deployment is None:
        return {
            "scheduled_stage_invocations": float("nan"),
            "used_replica_rate": float("nan"),
            "idle_replica_rate": float("nan"),
            "used_replicas_per_stage": float("nan"),
            "avg_replica_use_entropy": float("nan"),
            "avg_replica_use_top1_share": float("nan"),
            "cross_node_stage_transition_rate": float("nan"),
        }

    deployed_total = 0
    used_total = 0
    used_per_stage = []
    entropies = []
    top1_shares = []
    scheduled_stage_invocations = float(sum(usage.values()))

    for service in env.scenario.services:
        for stage in service.stages:
            deployed_nodes = np.flatnonzero(env.deployment[service.service_id, stage.stage_id])
            deployed_total += int(len(deployed_nodes))
            counts = np.asarray(
                [usage.get((service.service_id, stage.stage_id, int(node_id)), 0.0) for node_id in deployed_nodes],
                dtype=np.float64,
            )
            used = int(np.count_nonzero(counts > 0.0))
            used_total += used
            used_per_stage.append(float(used))
            total = float(counts.sum())
            if total > 0.0 and counts.size > 1:
                probabilities = counts[counts > 0.0] / total
                entropy = -float(np.sum(probabilities * np.log(probabilities)))
                entropies.append(entropy / max(np.log(float(counts.size)), 1e-9))
                top1_shares.append(float(counts.max() / total))
            elif total > 0.0:
                entropies.append(0.0)
                top1_shares.append(1.0)

    used_replica_rate = used_total / max(float(deployed_total), 1.0)
    return {
        "scheduled_stage_invocations": scheduled_stage_invocations,
        "used_replica_rate": float(used_replica_rate),
        "idle_replica_rate": float(1.0 - used_replica_rate),
        "used_replicas_per_stage": float(np.mean(used_per_stage)) if used_per_stage else float("nan"),
        "avg_replica_use_entropy": float(np.mean(entropies)) if entropies else 0.0,
        "avg_replica_use_top1_share": float(np.mean(top1_shares)) if top1_shares else 0.0,
        "cross_node_stage_transition_rate": float(cross_node_stage_transitions / max(total_stage_transitions, 1.0)),
    }


def _resource_usage_stats(env: EdgeComputingEnv, args: argparse.Namespace | None = None) -> dict[str, float]:
    if env.scenario is None or env.deployment is None:
        return {
            "avg_node_compute_load": float("nan"),
            "max_node_compute_load": float("nan"),
            "p95_node_compute_load": float("nan"),
            "std_node_compute_load": float("nan"),
            "active_node_rate": float("nan"),
            "hot_node_rate": float("nan"),
            "avg_link_load": float("nan"),
            "max_link_load": float("nan"),
            "p95_link_load": float("nan"),
            "std_link_load": float("nan"),
            "active_link_rate": float("nan"),
            "hot_link_rate": float("nan"),
            "avg_node_memory_util": float("nan"),
            "max_node_memory_util": float("nan"),
            "avg_node_storage_util": float("nan"),
            "max_node_storage_util": float("nan"),
            "avg_service_memory_util": float("nan"),
            "max_service_memory_util": float("nan"),
            "avg_service_storage_util": float("nan"),
            "max_service_storage_util": float("nan"),
            "deployed_node_rate": float("nan"),
            "idle_deployed_node_rate": float("nan"),
        }

    compute_load = np.asarray(env.node_compute_load, dtype=np.float64)
    finite_links = np.isfinite(env.scenario.bandwidth_mb_s) & env.scenario.adjacency
    np.fill_diagonal(finite_links, False)
    link_load = np.asarray(env.link_load[finite_links], dtype=np.float64)

    memory_used = np.zeros(env.config.num_edge_nodes, dtype=np.float64)
    storage_used = np.zeros(env.config.num_edge_nodes, dtype=np.float64)
    for service in env.scenario.services:
        for stage in service.stages:
            placed = env.deployment[service.service_id, stage.stage_id]
            memory_used += placed * stage.memory_gb
            storage_used += placed * stage.storage_gb

    memory_capacity = np.asarray([node.memory_gb for node in env.scenario.nodes], dtype=np.float64)
    storage_capacity = np.asarray([node.storage_gb for node in env.scenario.nodes], dtype=np.float64)
    memory_util = memory_used / np.maximum(memory_capacity, 1e-9)
    storage_util = storage_used / np.maximum(storage_capacity, 1e-9)
    service_memory_util = memory_used / np.maximum(env.service_memory_capacities(), 1e-9)
    service_storage_util = storage_used / np.maximum(env.service_storage_capacities(), 1e-9)
    deployed_nodes = np.logical_or(memory_used > 0.0, storage_used > 0.0)
    active_threshold = float(getattr(args, "resource_active_load_threshold", 0.01))
    hot_threshold = float(getattr(args, "compute_hotspot_threshold", 0.60))
    link_hot_threshold = float(getattr(args, "link_hotspot_threshold", hot_threshold))

    if link_load.size == 0:
        link_load = np.asarray([float("nan")], dtype=np.float64)
    finite_link_load = link_load[np.isfinite(link_load)]
    if finite_link_load.size == 0:
        finite_link_load = np.asarray([float("nan")], dtype=np.float64)

    return {
        "avg_node_compute_load": float(np.mean(compute_load)),
        "max_node_compute_load": float(np.max(compute_load)),
        "p95_node_compute_load": float(np.percentile(compute_load, 95)),
        "std_node_compute_load": float(np.std(compute_load)),
        "active_node_rate": float(np.mean(compute_load > active_threshold)),
        "hot_node_rate": float(np.mean(compute_load > hot_threshold)),
        "avg_link_load": float(np.nanmean(link_load)),
        "max_link_load": float(np.nanmax(link_load)),
        "p95_link_load": float(np.nanpercentile(link_load, 95)),
        "std_link_load": float(np.nanstd(link_load)),
        "active_link_rate": float(np.mean(finite_link_load > active_threshold)),
        "hot_link_rate": float(np.mean(finite_link_load > link_hot_threshold)),
        "avg_node_memory_util": float(np.mean(memory_util)),
        "max_node_memory_util": float(np.max(memory_util)),
        "avg_node_storage_util": float(np.mean(storage_util)),
        "max_node_storage_util": float(np.max(storage_util)),
        "avg_service_memory_util": float(np.mean(service_memory_util)),
        "max_service_memory_util": float(np.max(service_memory_util)),
        "avg_service_storage_util": float(np.mean(service_storage_util)),
        "max_service_storage_util": float(np.max(service_storage_util)),
        "deployed_node_rate": float(np.mean(deployed_nodes)),
        "idle_deployed_node_rate": float(
            np.mean(compute_load[deployed_nodes] <= active_threshold) if deployed_nodes.any() else 0.0
        ),
    }


def finite_weighted_mean(values: np.ndarray, weights: np.ndarray) -> float:
    """Average finite observations, falling back safely when all weights are zero."""

    finite = np.isfinite(values) & np.isfinite(weights)
    if not finite.any():
        return float("nan")
    finite_values = values[finite]
    finite_weights = weights[finite]
    weight_sum = float(finite_weights.sum())
    if weight_sum <= 0.0:
        return float(np.mean(finite_values))
    return float(np.average(finite_values, weights=finite_weights))


def aggregate_rollout_stats(rollouts: list[dict[str, float]]) -> dict[str, float]:
    if not rollouts:
        raise ValueError("cannot aggregate an empty rollout batch")
    if len(rollouts) == 1:
        return dict(rollouts[0])

    requests = np.asarray([r["requests"] for r in rollouts], dtype=np.float64)
    valid_requests = np.asarray([r["valid_requests"] for r in rollouts], dtype=np.float64)
    request_events = np.asarray([r["request_events"] for r in rollouts], dtype=np.float64)
    deployment_updates = np.asarray([r["deployment_updates"] for r in rollouts], dtype=np.float64)

    request_weighted = [
        "avg_reward",
        "avg_train_reward",
        "avg_train_latency_cost_s",
        "avg_fast_externality_cost_s",
        "avg_fast_counterfactual_regret_s",
        "avg_train_resource_penalty",
        "avg_diagnostic_resource_penalty",
        "avg_compute_hotspot_penalty",
        "avg_link_hotspot_penalty",
        "avg_compute_imbalance_penalty",
        "avg_link_imbalance_penalty",
        "avg_idle_deployed_node_penalty",
        "avg_latency_s",
        "p95_latency_s",
        "avg_compute_latency_s",
        "avg_link_latency_s",
        "avg_access_latency_s",
        "avg_propagation_latency_s",
        "avg_instantaneous_compute_work_gcycles",
        "avg_instantaneous_compute_pressure",
        "avg_max_instantaneous_compute_pressure",
        "avg_p95_instantaneous_compute_pressure",
        "avg_penalty_latency_s",
        "penalty_latency_share",
        "invalid_action_rate",
        "deadline_violation_rate",
        "first_window_avg_latency_s",
        "last_window_avg_latency_s",
        "window_latency_delta_s",
    ]
    valid_weighted = ["avg_valid_latency_s", "p95_valid_latency_s"]
    simple_mean = [
        "episode_fraction",
        "avg_fast_kkt_reward_residual_s",
        "demand_expected_compute_gcycles",
        "demand_expected_data_mb",
        "demand_expected_deadline_s",
        "demand_service_popularity_entropy",
        "avg_replicas_per_stage",
        "min_replicas_per_stage",
        "max_replicas_per_stage",
        "single_replica_stage_rate",
        "total_deployed_replicas",
        "avg_node_compute_load",
        "max_node_compute_load",
        "p95_node_compute_load",
        "std_node_compute_load",
        "active_node_rate",
        "hot_node_rate",
        "avg_link_load",
        "max_link_load",
        "p95_link_load",
        "std_link_load",
        "active_link_rate",
        "hot_link_rate",
        "avg_node_memory_util",
        "max_node_memory_util",
        "avg_node_storage_util",
        "max_node_storage_util",
        "avg_service_memory_util",
        "max_service_memory_util",
        "avg_service_storage_util",
        "max_service_storage_util",
        "deployed_node_rate",
        "idle_deployed_node_rate",
        "scheduled_stage_invocations",
        "used_replica_rate",
        "idle_replica_rate",
        "used_replicas_per_stage",
        "avg_replica_use_entropy",
        "avg_replica_use_top1_share",
        "cross_node_stage_transition_rate",
        "slow_window_return",
        "slow_window_latency_return",
        "slow_window_avg_latency",
        "slow_window_p95_latency",
        "slow_tail_latency_cost",
        "slow_colocation_credit_coef",
        "slow_colocation_cost",
        "slow_cross_stage_transition_rate",
        "slow_colocation_rate",
        "slow_data_weighted_cross_stage_rate",
        "slow_shared_return_credit",
        "slow_incremental_add_actions",
        "slow_incremental_stop_actions",
        "slow_budget_fraction",
        "slow_budget_feasible_capacity",
        "slow_budget_replica_slot_upper_bound",
        "slow_budget_extra_replicas",
        "slow_budget_allocated_replicas",
        "slow_budget_execution_ratio",
        "slow_budget_available_memory_gb",
        "slow_budget_available_storage_gb",
        "slow_budget_target_memory_gb",
        "slow_budget_target_storage_gb",
        "slow_budget_used_memory_gb",
        "slow_budget_used_storage_gb",
        "slow_budget_memory_fill_ratio",
        "slow_budget_storage_fill_ratio",
        "slow_replica_ablation_samples",
        "slow_replica_ablation_mean_s",
        "slow_stop_ablation_value_s",
        "slow_deployment_memory_cost",
        "slow_deployment_storage_cost",
        "slow_migration_cost",
        "slow_deadline_violation_cost",
        "slow_factorized_stage_return_mean",
        "slow_factorized_stage_return_std",
        "slow_factorized_count_return_mean",
        "slow_factorized_count_return_std",
        "slow_count_effective_replicas_per_stage",
        "slow_count_redundant_replica_fraction",
        "slow_count_unused_replica_fraction",
        "slow_count_unused_replica_cost",
        "slow_count_replica_imbalance_fraction",
        "slow_count_replica_efficiency_cost",
        "slow_placement_node_compute_load",
        "slow_placement_node_compute_cost",
        "slow_counterfactual_marginal_value",
        "slow_counterfactual_samples",
        "slow_stage_ablation_covered_stages",
        "slow_stage_ablation_credit_actions",
        "slow_stage_ablation_credit_fraction",
        "slow_deployment_memory_fraction",
        "slow_deployment_storage_fraction",
        "slow_migration_fraction",
        "avg_fast_oracle_latency_gap_s",
        "avg_fast_oracle_relative_gap",
        "fast_counterfactual_credit_coef",
    ]

    aggregated: dict[str, float] = {
        "requests": float(requests.sum()),
        "request_events": float(request_events.sum()),
        "sampled_request_events": float(sum(r.get("sampled_request_events", 0.) for r in rollouts)),
        "settlement_steps": float(sum(r["settlement_steps"] for r in rollouts)),
        "logical_steps": float(sum(r["logical_steps"] for r in rollouts)),
        "simulated_hours": float(sum(r["simulated_hours"] for r in rollouts)),
        "slow_planning_wall_s":float(sum(r.get("slow_planning_wall_s",0.) for r in rollouts)),
        "fast_scheduling_wall_s":float(sum(r.get("fast_scheduling_wall_s",0.) for r in rollouts)),
        "environment_settlement_wall_s":float(sum(r.get("environment_settlement_wall_s",0.) for r in rollouts)),
        "episode_complete": float(rollouts[-1]["episode_complete"]),
        "valid_requests": float(valid_requests.sum()),
        "invalid_actions": float(sum(r["invalid_actions"] for r in rollouts)),
        "deployment_updates": float(deployment_updates.sum()),
        "fast_oracle_samples": float(sum(r["fast_oracle_samples"] for r in rollouts)),
        "max_fast_kkt_reward_residual_s": float(
            np.nanmax(
                np.asarray(
                    [r["max_fast_kkt_reward_residual_s"] for r in rollouts],
                    dtype=np.float64,
                )
            )
        ),
    }
    aggregated["temporal_sampling_fraction"] = float(
        aggregated["settlement_steps"] / max(aggregated["logical_steps"], 1.0)
    )
    for key in request_weighted:
        values = np.asarray([r[key] for r in rollouts], dtype=np.float64)
        aggregated[key] = finite_weighted_mean(values, requests)
    for key in valid_weighted:
        values = np.asarray([r[key] for r in rollouts], dtype=np.float64)
        aggregated[key] = finite_weighted_mean(values, valid_requests)
    for key in simple_mean:
        values = np.asarray([r[key] for r in rollouts], dtype=np.float64)
        aggregated[key] = float(np.nanmean(values))
    return aggregated


def build_episode_metrics_row(
    rollouts: list[dict[str, float]],
    contexts: list[dict[str, float | int | str]],
) -> dict[str, float | int | str]:
    """Build one episode-level record from one or more collected rollout windows."""
    if not rollouts or len(rollouts) != len(contexts):
        raise ValueError("episode metrics require equally sized, non-empty rollout and context lists")
    stats = aggregate_rollout_stats(rollouts)
    first = contexts[0]
    last = contexts[-1]
    requests = float(stats["requests"])
    return {
        "episode": int(first["episode"]),
        "update_start": int(first["update"]),
        "update_end": int(last["update"]),
        "training_phase_start": str(first["training_phase"]),
        "training_phase_end": str(last["training_phase"]),
        "demand_seed": int(first["demand_seed"]),
        "demand_seed_end": int(last["demand_seed"]),
        "environment_seed": int(first["environment_seed"]),
        "environment_seed_end": int(last["environment_seed"]),
        "load_multiplier": float(first["load_multiplier"]),
        "load_multiplier_end": float(last["load_multiplier"]),
        "load_group": int(first["load_group"]),
        "load_group_end": int(last["load_group"]),
        "load_target_probability": float(first["load_target_probability"]),
        "load_target_probability_end": float(last["load_target_probability"]),
        "start_minute": float(first["start_minute"]),
        "start_minute_end": float(last["start_minute"]),
        "rollout_start": int(first["rollout"]),
        "rollout_end": int(last["rollout"]),
        "rollouts_collected": len(rollouts),
        "window_start": int(first["window"]),
        "window_end": int(last["window"]),
        "total_reward": float(stats["avg_reward"] * requests),
        "total_train_reward": float(stats["avg_train_reward"] * requests),
        **stats,
        "first_window_avg_latency_s": float(rollouts[0]["first_window_avg_latency_s"]),
        "last_window_avg_latency_s": float(rollouts[-1]["last_window_avg_latency_s"]),
        "window_latency_delta_s": float(rollouts[-1]["last_window_avg_latency_s"])
        - float(rollouts[0]["first_window_avg_latency_s"]),
    }


def build_rollout_metrics_row(
    stats: dict[str, float],
    context: dict[str, float | int | str],
    rollout_in_update: int,
) -> dict[str, float | int | str]:
    """Build one plot-ready record for every independently collected window."""

    requests = float(stats["requests"])
    return {
        "rollout": int(context["rollout"]),
        "update": int(context["update"]),
        "rollout_in_update": int(rollout_in_update),
        "episode": int(context["episode"]),
        "window": int(context["window"]),
        "training_phase": str(context["training_phase"]),
        "demand_seed": int(context["demand_seed"]),
        "environment_seed": int(context["environment_seed"]),
        "load_multiplier": float(context["load_multiplier"]),
        "load_group": int(context["load_group"]),
        "load_target_probability": float(context["load_target_probability"]),
        "start_minute": float(context["start_minute"]),
        "total_reward": float(stats["avg_reward"] * requests),
        "total_train_reward": float(stats["avg_train_reward"] * requests),
        **stats,
    }


def _resource_reward_components(
    env: EdgeComputingEnv,
    args: argparse.Namespace,
) -> dict[str, float]:
    compute_load = np.asarray(env.node_compute_load, dtype=np.float64)
    max_compute = float(np.max(compute_load)) if compute_load.size else 0.0
    compute_hotspot_excess = max(0.0, max_compute - float(args.compute_hotspot_threshold))

    finite_links = np.isfinite(env.scenario.bandwidth_mb_s) & env.scenario.adjacency if env.scenario is not None else None
    if finite_links is not None:
        np.fill_diagonal(finite_links, False)
        link_load = np.asarray(env.link_load[finite_links], dtype=np.float64)
        link_load = link_load[np.isfinite(link_load)]
    else:
        link_load = np.asarray([], dtype=np.float64)
    max_link = float(np.max(link_load)) if link_load.size else 0.0
    link_hotspot_excess = max(0.0, max_link - float(args.link_hotspot_threshold))

    deployed_idle_rate = 0.0
    if env.deployment is not None and env.scenario is not None:
        memory_used = np.zeros(env.config.num_edge_nodes, dtype=np.float64)
        storage_used = np.zeros(env.config.num_edge_nodes, dtype=np.float64)
        for service in env.scenario.services:
            for stage in service.stages:
                placed = env.deployment[service.service_id, stage.stage_id]
                memory_used += placed * stage.memory_gb
                storage_used += placed * stage.storage_gb
        deployed_nodes = np.logical_or(memory_used > 0.0, storage_used > 0.0)
        if deployed_nodes.any():
            deployed_idle_rate = float(
                np.mean(compute_load[deployed_nodes] <= float(args.resource_active_load_threshold))
            )

    compute_imbalance = float(np.std(compute_load)) if compute_load.size else 0.0
    link_imbalance = float(np.std(link_load)) if link_load.size else 0.0
    return {
        "compute_hotspot_penalty": float(args.compute_hotspot_coef) * compute_hotspot_excess,
        "link_hotspot_penalty": float(args.link_hotspot_coef) * link_hotspot_excess,
        "compute_imbalance_penalty": float(args.compute_imbalance_coef) * compute_imbalance,
        "link_imbalance_penalty": float(args.link_imbalance_coef) * link_imbalance,
        "idle_deployed_node_penalty": float(args.idle_deployed_node_coef) * deployed_idle_rate,
        "compute_hotspot_excess": compute_hotspot_excess,
        "link_hotspot_excess": link_hotspot_excess,
    }


def _training_reward_components(
    policy_info: dict[str, object],
    env: EdgeComputingEnv,
    args: argparse.Namespace,
) -> dict[str, float]:
    latency_cost = float(policy_info["latency_s"])
    components = _resource_reward_components(env, args)
    resource_penalty = (
        components["compute_hotspot_penalty"]
        + components["link_hotspot_penalty"]
        + components["compute_imbalance_penalty"]
        + components["link_imbalance_penalty"]
        + components["idle_deployed_node_penalty"]
    )
    reward = -latency_cost
    return {
        "train_reward": reward,
        "train_latency_cost_s": latency_cost,
        "train_resource_penalty": 0.0,
        "diagnostic_resource_penalty": resource_penalty,
        **components,
    }


def _stage_latency_costs(
    policy_info: dict[str, object],
    env: EdgeComputingEnv,
    request,
    *,
    include_access: bool = True,
) -> list[float]:
    """Decompose one request's end-to-end latency into additive stage costs.

    Each stage owns its compute delay and the communication needed to reach
    that stage. Radio access can be excluded because it is invariant to every
    scheduling and placement action. Any invalid-action penalty belongs to the
    terminal stage.
    """

    assert env.scenario is not None
    stage_nodes = [int(node_id) for node_id in policy_info["stage_nodes"]]
    compute_delays = policy_info["compute_delays"]
    link_delays = policy_info["link_delays"]
    propagation_delays = policy_info.get("logical_propagation_delays", {})
    costs: list[float] = []
    for stage_id, node_id in enumerate(stage_nodes):
        cost = float(compute_delays.get(f"stage-{stage_id}", 0.0))
        if stage_id == 0:
            if include_access:
                cost += float(policy_info["access_delay_s"])
            previous_node = int(request.home_node)
            link_key = "ingress"
        else:
            previous_node = stage_nodes[stage_id - 1]
            link_key = f"stage-{stage_id - 1}"
        if previous_node != node_id:
            cost += float(link_delays.get(link_key, 0.0))
            cost += float(propagation_delays.get(link_key, 0.0))
        costs.append(cost)

    if not costs:
        return []
    costs[-1] += float(policy_info["penalty_latency_s"])
    # Keep the decomposition robust to future latency components and floating
    # point drift by assigning any residual to the terminal transition.
    target_latency = float(policy_info["latency_s"])
    if not include_access:
        target_latency -= float(policy_info["access_delay_s"])
    costs[-1] += target_latency - float(sum(costs))
    return costs


def _stage_congestion_externality_costs(
    policy_info: dict[str, object],
    env: EdgeComputingEnv,
    request,
) -> list[float]:
    """Assign exact KKT difference-reward externalities to Fast stages.

    A stage owns the compute congestion it creates at its selected node and the
    wired-link congestion created while reaching that stage.  These terms are
    zero for isolated resources and positive only when another request shares
    the same constrained resource.
    """

    del env
    stage_nodes = [int(node_id) for node_id in policy_info["stage_nodes"]]
    compute_externalities = policy_info.get("compute_externality_delays", {})
    link_externalities = policy_info.get("link_externality_delays", {})
    costs: list[float] = []
    for stage_id, node_id in enumerate(stage_nodes):
        cost = float(compute_externalities.get(f"stage-{stage_id}", 0.0))
        previous_node = int(request.home_node) if stage_id == 0 else stage_nodes[stage_id - 1]
        link_key = "ingress" if stage_id == 0 else f"stage-{stage_id - 1}"
        if previous_node != node_id:
            cost += float(link_externalities.get(link_key, 0.0))
        costs.append(cost)
    return costs


def evaluate_agent(
    args: argparse.Namespace,
    agent: HierarchicalPPOAgent,
    *,
    seed_base: int,
    max_requests: int,
    train_mode: str,
    rollout_unit: str = "requests",
) -> dict[str, float]:
    runs = []
    for seed_idx in range(args.eval_seeds):
        eval_env = build_env(args, seed_offset=seed_base + seed_idx)
        reset_env = True
        if rollout_unit == "window":
            eval_env.reset()
            start_env_at_minute(eval_env, rollout_start_minute(args, seed_idx, eval_mode=True))
            reset_env = False
        runs.append(
            rollout(
                eval_env,
                agent,
                max_requests,
                args=args,
                deterministic=True,
                record=False,
                train_mode=train_mode,
                progress_label=f"eval seed={seed_idx + 1:02d}/{args.eval_seeds:02d}",
                progress_interval_seconds=getattr(args, "progress_interval_seconds", 0.0),
                rollout_unit=rollout_unit,
                reset_env=reset_env,
            )
        )
    avg_latencies = np.array([r["avg_latency_s"] for r in runs], dtype=np.float64)
    p95_latencies = np.array([r["p95_latency_s"] for r in runs], dtype=np.float64)
    avg_compute_latencies = np.array([r["avg_compute_latency_s"] for r in runs], dtype=np.float64)
    avg_link_latencies = np.array([r["avg_link_latency_s"] for r in runs], dtype=np.float64)
    avg_access_latencies = np.array([r["avg_access_latency_s"] for r in runs], dtype=np.float64)
    avg_propagation_latencies = np.array([r["avg_propagation_latency_s"] for r in runs], dtype=np.float64)
    avg_instantaneous_compute_work = np.array(
        [r["avg_instantaneous_compute_work_gcycles"] for r in runs], dtype=np.float64
    )
    avg_instantaneous_compute_pressure = np.array(
        [r["avg_instantaneous_compute_pressure"] for r in runs], dtype=np.float64
    )
    avg_max_instantaneous_compute_pressure = np.array(
        [r["avg_max_instantaneous_compute_pressure"] for r in runs], dtype=np.float64
    )
    avg_p95_instantaneous_compute_pressure = np.array(
        [r["avg_p95_instantaneous_compute_pressure"] for r in runs], dtype=np.float64
    )
    avg_valid_latencies = np.array([r["avg_valid_latency_s"] for r in runs], dtype=np.float64)
    p95_valid_latencies = np.array([r["p95_valid_latency_s"] for r in runs], dtype=np.float64)
    avg_penalty_latencies = np.array([r["avg_penalty_latency_s"] for r in runs], dtype=np.float64)
    penalty_latency_shares = np.array([r["penalty_latency_share"] for r in runs], dtype=np.float64)
    invalid_actions = np.array([r["invalid_actions"] for r in runs], dtype=np.float64)
    invalid_action_rates = np.array([r["invalid_action_rate"] for r in runs], dtype=np.float64)
    violation_rates = np.array([r["deadline_violation_rate"] for r in runs], dtype=np.float64)
    deployment_updates = np.array([r["deployment_updates"] for r in runs], dtype=np.float64)
    request_events = np.array([r["request_events"] for r in runs], dtype=np.float64)
    settlement_steps = np.array([r["settlement_steps"] for r in runs], dtype=np.float64)
    logical_steps = np.array([r["logical_steps"] for r in runs], dtype=np.float64)
    avg_replicas = np.array([r["avg_replicas_per_stage"] for r in runs], dtype=np.float64)
    single_replica_rates = np.array([r["single_replica_stage_rate"] for r in runs], dtype=np.float64)
    total_replicas = np.array([r["total_deployed_replicas"] for r in runs], dtype=np.float64)
    first_window_latencies = np.array([r["first_window_avg_latency_s"] for r in runs], dtype=np.float64)
    last_window_latencies = np.array([r["last_window_avg_latency_s"] for r in runs], dtype=np.float64)
    avg_node_compute_load = np.array([r["avg_node_compute_load"] for r in runs], dtype=np.float64)
    max_node_compute_load = np.array([r["max_node_compute_load"] for r in runs], dtype=np.float64)
    p95_node_compute_load = np.array([r["p95_node_compute_load"] for r in runs], dtype=np.float64)
    std_node_compute_load = np.array([r["std_node_compute_load"] for r in runs], dtype=np.float64)
    active_node_rate = np.array([r["active_node_rate"] for r in runs], dtype=np.float64)
    hot_node_rate = np.array([r["hot_node_rate"] for r in runs], dtype=np.float64)
    avg_link_load = np.array([r["avg_link_load"] for r in runs], dtype=np.float64)
    max_link_load = np.array([r["max_link_load"] for r in runs], dtype=np.float64)
    p95_link_load = np.array([r["p95_link_load"] for r in runs], dtype=np.float64)
    std_link_load = np.array([r["std_link_load"] for r in runs], dtype=np.float64)
    active_link_rate = np.array([r["active_link_rate"] for r in runs], dtype=np.float64)
    hot_link_rate = np.array([r["hot_link_rate"] for r in runs], dtype=np.float64)
    avg_node_memory_util = np.array([r["avg_node_memory_util"] for r in runs], dtype=np.float64)
    max_node_memory_util = np.array([r["max_node_memory_util"] for r in runs], dtype=np.float64)
    avg_node_storage_util = np.array([r["avg_node_storage_util"] for r in runs], dtype=np.float64)
    max_node_storage_util = np.array([r["max_node_storage_util"] for r in runs], dtype=np.float64)
    deployed_node_rate = np.array([r["deployed_node_rate"] for r in runs], dtype=np.float64)
    idle_deployed_node_rate = np.array([r["idle_deployed_node_rate"] for r in runs], dtype=np.float64)
    scheduled_stage_invocations = np.array([r["scheduled_stage_invocations"] for r in runs], dtype=np.float64)
    used_replica_rate = np.array([r["used_replica_rate"] for r in runs], dtype=np.float64)
    idle_replica_rate = np.array([r["idle_replica_rate"] for r in runs], dtype=np.float64)
    used_replicas_per_stage = np.array([r["used_replicas_per_stage"] for r in runs], dtype=np.float64)
    avg_replica_use_entropy = np.array([r["avg_replica_use_entropy"] for r in runs], dtype=np.float64)
    avg_replica_use_top1_share = np.array([r["avg_replica_use_top1_share"] for r in runs], dtype=np.float64)
    cross_node_stage_transition_rate = np.array([r["cross_node_stage_transition_rate"] for r in runs], dtype=np.float64)
    return {
        "eval_avg_latency_s": float(avg_latencies.mean()),
        "eval_avg_latency_std": float(avg_latencies.std()),
        "eval_p95_latency_s": float(p95_latencies.mean()),
        "eval_avg_compute_latency_s": float(avg_compute_latencies.mean()),
        "eval_avg_link_latency_s": float(avg_link_latencies.mean()),
        "eval_avg_access_latency_s": float(avg_access_latencies.mean()),
        "eval_avg_propagation_latency_s": float(avg_propagation_latencies.mean()),
        "eval_avg_instantaneous_compute_work_gcycles": float(avg_instantaneous_compute_work.mean()),
        "eval_avg_instantaneous_compute_pressure": float(avg_instantaneous_compute_pressure.mean()),
        "eval_avg_max_instantaneous_compute_pressure": float(avg_max_instantaneous_compute_pressure.mean()),
        "eval_avg_p95_instantaneous_compute_pressure": float(avg_p95_instantaneous_compute_pressure.mean()),
        "eval_avg_valid_latency_s": float(avg_valid_latencies.mean()),
        "eval_p95_valid_latency_s": float(p95_valid_latencies.mean()),
        "eval_avg_penalty_latency_s": float(avg_penalty_latencies.mean()),
        "eval_penalty_latency_share": float(penalty_latency_shares.mean()),
        "eval_invalid_actions": float(invalid_actions.mean()),
        "eval_invalid_action_rate": float(invalid_action_rates.mean()),
        "eval_deadline_violation_rate": float(violation_rates.mean()),
        "eval_deployment_updates": float(deployment_updates.mean()),
        "eval_request_events": float(request_events.mean()),
        "eval_settlement_steps": float(settlement_steps.mean()),
        "eval_logical_steps": float(logical_steps.mean()),
        "eval_temporal_sampling_fraction": float(settlement_steps.sum() / max(logical_steps.sum(), 1.0)),
        "eval_avg_replicas_per_stage": float(avg_replicas.mean()),
        "eval_single_replica_stage_rate": float(single_replica_rates.mean()),
        "eval_total_deployed_replicas": float(total_replicas.mean()),
        "eval_first_window_avg_latency_s": float(np.nanmean(first_window_latencies)),
        "eval_last_window_avg_latency_s": float(np.nanmean(last_window_latencies)),
        "eval_window_latency_delta_s": float(np.nanmean(last_window_latencies - first_window_latencies)),
        "eval_avg_node_compute_load": float(np.nanmean(avg_node_compute_load)),
        "eval_max_node_compute_load": float(np.nanmean(max_node_compute_load)),
        "eval_p95_node_compute_load": float(np.nanmean(p95_node_compute_load)),
        "eval_std_node_compute_load": float(np.nanmean(std_node_compute_load)),
        "eval_active_node_rate": float(np.nanmean(active_node_rate)),
        "eval_hot_node_rate": float(np.nanmean(hot_node_rate)),
        "eval_avg_link_load": float(np.nanmean(avg_link_load)),
        "eval_max_link_load": float(np.nanmean(max_link_load)),
        "eval_p95_link_load": float(np.nanmean(p95_link_load)),
        "eval_std_link_load": float(np.nanmean(std_link_load)),
        "eval_active_link_rate": float(np.nanmean(active_link_rate)),
        "eval_hot_link_rate": float(np.nanmean(hot_link_rate)),
        "eval_avg_node_memory_util": float(np.nanmean(avg_node_memory_util)),
        "eval_max_node_memory_util": float(np.nanmean(max_node_memory_util)),
        "eval_avg_node_storage_util": float(np.nanmean(avg_node_storage_util)),
        "eval_max_node_storage_util": float(np.nanmean(max_node_storage_util)),
        "eval_deployed_node_rate": float(np.nanmean(deployed_node_rate)),
        "eval_idle_deployed_node_rate": float(np.nanmean(idle_deployed_node_rate)),
        "eval_scheduled_stage_invocations": float(np.nanmean(scheduled_stage_invocations)),
        "eval_used_replica_rate": float(np.nanmean(used_replica_rate)),
        "eval_idle_replica_rate": float(np.nanmean(idle_replica_rate)),
        "eval_used_replicas_per_stage": float(np.nanmean(used_replicas_per_stage)),
        "eval_avg_replica_use_entropy": float(np.nanmean(avg_replica_use_entropy)),
        "eval_avg_replica_use_top1_share": float(np.nanmean(avg_replica_use_top1_share)),
        "eval_cross_node_stage_transition_rate": float(np.nanmean(cross_node_stage_transition_rate)),
    }


EVAL_STAT_KEYS = [
    "eval_avg_latency_s",
    "eval_avg_latency_std",
    "eval_p95_latency_s",
    "eval_avg_compute_latency_s",
    "eval_avg_link_latency_s",
    "eval_avg_access_latency_s",
    "eval_avg_propagation_latency_s",
    "eval_avg_instantaneous_compute_work_gcycles",
    "eval_avg_instantaneous_compute_pressure",
    "eval_avg_max_instantaneous_compute_pressure",
    "eval_avg_p95_instantaneous_compute_pressure",
    "eval_avg_valid_latency_s",
    "eval_p95_valid_latency_s",
    "eval_avg_penalty_latency_s",
    "eval_penalty_latency_share",
    "eval_invalid_actions",
    "eval_invalid_action_rate",
    "eval_deadline_violation_rate",
    "eval_deployment_updates",
    "eval_request_events",
    "eval_settlement_steps",
    "eval_logical_steps",
    "eval_temporal_sampling_fraction",
    "eval_avg_replicas_per_stage",
    "eval_single_replica_stage_rate",
    "eval_total_deployed_replicas",
    "eval_first_window_avg_latency_s",
    "eval_last_window_avg_latency_s",
    "eval_window_latency_delta_s",
    "eval_avg_node_compute_load",
    "eval_max_node_compute_load",
    "eval_p95_node_compute_load",
    "eval_std_node_compute_load",
    "eval_active_node_rate",
    "eval_hot_node_rate",
    "eval_avg_link_load",
    "eval_max_link_load",
    "eval_p95_link_load",
    "eval_std_link_load",
    "eval_active_link_rate",
    "eval_hot_link_rate",
    "eval_avg_node_memory_util",
    "eval_max_node_memory_util",
    "eval_avg_node_storage_util",
    "eval_max_node_storage_util",
    "eval_deployed_node_rate",
    "eval_idle_deployed_node_rate",
    "eval_scheduled_stage_invocations",
    "eval_used_replica_rate",
    "eval_idle_replica_rate",
    "eval_used_replicas_per_stage",
    "eval_avg_replica_use_entropy",
    "eval_avg_replica_use_top1_share",
    "eval_cross_node_stage_transition_rate",
]


def prefix_eval_stats(stats: dict[str, float], prefix: str) -> dict[str, float]:
    return {
        f"{prefix}{key.removeprefix('eval_')}": value
        for key, value in ((key, stats.get(key, float("nan"))) for key in EVAL_STAT_KEYS)
    }


def rollout_baseline(env: EdgeComputingEnv, max_requests: int) -> dict[str, float]:
    agent = build_baseline_agent()
    env.reset()
    rewards: list[float] = []
    latencies: list[float] = []
    invalid = 0
    while not env.done and env.metrics["requests"] < max_requests:
        requests = list(env.current_requests)
        actions = agent.act_batch(env)
        _, _, _, batch_info = env.step(actions)
        for request, info in zip(requests, batch_info["group_infos"]):
            rewards.extend([float(info["reward"])] * int(request.request_count))
            latencies.extend([float(info["latency_s"])] * int(request.request_count))
            invalid += int(not info["valid"]) * int(request.request_count)
    return {
        "requests": float(env.metrics["requests"]),
        "avg_reward": float(np.mean(rewards)) if rewards else 0.0,
        "avg_latency_s": float(np.mean(latencies)) if latencies else 0.0,
        "p95_latency_s": float(np.percentile(latencies, 95)) if latencies else 0.0,
        "invalid_actions": float(invalid),
        "deadline_violation_rate": float(env.metrics["deadline_violations"] / max(env.metrics["requests"], 1.0)),
    }


def pretrain_fast_agent(
    args: argparse.Namespace,
    agent: HierarchicalPPOAgent,
    *,
    requests: int,
    epochs: int,
) -> dict[str, float]:
    if requests <= 0:
        return {"bc_loss": 0.0, "bc_accuracy": 0.0, "bc_samples": 0.0}

    slow_policy = SlowGreedyDeploymentPolicy()
    expert = FastGreedyScheduler()
    states = []
    masks = []
    actions = []
    collected_requests = 0
    episode_idx = 0
    while collected_requests < requests:
        env = build_env(args, seed_offset=40_000 + episode_idx, group_scenario_by_refresh=True)
        env.reset()
        episode_idx += 1
        while not env.done and collected_requests < requests:
            if env.needs_deployment_update:
                env.apply_deployment(slow_policy.act(env))
            tick_requests = list(env.current_requests)
            expert_batch: list[list[int]] = []
            for request in tick_requests:
                expert_nodes = expert.act(env, request)
                expert_batch.append(expert_nodes)
                partial_nodes: list[int] = []
                for stage_id, node_id in enumerate(expert_nodes):
                    state = agent.fast_agent._build_state(env, request, stage_id, partial_nodes)
                    mask = agent.fast_agent._build_mask(env, request, stage_id, partial_nodes)
                    if mask[node_id]:
                        states.append(state)
                        masks.append(mask)
                        actions.append(node_id)
                    partial_nodes.append(node_id)
            env.step(expert_batch)
            collected_requests += int(sum(request.request_count for request in tick_requests))

    if not actions:
        return {"bc_loss": 0.0, "bc_accuracy": 0.0, "bc_samples": 0.0}
    metrics = agent.fast_agent.ppo.behavior_clone(
        np.stack(states),
        np.stack(masks),
        np.asarray(actions, dtype=np.int64),
        epochs=epochs,
    )
    metrics["bc_samples"] = float(len(actions))
    return metrics


def _serialize_rollout_buffer(
    buffer: object,
    *,
    continuous_actions: bool = False,
) -> dict[str, object]:
    """Store an on-policy buffer without binding checkpoints to CUDA tensors."""

    states = getattr(buffer, "states")
    masks = getattr(buffer, "masks")
    return {
        "states": torch.as_tensor(np.stack(states), dtype=torch.float32)
        if states
        else torch.empty((0,), dtype=torch.float32),
        "masks": torch.as_tensor(np.stack(masks), dtype=torch.bool)
        if masks
        else torch.empty((0,), dtype=torch.bool),
        "actions": torch.as_tensor(
            getattr(buffer, "actions"),
            dtype=torch.float32 if continuous_actions else torch.int64,
        ),
        "logprobs": torch.as_tensor(getattr(buffer, "logprobs"), dtype=torch.float32),
        "rewards": torch.as_tensor(getattr(buffer, "rewards"), dtype=torch.float32),
        "dones": torch.as_tensor(getattr(buffer, "dones"), dtype=torch.bool),
        "values": torch.as_tensor(getattr(buffer, "values"), dtype=torch.float32),
        "weights": torch.as_tensor(getattr(buffer, "weights"), dtype=torch.float32),
        "sample_groups": torch.as_tensor(getattr(buffer, "sample_groups"), dtype=torch.float32),
    }


def _restore_rollout_buffer(
    buffer: object,
    state: object,
    *,
    continuous_actions: bool = False,
) -> None:
    if not isinstance(state, dict):
        return
    buffer.clear()
    states = state.get("states")
    masks = state.get("masks")
    if torch.is_tensor(states) and states.numel() > 0:
        buffer.states.extend(item.numpy().copy() for item in states.cpu())
    if torch.is_tensor(masks) and masks.numel() > 0:
        buffer.masks.extend(item.numpy().astype(bool, copy=True) for item in masks.cpu())
    tensor_fields = {
        "actions": float if continuous_actions else int,
        "logprobs": float,
        "rewards": float,
        "dones": bool,
        "values": float,
        "weights": float,
        "sample_groups": float,
    }
    for field, converter in tensor_fields.items():
        values = state.get(field)
        if torch.is_tensor(values):
            getattr(buffer, field).extend(converter(value) for value in values.cpu().tolist())


def _serialize_pending_slow_collection(agent: HierarchicalPPOAgent) -> dict[str, object]:
    slow = agent.slow_agent
    if slow.pending_window_id is not None:
        raise RuntimeError("checkpoints may only be saved after the current Slow window receives feedback")
    return {
        "count_buffer": _serialize_rollout_buffer(
            slow.count_ppo.buffer,
            continuous_actions=slow.count_ppo.continuous_actions,
        ),
        "stage_buffer": (
            _serialize_rollout_buffer(slow.stage_ppo.buffer)
            if slow.stage_ppo is not None
            else None
        ),
        "placement_buffer": _serialize_rollout_buffer(slow.placement_ppo.buffer),
        "count_action_returns": list(slow.count_action_returns),
        "stage_action_returns": list(slow.stage_action_returns),
        "placement_action_returns": list(slow.placement_action_returns),
        "count_action_stage_keys": [list(key) for key in slow.count_action_stage_keys],
        "stage_action_stage_keys": [list(key) for key in slow.stage_action_stage_keys],
        "placement_action_stage_keys": [list(key) for key in slow.placement_action_stage_keys],
        "count_window_ids": list(slow.count_window_ids),
        "stage_window_ids": list(slow.stage_window_ids),
        "placement_window_ids": list(slow.placement_window_ids),
        "window_states": torch.as_tensor(np.stack(slow.window_states), dtype=torch.float32)
        if slow.window_states
        else torch.empty((0,), dtype=torch.float32),
        "window_old_values": list(slow.window_old_values),
        "window_returns": list(slow.window_returns),
        "window_dones": list(slow.window_dones),
        "window_episode_ids": list(slow.window_episode_ids),
        "last_route_history":slow.last_route_history,
    }


def _restore_pending_slow_collection(agent: HierarchicalPPOAgent, state: object) -> None:
    if not isinstance(state, dict):
        return
    slow = agent.slow_agent
    slow.last_route_history = state.get("last_route_history", {})
    _restore_rollout_buffer(
        slow.count_ppo.buffer,
        state.get("count_buffer"),
        continuous_actions=slow.count_ppo.continuous_actions,
    )
    if slow.stage_ppo is not None:
        _restore_rollout_buffer(slow.stage_ppo.buffer, state.get("stage_buffer"))
    _restore_rollout_buffer(slow.placement_ppo.buffer, state.get("placement_buffer"))
    slow.count_action_returns = [float(value) for value in state.get("count_action_returns", [])]
    slow.stage_action_returns = [float(value) for value in state.get("stage_action_returns", [])]
    slow.placement_action_returns = [float(value) for value in state.get("placement_action_returns", [])]
    slow.count_action_stage_keys = [tuple(map(int, key)) for key in state.get("count_action_stage_keys", [])]
    slow.stage_action_stage_keys = [
        tuple(map(int, key)) for key in state.get("stage_action_stage_keys", [])
    ]
    slow.placement_action_stage_keys = [
        tuple(map(int, key)) for key in state.get("placement_action_stage_keys", [])
    ]
    slow.count_window_ids = [int(value) for value in state.get("count_window_ids", [])]
    slow.stage_window_ids = [int(value) for value in state.get("stage_window_ids", [])]
    slow.placement_window_ids = [int(value) for value in state.get("placement_window_ids", [])]
    window_states = state.get("window_states")
    slow.window_states = (
        [item.numpy().copy() for item in window_states.cpu()]
        if torch.is_tensor(window_states) and window_states.numel() > 0
        else []
    )
    slow.window_old_values = [float(value) for value in state.get("window_old_values", [])]
    slow.window_returns = [float(value) for value in state.get("window_returns", [])]
    slow.window_dones = [bool(value) for value in state.get("window_dones", [])]
    slow.window_episode_ids = [int(value) for value in state.get("window_episode_ids", [])]
    slow.pending_window_id = None
    slow.pending_count_indices.clear()
    slow.pending_stage_indices.clear()
    slow.pending_placement_indices.clear()
    slow.pending_count_stage_keys.clear()
    slow.pending_count_node_ids.clear()
    slow.pending_stage_keys.clear()
    slow.pending_stage_node_ids.clear()
    slow.pending_placement_stage_keys.clear()
    slow.pending_budget_fraction = 0.0
    slow.pending_budget_feasible_capacity = 0
    slow.pending_budget_replica_slot_upper_bound = 0
    slow.pending_budget_requested_replicas = 0
    slow.pending_budget_available_memory_gb = 0.0
    slow.pending_budget_available_storage_gb = 0.0
    slow.pending_budget_target_memory_gb = 0.0
    slow.pending_budget_target_storage_gb = 0.0
    slow.pending_budget_used_memory_gb = 0.0
    slow.pending_budget_used_storage_gb = 0.0


def save_checkpoint(
    agent: HierarchicalPPOAgent,
    path: Path,
    metadata: dict[str, object],
    random_streams: TrainingRandomStreams | None = None,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    numpy_state = np.random.get_state()
    safe_numpy_state = {
        "bit_generator": str(numpy_state[0]),
        "keys": [int(value) for value in numpy_state[1]],
        "position": int(numpy_state[2]),
        "has_gauss": int(numpy_state[3]),
        "cached_gaussian": float(numpy_state[4]),
    }
    checkpoint = {
            "training_repair": "batch-credit-v1" if agent.fast_agent.batch_credit else "legacy",
            "fast_independent_critic": agent.fast_agent.independent_critic,
            "fast_update_chunks": agent.fast_agent.update_chunks,
            # The global incremental Count head has a different action space
            # and network topology from the legacy per-stage Count head.  Save
            # the architecture tag so resume failures are explicit instead of
            # surfacing later as opaque tensor-size mismatches.
            "slow_allocation_mode": agent.slow_agent.allocation_mode,
            "slow_quota_decode": agent.slow_agent.quota_decode,
            "slow_deployment_context": agent.slow_agent.deployment_context,
            "slow_learning_repair": agent.slow_agent.learning_repair,
            "slow_conditional_learning_state": {
                name: None if ppo is None or ppo.slow_conditional_learning is None else ppo.slow_conditional_learning.state_dict()
                for name, ppo in (("count", agent.slow_agent.count_ppo), ("stage", agent.slow_agent.stage_ppo),
                                  ("placement", agent.slow_agent.placement_ppo))
            },
            "slow_count_agent": agent.slow_agent.count_ppo.policy.state_dict(),
            "slow_count_optimizer": agent.slow_agent.count_ppo.optimizer.state_dict(),
            "slow_stage_agent": (
                agent.slow_agent.stage_ppo.policy.state_dict()
                if agent.slow_agent.stage_ppo is not None
                else None
            ),
            "slow_stage_optimizer": (
                agent.slow_agent.stage_ppo.optimizer.state_dict()
                if agent.slow_agent.stage_ppo is not None
                else None
            ),
            "slow_placement_agent": agent.slow_agent.placement_ppo.policy.state_dict(),
            "slow_placement_optimizer": agent.slow_agent.placement_ppo.optimizer.state_dict(),
            "slow_placement_updates_completed": agent.slow_agent.placement_updates_completed,
            "slow_placement_entropy_current_coef": agent.slow_agent.placement_entropy_current_coef,
            "slow_window_critic": agent.slow_agent.window_critic.state_dict(),
            "slow_window_critic_optimizer": agent.slow_agent.critic_optimizer.state_dict(),
            "slow_window_critic_return_mean": agent.slow_agent.critic_return_mean,
            "slow_window_critic_return_std": agent.slow_agent.critic_return_std,
            "slow_window_critic_update_index": agent.slow_agent.critic_update_index,
            "slow_window_critic_last_holdout_ev": agent.slow_agent.last_window_critic_holdout_ev,
            "slow_window_critic_replay_states": (
                torch.as_tensor(
                    np.stack(agent.slow_agent.critic_replay_states),
                    dtype=torch.float32,
                )
                if agent.slow_agent.critic_replay_states
                else torch.empty((0,), dtype=torch.float32)
            ),
            "slow_window_critic_replay_returns": torch.as_tensor(
                agent.slow_agent.critic_replay_returns,
                dtype=torch.float32,
            ),
            "slow_window_critic_replay_update_ids": torch.as_tensor(
                agent.slow_agent.critic_replay_update_ids,
                dtype=torch.int64,
            ),
            "slow_window_critic_replay_episode_ids": torch.as_tensor(
                agent.slow_agent.critic_replay_episode_ids,
                dtype=torch.int64,
            ),
            "slow_window_critic_episode_index": agent.slow_agent.critic_episode_index,
            "pending_slow_collection": _serialize_pending_slow_collection(agent),
            "fast_agent": agent.fast_agent.ppo.policy.state_dict(),
            "fast_optimizer": agent.fast_agent.ppo.optimizer.state_dict(),
            "fast_value_normalization": agent.fast_agent.ppo.value_normalization_state(),
            "slow_component_value_normalization": {
                "count": agent.slow_agent.count_ppo.value_normalization_state(),
                "stage": None if agent.slow_agent.stage_ppo is None else agent.slow_agent.stage_ppo.value_normalization_state(),
                "placement": agent.slow_agent.placement_ppo.value_normalization_state(),
            },
            "fast_entropy_current_coef": agent.fast_agent.entropy_current_coef,
            "training_random_streams": None if random_streams is None else random_streams.state_dict(),
            "numpy_random_state": safe_numpy_state,
            "torch_random_state": torch.get_rng_state(),
            "torch_cuda_random_state": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
            "metadata": metadata,
        }
    temporary_path = path.with_suffix(path.suffix + ".tmp")
    torch.save(checkpoint, temporary_path)
    temporary_path.replace(path)


def load_checkpoint(
    agent: HierarchicalPPOAgent,
    path: Path,
    random_streams: TrainingRandomStreams | None = None,
    *, restore_rng: bool = True,
) -> dict[str, object]:
    # Keep serialized RNG states on the CPU.  Mapping the whole checkpoint to
    # CUDA also moves ``torch_random_state`` to CUDA, but the default PyTorch
    # generator only accepts a CPU ByteTensor.  Model/optimizer state loaders
    # copy their tensors to the parameter device themselves.
    checkpoint = torch.load(path, map_location="cpu")
    if checkpoint.get("slow_quota_decode", "mean") != agent.slow_agent.quota_decode:
        raise ValueError("checkpoint Slow quota decoder differs; restore its saved decoder for full resume")
    if bool(checkpoint.get("fast_independent_critic", False)) != agent.fast_agent.independent_critic:
        raise ValueError("checkpoint Fast critic architecture differs; restore saved settings or start a fresh run")
    if checkpoint.get("slow_deployment_context", "legacy") != agent.slow_agent.deployment_context:
        raise ValueError("checkpoint Slow deployment context differs; resume the saved architecture or start a fresh Slow with --init-fast-checkpoint")
    requested_repair = "batch-credit-v1" if agent.fast_agent.batch_credit else "legacy"
    if str(checkpoint.get("training_repair", "legacy")) != requested_repair:
        raise ValueError("checkpoint training repair version differs; use --training-repair auto to resume or start a fresh run")
    if agent.fast_agent.batch_credit and "fast_value_normalization" not in checkpoint:
        raise ValueError("repaired checkpoint is missing Fast value normalization state")
    if agent.slow_agent.team_window_credit and "slow_component_value_normalization" not in checkpoint:
        raise ValueError("repaired checkpoint is missing Slow conditional value normalization")
    saved_allocation_mode = checkpoint.get("slow_allocation_mode")
    if saved_allocation_mode is None and "slow_count_agent" in checkpoint:
        count_state = checkpoint["slow_count_agent"]
        if isinstance(count_state, dict):
            saved_allocation_mode = (
                "global-incremental"
                if any(
                    str(key).startswith(("stage_encoder.", "stop_actor."))
                    for key in count_state
                )
                else "legacy-factorized"
            )
    if (
        saved_allocation_mode is not None
        and str(saved_allocation_mode) != agent.slow_agent.allocation_mode
    ):
        raise ValueError(
            "checkpoint Slow allocation architecture is "
            f"{saved_allocation_mode!r}, but the current run requested "
            f"{agent.slow_agent.allocation_mode!r}; resume with the same "
            "--slow-allocation-mode or start a fresh run"
        )
    if "slow_count_agent" in checkpoint:
        agent.slow_agent.count_ppo.policy.load_state_dict(checkpoint["slow_count_agent"])
    if "slow_count_optimizer" in checkpoint:
        agent.slow_agent.count_ppo.optimizer.load_state_dict(checkpoint["slow_count_optimizer"])
    if checkpoint.get("slow_stage_agent") is not None:
        if agent.slow_agent.stage_ppo is None:
            raise ValueError("checkpoint contains a Slow Stage actor, but this mode does not")
        agent.slow_agent.stage_ppo.policy.load_state_dict(checkpoint["slow_stage_agent"])
    if checkpoint.get("slow_stage_optimizer") is not None:
        if agent.slow_agent.stage_ppo is None:
            raise ValueError("checkpoint contains a Slow Stage optimizer, but this mode does not")
        agent.slow_agent.stage_ppo.optimizer.load_state_dict(checkpoint["slow_stage_optimizer"])
    if "slow_placement_agent" in checkpoint:
        agent.slow_agent.placement_ppo.policy.load_state_dict(checkpoint["slow_placement_agent"])
        if "slow_placement_optimizer" in checkpoint:
            agent.slow_agent.placement_ppo.optimizer.load_state_dict(checkpoint["slow_placement_optimizer"])
    elif "slow_agent" in checkpoint:
        agent.slow_agent.placement_ppo.policy.load_state_dict(checkpoint["slow_agent"])
    if "slow_window_critic" in checkpoint:
        agent.slow_agent.window_critic.load_state_dict(checkpoint["slow_window_critic"])
    if "slow_window_critic_optimizer" in checkpoint:
        agent.slow_agent.critic_optimizer.load_state_dict(checkpoint["slow_window_critic_optimizer"])
    if "slow_window_critic_return_mean" in checkpoint:
        agent.slow_agent.critic_return_mean = float(
            checkpoint["slow_window_critic_return_mean"]
        )
        agent.slow_agent.critic_return_std = float(
            checkpoint["slow_window_critic_return_std"]
        )
        agent.slow_agent.critic_update_index = int(
            checkpoint.get("slow_window_critic_update_index", 0)
        )
        agent.slow_agent.last_window_critic_holdout_ev = float(
            checkpoint.get("slow_window_critic_last_holdout_ev", 0.0)
        )
        replay_states = checkpoint.get("slow_window_critic_replay_states")
        replay_returns = checkpoint.get("slow_window_critic_replay_returns")
        replay_update_ids = checkpoint.get("slow_window_critic_replay_update_ids")
        replay_episode_ids = checkpoint.get("slow_window_critic_replay_episode_ids")
        if torch.is_tensor(replay_states) and replay_states.numel() > 0:
            agent.slow_agent.critic_replay_states = [
                state.numpy().copy() for state in replay_states.cpu()
            ]
        if torch.is_tensor(replay_returns):
            agent.slow_agent.critic_replay_returns = [
                float(value) for value in replay_returns.cpu().tolist()
            ]
        if torch.is_tensor(replay_update_ids):
            agent.slow_agent.critic_replay_update_ids = [
                int(value) for value in replay_update_ids.cpu().tolist()
            ]
        if torch.is_tensor(replay_episode_ids):
            agent.slow_agent.critic_replay_episode_ids = [
                int(value) for value in replay_episode_ids.cpu().tolist()
            ]
        elif agent.slow_agent.critic_replay_returns:
            # Old checkpoints did not persist episode ids. Keep them loadable by
            # reconstructing the historical default of six windows per episode.
            fallback_windows_per_episode = max(
                agent.slow_agent.critic_holdout_windows
                // agent.slow_agent.critic_holdout_episodes,
                1,
            )
            agent.slow_agent.critic_replay_episode_ids = list(
                index // fallback_windows_per_episode
                for index in range(len(agent.slow_agent.critic_replay_returns))
            )
        agent.slow_agent.critic_episode_index = int(
            checkpoint.get(
                "slow_window_critic_episode_index",
                max(agent.slow_agent.critic_replay_episode_ids, default=-1) + 1,
            )
        )
    if "fast_agent" in checkpoint:
        agent.fast_agent.ppo.policy.load_state_dict(checkpoint["fast_agent"])
    if "fast_optimizer" in checkpoint:
        agent.fast_agent.ppo.optimizer.load_state_dict(checkpoint["fast_optimizer"])
    if "fast_value_normalization" in checkpoint:
        agent.fast_agent.ppo.load_value_normalization_state(checkpoint["fast_value_normalization"])
    if "slow_component_value_normalization" in checkpoint:
        for name, ppo in (("count", agent.slow_agent.count_ppo), ("stage", agent.slow_agent.stage_ppo),
                          ("placement", agent.slow_agent.placement_ppo)):
            state = checkpoint["slow_component_value_normalization"].get(name)
            if ppo is not None and state is not None:
                ppo.load_value_normalization_state(state)
    if agent.slow_agent.learning_repair != "none":
        for name, ppo in (("count", agent.slow_agent.count_ppo), ("stage", agent.slow_agent.stage_ppo),
                          ("placement", agent.slow_agent.placement_ppo)):
            state = checkpoint.get("slow_conditional_learning_state", {}).get(name)
            if ppo is not None and state is not None:
                ppo.slow_conditional_learning.load_state_dict(state)
            if ppo is not None and checkpoint.get("slow_learning_repair", "none") == "none":
                # MSE -> Huber changes the value-gradient scale and direction.
                # Preserve policy/Actor Adam exactly; start only Critic moments
                # afresh rather than dragging obsolete MSE momentum into replay.
                for parameter in ppo.policy.critic.parameters():
                    ppo.optimizer.state.pop(parameter, None)
    if "slow_placement_updates_completed" in checkpoint:
        agent.slow_agent.placement_updates_completed = int(checkpoint["slow_placement_updates_completed"])
    if "slow_placement_entropy_current_coef" in checkpoint:
        agent.slow_agent.placement_entropy_current_coef = float(checkpoint["slow_placement_entropy_current_coef"])
    else:
        agent.slow_agent.placement_entropy_current_coef = agent.slow_agent.placement_entropy_schedule_coefficient()
    agent.slow_agent.placement_ppo.entropy_coef = agent.slow_agent.placement_entropy_coefficient()
    if "fast_entropy_current_coef" in checkpoint:
        agent.fast_agent.entropy_current_coef = float(checkpoint["fast_entropy_current_coef"])
        agent.fast_agent.ppo.entropy_coef = agent.fast_agent.entropy_current_coef
    _restore_pending_slow_collection(agent, checkpoint.get("pending_slow_collection"))
    if restore_rng and random_streams is not None and checkpoint.get("training_random_streams") is not None:
        random_streams.load_state_dict(checkpoint["training_random_streams"])
    if restore_rng and "numpy_random_state" in checkpoint:
        numpy_state = checkpoint["numpy_random_state"]
        np.random.set_state(
            (
                str(numpy_state["bit_generator"]),
                np.asarray(numpy_state["keys"], dtype=np.uint32),
                int(numpy_state["position"]),
                int(numpy_state["has_gauss"]),
                float(numpy_state["cached_gaussian"]),
            )
        )
    if restore_rng and "torch_random_state" in checkpoint:
        torch.set_rng_state(_cpu_byte_rng_state(checkpoint["torch_random_state"]))
    if restore_rng and torch.cuda.is_available() and checkpoint.get("torch_cuda_random_state") is not None:
        torch.cuda.set_rng_state_all(
            [_cpu_byte_rng_state(state) for state in checkpoint["torch_cuda_random_state"]]
        )
    return checkpoint.get("metadata", {})


def _cpu_byte_rng_state(state: object) -> torch.Tensor:
    """Canonicalize saved CPU/CUDA RNG state for PyTorch generators."""

    if torch.is_tensor(state):
        return state.detach().to(device="cpu", dtype=torch.uint8).contiguous()
    return torch.as_tensor(state, dtype=torch.uint8, device="cpu").contiguous()


_LOG_HEADERS = {}


def append_log(path: Path, row: dict[str, float | int | str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not path.exists() or path.stat().st_size == 0
    if write_header:
        _LOG_HEADERS[path] = list(row)
    elif path not in _LOG_HEADERS:
        with path.open(newline="", encoding="utf-8") as source:
            _LOG_HEADERS[path] = next(csv.reader(source))
    fields = _LOG_HEADERS[path]
    with path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        if write_header:
            writer.writeheader()
        writer.writerow(row)
    extra = {key:value for key,value in row.items() if key not in fields}
    if extra:
        # Never append wider/reordered rows beneath an archived CSV header.
        identity = {key:row[key] for key in ("update", "episode", "rollout") if key in row}
        append_log(path.with_name(path.stem+"_extensions_v2.csv"), {**identity, **extra})


def write_single_row_csv(path: Path, row: dict[str, float | int | str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(row.keys()))
        writer.writeheader()
        writer.writerow(row)


def format_group_diagnostics(
    diagnostics: dict[float, dict[str, float]],
    metric: str,
) -> str:
    return ";".join(
        f"{group_id:g}={values.get(metric, float('nan')):.8g}"
        for group_id, values in sorted(diagnostics.items())
    )


def load_adjusted_rolling_latency(
    history: list[dict[str, float]],
    window: int,
    reference_load: float,
) -> tuple[float, float]:
    """Return a rolling latency score corrected to one fixed demand load.

    A non-negative least-squares slope is fitted over all available update
    observations.  Checkpoint ranking then averages only the newest ``window``
    load-adjusted observations, avoiding selection of a single easy rollout.
    """

    if window < 1:
        raise ValueError("checkpoint rolling window must be positive")
    finite = [
        item
        for item in history
        if np.isfinite(item.get("latency_s", np.nan))
        and np.isfinite(item.get("load_multiplier", np.nan))
    ]
    if not finite:
        return float("inf"), 0.0
    loads = np.asarray([item["load_multiplier"] for item in finite], dtype=np.float64)
    latencies = np.asarray([item["latency_s"] for item in finite], dtype=np.float64)
    centered_loads = loads - float(loads.mean())
    denominator = float(np.dot(centered_loads, centered_loads))
    slope = 0.0
    if denominator > 1e-12:
        slope = max(
            float(np.dot(centered_loads, latencies - float(latencies.mean())) / denominator),
            0.0,
        )
    adjusted = latencies - slope * (loads - float(reference_load))
    return float(np.mean(adjusted[-window:])), slope


class SlowLearningRateController:
    """KL-gated, independent learning-rate control for the two Slow actors.

    A joint latency plateau is not sufficient evidence that either Slow actor
    is taking steps that are too large: Fast is changing at the same time, and
    an actor whose KL is already tiny must not be made even less responsive.
    Count and Placement therefore keep independent patience/reduction state,
    and a reduction normally requires a meaningful fraction of its PPO KL
    budget. Placement may override that gate after it has fallen below its
    entropy target, where many small one-sided steps can still accumulate into
    a harmful drift.
    """

    def __init__(
        self,
        *,
        enabled: bool,
        patience: int,
        factor: float,
        min_delta: float,
        min_lr: float,
        count_min_lr: float | None = None,
        placement_min_lr: float | None = None,
        kl_floor_fraction: float = 0.10,
        max_reductions: int = 1,
        cooldown_updates: int = 20,
        state: object = None,
        independent_stage: bool = False,
    ) -> None:
        self.enabled = bool(enabled)
        self.patience = int(patience)
        self.factor = float(factor)
        self.min_delta = float(min_delta)
        self.min_lr = float(min_lr)
        self.min_lrs = {
            "count": float(self.min_lr if count_min_lr is None else count_min_lr),
            "placement": float(
                self.min_lr if placement_min_lr is None else placement_min_lr
            ),
        }
        self.kl_floor_fraction = float(kl_floor_fraction)
        self.max_reductions = int(max_reductions)
        self.cooldown_updates = int(cooldown_updates)
        self.independent_stage = bool(independent_stage)
        if self.independent_stage:
            self.min_lrs["stage"] = self.min_lrs["count"]
        self.actor_state: dict[str, dict[str, float | int]] = {
            actor: {
                "best_score": float("inf"),
                "bad_updates": 0,
                "reductions": 0,
                "cooldown_remaining": 0,
                "low_kl_blocks": 0,
                "low_entropy_overrides": 0,
            }
            for actor in (("count", "stage", "placement") if self.independent_stage else ("count", "placement"))
        }
        if isinstance(state, dict):
            saved_actors = state.get("actors")
            if isinstance(saved_actors, dict):
                for actor in self.actor_state:
                    saved = saved_actors.get(actor)
                    if isinstance(saved, dict):
                        for key in self.actor_state[actor]:
                            if key in saved:
                                value = saved[key]
                                self.actor_state[actor][key] = (
                                    float(value) if key == "best_score" else int(value)
                                )
            else:
                # Old checkpoints stored one controller for both actors.
                # Reconstruct both sides without changing checkpoint loading.
                for actor in self.actor_state:
                    self.actor_state[actor]["best_score"] = float(
                        state.get("best_score", float("inf"))
                    )
                    self.actor_state[actor]["bad_updates"] = int(
                        state.get("bad_updates", 0)
                    )
                    self.actor_state[actor]["reductions"] = int(
                        state.get("reductions", 0)
                    )

    @property
    def best_score(self) -> float:
        return min(float(state["best_score"]) for state in self.actor_state.values())

    @property
    def bad_updates(self) -> int:
        return max(int(state["bad_updates"]) for state in self.actor_state.values())

    @property
    def reductions(self) -> int:
        return max(int(state["reductions"]) for state in self.actor_state.values())

    def actor_metric(self, actor: str, key: str) -> float | int:
        return self.actor_state[actor][key]

    def enforce_minimum_lrs(self, agent: HierarchicalPPOAgent) -> bool:
        """Lift optimizer LRs from older checkpoints to the configured floors."""

        changed = False
        optimizers = {
            "count": [
                agent.slow_agent.count_ppo.optimizer,
                *(
                    [agent.slow_agent.stage_ppo.optimizer]
                    if agent.slow_agent.stage_ppo is not None
                    else []
                ),
            ],
            "placement": [agent.slow_agent.placement_ppo.optimizer],
        }
        if self.independent_stage and agent.slow_agent.stage_ppo is not None:
            optimizers["count"] = [agent.slow_agent.count_ppo.optimizer]
            optimizers["stage"] = [agent.slow_agent.stage_ppo.optimizer]
        for actor, actor_optimizers in optimizers.items():
            for optimizer in actor_optimizers:
                for group in optimizer.param_groups:
                    if group.get("role") == "critic":
                        continue
                    old_lr = float(group["lr"])
                    new_lr = max(old_lr, self.min_lrs[actor])
                    group["lr"] = new_lr
                    changed = changed or new_lr > old_lr + 1e-15
        return changed

    @staticmethod
    def optimizer_lr(optimizer: torch.optim.Optimizer) -> float:
        return float(optimizer.param_groups[0]["lr"])

    def observe(
        self,
        score: float,
        *,
        ready: bool,
        slow_updated: bool,
        agent: HierarchicalPPOAgent,
        count_approx_kl: float | None = None,
        stage_approx_kl: float | None = None,
        placement_approx_kl: float | None = None,
        count_target_kl: float | None = None,
        placement_target_kl: float | None = None,
        placement_entropy: float | None = None,
        placement_entropy_target: float | None = None,
        low_entropy_override: bool = False,
    ) -> bool:
        if not self.enabled or not ready or not slow_updated or not np.isfinite(score):
            return False
        changed = False
        count_kl_values = [
            value
            for value in (count_approx_kl, stage_approx_kl)
            if value is not None and np.isfinite(value)
        ]
        effective_count_kl = max(count_kl_values) if count_kl_values else None
        actor_inputs = {
            "count": (
                [
                    agent.slow_agent.count_ppo.optimizer,
                    *(
                        [agent.slow_agent.stage_ppo.optimizer]
                        if agent.slow_agent.stage_ppo is not None
                        else []
                    ),
                ],
                effective_count_kl,
                count_target_kl,
            ),
            "placement": (
                [agent.slow_agent.placement_ppo.optimizer],
                placement_approx_kl,
                placement_target_kl,
            ),
        }
        if self.independent_stage:
            actor_inputs["count"] = ([agent.slow_agent.count_ppo.optimizer], count_approx_kl, count_target_kl)
            if agent.slow_agent.stage_ppo is not None:
                actor_inputs["stage"] = ([agent.slow_agent.stage_ppo.optimizer], stage_approx_kl, count_target_kl)
        for actor, (actor_optimizers, approx_kl, target_kl) in actor_inputs.items():
            actor_state = self.actor_state[actor]
            if score < float(actor_state["best_score"]) - self.min_delta:
                actor_state["best_score"] = float(score)
                actor_state["bad_updates"] = 0
                continue
            if int(actor_state["cooldown_remaining"]) > 0:
                actor_state["cooldown_remaining"] = (
                    int(actor_state["cooldown_remaining"]) - 1
                )
                actor_state["bad_updates"] = 0
                continue
            if int(actor_state["reductions"]) >= self.max_reductions:
                actor_state["bad_updates"] = 0
                continue
            placement_is_under_exploring = bool(
                actor == "placement"
                and low_entropy_override
                and placement_entropy is not None
                and placement_entropy_target is not None
                and np.isfinite(placement_entropy)
                and np.isfinite(placement_entropy_target)
                and placement_entropy_target > 0.0
                and placement_entropy < placement_entropy_target
            )
            low_kl = bool(
                approx_kl is not None
                and target_kl is not None
                and np.isfinite(approx_kl)
                and np.isfinite(target_kl)
                and target_kl > 0.0
                and approx_kl < self.kl_floor_fraction * target_kl
            )
            if low_kl and not placement_is_under_exploring:
                actor_state["low_kl_blocks"] = int(actor_state["low_kl_blocks"]) + 1
                actor_state["bad_updates"] = 0
                continue
            if low_kl and placement_is_under_exploring:
                # Low one-step KL normally prevents a needless LR reduction.
                # Once Placement is already under-exploring, however, many
                # individually small biased updates can accumulate into a
                # large policy drift. Let the sustained score guard count it.
                actor_state["low_entropy_overrides"] = (
                    int(actor_state["low_entropy_overrides"]) + 1
                )
            actor_state["bad_updates"] = int(actor_state["bad_updates"]) + 1
            if int(actor_state["bad_updates"]) < self.patience:
                continue

            actor_changed = False
            for optimizer in actor_optimizers:
                for group in optimizer.param_groups:
                    if group.get("role") == "critic":
                        continue
                    old_lr = float(group["lr"])
                    new_lr = min(
                        old_lr,
                        max(self.min_lrs[actor], old_lr * self.factor),
                    )
                    group["lr"] = new_lr
                    actor_changed = actor_changed or new_lr < old_lr - 1e-15
            actor_state["bad_updates"] = 0
            if actor_changed:
                actor_state["reductions"] = int(actor_state["reductions"]) + 1
                actor_state["cooldown_remaining"] = self.cooldown_updates
                changed = True
        return changed

    def state_dict(self) -> dict[str, object]:
        return {
            "best_score": self.best_score,
            "bad_updates": self.bad_updates,
            "reductions": self.reductions,
            "actors": {
                actor: dict(actor_state)
                for actor, actor_state in self.actor_state.items()
            },
        }


def slow_colocation_credit_coefficient(
    args: argparse.Namespace,
    completed_updates: int,
) -> float:
    """Anneal duplicate locality shaping while retaining measured link latency."""

    initial = float(getattr(args, "slow_colocation_coef", 0.0))
    configured_final = getattr(args, "slow_colocation_final_coef", None)
    final = initial if configured_final is None else float(configured_final)
    hold = max(int(getattr(args, "slow_colocation_hold_updates", 0)), 0)
    decay = max(int(getattr(args, "slow_colocation_decay_updates", 1)), 1)
    progress = float(np.clip((int(completed_updates) - hold) / decay, 0.0, 1.0))
    return float(initial + progress * (final - initial))


def fast_counterfactual_credit_coefficient(
    args: argparse.Namespace,
    completed_updates: int,
) -> float:
    """Anneal structural Fast guidance after it has taught chain locality."""

    initial = float(getattr(args, "fast_counterfactual_credit_coef", 0.0))
    final = float(
        getattr(args, "fast_counterfactual_credit_final_coef", initial)
    )
    hold = max(
        int(getattr(args, "fast_counterfactual_credit_hold_updates", 0)),
        0,
    )
    decay = max(
        int(getattr(args, "fast_counterfactual_credit_decay_updates", 1)),
        1,
    )
    progress = np.clip((int(completed_updates) - hold) / float(decay), 0.0, 1.0)
    return float(initial + float(progress) * (final - initial))


def checkpoint_reference_load(args: argparse.Namespace) -> float:
    strata = _load_strata_for_args(args)
    probabilities = _load_probabilities_for_args(args, len(strata))
    midpoints = np.asarray([(low + high) * 0.5 for low, high in strata], dtype=np.float64)
    return float(np.dot(midpoints, np.asarray(probabilities, dtype=np.float64)))


def make_run_paths(args: argparse.Namespace) -> tuple[str, Path, Path, Path]:
    mode_tag = args.train_mode.replace("-", "_")
    run_name = args.run_name or (
        f"dual_ppo_{mode_tag}_u{args.num_users}_n{args.num_edge_nodes}_"
        f"s{args.num_service_types}_seed{args.seed}"
    )
    run_dir = Path(args.run_root) / run_name
    log_dir = Path(args.log_dir) if args.log_dir else run_dir / "logs"
    save_dir = Path(args.save_dir) if args.save_dir else run_dir / "checkpoints"
    return run_name, run_dir, log_dir, save_dir


def write_metadata(path: Path, args: argparse.Namespace, bc_metrics: dict[str, float], loaded_metadata: dict[str, object]) -> None:
    path.mkdir(parents=True, exist_ok=True)
    metadata = {
        "args": vars(args),
        "bc_metrics": bc_metrics,
        "loaded_checkpoint_metadata": loaded_metadata,
        "created_at": datetime.now().replace(microsecond=0).isoformat(),
        "reference_style": "DRL-AC-Allocation sequential masked PPO with staged train/eval separation",
    }
    (path / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")


def resolve_eval_rollout_unit(args: argparse.Namespace) -> str:
    if args.eval_rollout_unit == "same":
        return args.rollout_unit
    return args.eval_rollout_unit


def resolve_fast_chain_context(args: argparse.Namespace) -> str:
    """Use causal KKT chain context for new runs and preserve checkpoint dimensions."""

    requested = str(getattr(args, "fast_chain_context", "auto"))
    if requested != "auto":
        return requested
    checkpoint_raw = getattr(args, "load_checkpoint", None)
    if not checkpoint_raw:
        return "chain-kkt-v3"
    checkpoint_path = Path(checkpoint_raw)
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    embedded_args = checkpoint.get("metadata", {}).get("args", {})
    checkpoint_args = embedded_args if isinstance(embedded_args, dict) else {}
    if not checkpoint_args:
        sidecar_path = checkpoint_path.parent.parent / "metadata.json"
        if sidecar_path.is_file():
            with sidecar_path.open("r", encoding="utf-8") as handle:
                checkpoint_args = dict(json.load(handle).get("args", {}))
    return str(checkpoint_args.get("fast_chain_context", "legacy"))


def resolve_training_repair(args: argparse.Namespace) -> str:
    requested = str(getattr(args, "training_repair", "auto"))
    if requested != "auto":
        return requested
    checkpoint_path = getattr(args, "load_checkpoint", None)
    if checkpoint_path:
        checkpoint = torch.load(Path(checkpoint_path), map_location="cpu")
        return str(checkpoint.get("training_repair", "legacy"))
    return "batch-credit-v1" if args.pressure_profile == "mec-latency200" else "legacy"


def resolve_slow_deployment_context(args: argparse.Namespace) -> str:
    requested = getattr(args, "slow_deployment_context", "auto")
    if requested != "auto":
        return requested
    if args.load_checkpoint:
        return str(torch.load(Path(args.load_checkpoint), map_location="cpu").get("slow_deployment_context", "legacy"))
    return ("deployment-aware-v2" if args.pressure_profile == "mec-latency200"
            and args.training_repair == "batch-credit-v1" and args.slow_allocation_mode == "budget-continuous-v2"
            else "legacy")


def resolve_slow_learning_repair(args: argparse.Namespace) -> str:
    requested = getattr(args, "slow_learning_repair", "auto")
    if requested != "auto":
        return requested
    if args.load_checkpoint:
        return str(torch.load(Path(args.load_checkpoint), map_location="cpu").get("slow_learning_repair", "none"))
    return "conditional-replay-v1" if args.slow_deployment_context in {"deployment-aware-v2", "deployment-chain-v3"} else "none"


def resolve_slow_quota_decode(args: argparse.Namespace) -> str:
    requested = getattr(args, "slow_quota_decode", "auto")
    if requested != "auto":
        return requested
    if getattr(args, "load_checkpoint", None):
        checkpoint = torch.load(Path(args.load_checkpoint), map_location="cpu")
        return str(checkpoint.get("slow_quota_decode", "mean"))
    return ("categorical-mean" if args.slow_allocation_mode in {"stage-budget-v5", "stage-budget-v6"}
            else "categorical-mode" if args.slow_allocation_mode == "stage-budget-v4" else "mean")


def initialize_fast_checkpoint(agent, path: Path, args) -> dict[str, object]:
    """Transfer Fast only. This is NOT continuation of a previous training run."""
    checkpoint = torch.load(path, map_location="cpu")
    source_args = checkpoint.get("metadata", {}).get("args", {})
    if not source_args:
        with (path.parent.parent / "metadata.json").open(encoding="utf-8") as handle:
            source_args = json.load(handle)["args"]
    from edge_drl.comparison.checkpoint import CRITICAL_ENV_KEYS
    for name in CRITICAL_ENV_KEYS + ("fast_policy_kind", "fast_chain_context", "reward_mode", "reward_scale", "max_service_stages"):
        if name == "service_calibration_document":
            continue
        current = getattr(args, name, None)
        if name in source_args and source_args[name] != current:
            raise ValueError(f"Fast initialization configuration conflict: {name}")
    source_physical_seed = source_args.get("physical_seed")
    current_physical_seed = getattr(args, "physical_seed", None)
    if (source_args.get("seed", 2026) if source_physical_seed is None else source_physical_seed) != (args.seed if current_physical_seed is None else current_physical_seed):
        raise ValueError("Fast initialization physical seed differs")
    if source_args.get("service_calibration_document") != getattr(args, "service_calibration_document", None):
        raise ValueError("Fast initialization service calibration document differs")
    if checkpoint.get("training_repair", "legacy") != args.training_repair:
        raise ValueError("Fast initialization training repair differs")
    actor_only = bool(getattr(args, "init_fast_actor_only", False))
    if actor_only:
        state = {key:value for key,value in checkpoint["fast_agent"].items() if not key.startswith("critic.")}
        missing, unexpected = agent.fast_agent.ppo.policy.load_state_dict(state, strict=False)
        if unexpected or any(not key.startswith("critic.") for key in missing):
            raise ValueError("Fast actor-only initialization architecture mismatch")
    else:
        agent.fast_agent.ppo.policy.load_state_dict(checkpoint["fast_agent"], strict=True)
    if agent.fast_agent.batch_credit and not actor_only:
        agent.fast_agent.ppo.load_value_normalization_state(checkpoint["fast_value_normalization"])
    return {"path": str(path.resolve()), "source_update": checkpoint.get("metadata", {}).get("update"),
            "scope": "fast_actor_only_new_critic" if actor_only else "fast_weights_and_value_scale_only", "resume": False}


def checkpoint_run_args(path: Path, checkpoint: dict) -> dict:
    """Recover the ORIGINAL run configuration, including legacy sidecars.

    Older training checkpoints omitted args even though metadata.json saved
    them. Missing embedded args are not permission to revert shared-NIC,
    audited workloads or temporal sampling to the legacy defaults on resume.
    """
    embedded = checkpoint.get("metadata", {}).get("args", {})
    if embedded:
        return dict(embedded)
    for parent in list(path.resolve().parents)[:3]:
        metadata_path = parent / "metadata.json"
        if metadata_path.is_file():
            with metadata_path.open(encoding="utf-8") as handle:
                saved_args = json.load(handle).get("args", {})
            if saved_args:
                return dict(saved_args)
    if checkpoint.get("training_repair", "legacy") != "legacy":
        raise ValueError("repaired checkpoint is missing original run args/metadata.json; cannot safely restore the physical environment")
    return {}


def apply_proposed_design(args):
    """Opt-in preset; archived commands/checkpoints never silently upgrade."""
    explicit = {token.split("=", 1)[0] for token in sys.argv[1:]}
    saved = {}
    if getattr(args, "load_checkpoint", None):
        checkpoint = torch.load(Path(args.load_checkpoint), map_location="cpu")
        saved = checkpoint_run_args(Path(args.load_checkpoint), checkpoint)
    requested = getattr(args, "proposed_design", "auto")
    args.proposed_design = saved.get("proposed_design", "legacy") if requested == "auto" else requested
    if args.proposed_design not in {"joint-credit-v2", "joint-credit-v3", "joint-credit-v4", "joint-credit-v5"}:
        # New flags must also survive a legacy-design full resume.
        for name, default in (("fast_update_chunks", 1), ("fast_independent_critic", False),
                              ("checkpoint_probe_interval", 10)):
            if "--"+name.replace("_", "-") not in explicit:
                setattr(args, name, saved.get(name, getattr(args, name, default)))
        return args
    if saved and saved.get("proposed_design", "legacy") != args.proposed_design:
        raise ValueError(f"{args.proposed_design} changes Slow action semantics: start a fresh run, not full legacy resume")
    deployment_context = "deployment-aware-v2"
    if args.proposed_design in {"joint-credit-v3", "joint-credit-v4", "joint-credit-v5"}:
        deployment_context = (getattr(args, "slow_deployment_context", "auto")
                              if "--slow-deployment-context" in explicit
                              else saved.get("slow_deployment_context", "deployment-chain-v3" if args.proposed_design == "joint-credit-v5" else "deployment-aware-v2"))
        if deployment_context == "auto":
            deployment_context = saved.get("slow_deployment_context", "deployment-chain-v3" if args.proposed_design == "joint-credit-v5" else "deployment-aware-v2")
        if deployment_context not in {"deployment-aware-v2", "deployment-chain-v3"}:
            raise ValueError("integer joint designs require deployment-aware-v2 or deployment-chain-v3")
    required = {"training_repair":"batch-credit-v1", "slow_deployment_context":deployment_context,
                "slow_learning_repair":"prefix-structured-v3" if args.proposed_design == "joint-credit-v5" else "prefix-credit-v2",
                "slow_allocation_mode":{"joint-credit-v2":"stage-budget-v3", "joint-credit-v3":"stage-budget-v4", "joint-credit-v4":"stage-budget-v5", "joint-credit-v5":"stage-budget-v6"}[args.proposed_design],
                "fast_chain_context":"chain-kkt-v3", "fast_policy_kind":"gat_node_scorer",
                "joint_training_schedule":"simultaneous", "train_mode":"joint"}
    for name, value in required.items():
        current = getattr(args, name, None)
        if "--"+name.replace("_", "-") in explicit and current not in {value, "auto"}:
            raise ValueError(f"{args.proposed_design} requires --{name.replace('_','-')} {value}")
        setattr(args, name, value)
    defaults = {"fast_update_chunks":4, "fast_independent_critic":True,
                "slow_tail_latency_coef":0., "slow_deployment_memory_coef":0.,
                "slow_deployment_storage_coef":0., "slow_deadline_violation_coef":0.,
                "slow_colocation_coef":0., "slow_colocation_final_coef":0.,
                "slow_shared_return_coef":0., "slow_counterfactual_credit_coef":0.,
                "slow_count_global_advantage_coef":0., "slow_placement_global_advantage_coef":0.,
                "slow_placement_global_attribution_coef":0., "slow_idle_replica_coef":0.,
                "slow_count_unused_replica_coef":0., "slow_placement_idle_coef":0.,
                "slow_placement_compute_coef":0., "slow_count_shortage_coef":0.,
                "slow_replica_ablation_samples":0, "fast_oracle_diagnostic_requests":0,
                "fast_counterfactual_credit_coef":0., "fast_counterfactual_credit_final_coef":0.}
    if args.proposed_design == "joint-credit-v5":
        defaults.update(slow_critic_replay_windows=24, slow_critic_holdout_windows=6,
                        slow_critic_holdout_episodes=1)
    for name, value in defaults.items():
        if not {"--"+name.replace("_", "-"), "--no-"+name.replace("_", "-")} & explicit:
            setattr(args, name, saved.get(name, value))
    if getattr(args, "fast_warmup_updates", 0) or getattr(args, "slow_warmup_updates", 0):
        raise ValueError(f"{args.proposed_design} keeps simultaneous joint training without phased warmups")
    return args


def main() -> None:
    args = parse_args()
    args = apply_proposed_design(args)
    args.fast_chain_context = resolve_fast_chain_context(args)
    args.training_repair = resolve_training_repair(args)
    args.slow_deployment_context = resolve_slow_deployment_context(args)
    args.slow_learning_repair = resolve_slow_learning_repair(args)
    args.slow_quota_decode = resolve_slow_quota_decode(args)
    if args.load_checkpoint and args.init_fast_checkpoint:
        raise ValueError("--load-checkpoint and --init-fast-checkpoint are mutually exclusive")
    if args.load_checkpoint and args.init_slow_checkpoint:
        raise ValueError("--load-checkpoint and --init-slow-checkpoint are mutually exclusive")
    if args.init_fast_actor_only and not args.init_fast_checkpoint:
        raise ValueError("--init-fast-actor-only requires --init-fast-checkpoint")
    args.rollout_acceleration_version = "vector-features-v1"
    args.network_allocator_version = "shared-nic-certified-v4"
    if args.training_repair == "batch-credit-v1":
        explicit_controls = {token.split("=", 1)[0] for token in sys.argv[1:]}
        for name in ("slow_counterfactual_credit_coef", "slow_replica_ablation_samples", "fast_oracle_diagnostic_requests",
                     "fast_counterfactual_credit_coef", "fast_counterfactual_credit_final_coef"):
            if "--" + name.replace("_", "-") not in explicit_controls:
                setattr(args, name, 0)
    if args.load_checkpoint:
        saved = torch.load(Path(args.load_checkpoint), map_location="cpu")
        saved_args = checkpoint_run_args(Path(args.load_checkpoint), saved)
        explicit = {t.split("=", 1)[0] for t in sys.argv[1:]}
        for name, default in (("network_constraint_mode", "edge-only"), ("service_calibration_mode", "legacy"),
                              ("service_calibration_file", None), ("temporal_sampling_mode", "left-hold"),
                              ("sampling_max_interval_seconds", 0.0)):
            if "--" + name.replace("_", "-") not in explicit:
                setattr(args, name, saved_args.get(name, default))
        args.service_calibration_document = saved_args.get("service_calibration_document")
        if "--service-calibration-file" in explicit:
            args.service_calibration_document = None
    if args.service_calibration_mode == "audited-v1" and getattr(args, "service_calibration_document", None) is None:
        from edge_drl.env.calibration import load_budget_document
        args.service_calibration_document = load_budget_document(args.service_calibration_file)
    eval_rollout_unit = resolve_eval_rollout_unit(args)
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    training_random_streams = TrainingRandomStreams(args.seed)

    env = build_env(args)
    env.reset()
    traffic = traffic_rate_summary(env)
    replica_action_dim = effective_replicas_per_stage(args)
    agent = HierarchicalPPOAgent.from_env(
        env,
        device=args.device,
        replicas_per_stage=replica_action_dim,
        slow_lr=args.slow_lr,
        slow_count_lr=args.slow_count_lr,
        slow_stage_lr=args.slow_stage_lr,
        slow_placement_lr=args.slow_placement_lr,
        fast_lr=args.fast_lr,
        slow_k_epochs=args.slow_k_epochs,
        slow_stage_k_epochs=args.slow_stage_k_epochs,
        slow_placement_k_epochs=args.slow_placement_k_epochs,
        fast_k_epochs=args.fast_k_epochs,
        slow_entropy_coef=args.slow_entropy_coef,
        slow_count_entropy_coef=args.slow_count_entropy_coef,
        slow_placement_entropy_coef=args.slow_placement_entropy_coef,
        slow_placement_entropy_final_coef=args.slow_placement_entropy_final_coef,
        slow_placement_entropy_hold_updates=args.slow_placement_entropy_hold_updates,
        slow_placement_entropy_decay_updates=args.slow_placement_entropy_decay_updates,
        slow_placement_entropy_target=args.slow_placement_entropy_target,
        slow_placement_entropy_max_coef=args.slow_placement_entropy_max_coef,
        slow_placement_entropy_adaptation_rate=args.slow_placement_entropy_adaptation_rate,
        slow_count_global_advantage_coef=args.slow_count_global_advantage_coef,
        slow_placement_global_advantage_coef=args.slow_placement_global_advantage_coef,
        slow_placement_global_attribution_coef=args.slow_placement_global_attribution_coef,
        slow_global_advantage_ev_full=args.slow_global_advantage_ev_full,
        fast_entropy_coef=args.fast_entropy_coef,
        fast_entropy_target=args.fast_entropy_target,
        fast_entropy_max_coef=args.fast_entropy_max_coef,
        fast_entropy_adaptation_rate=args.fast_entropy_adaptation_rate,
        fast_entropy_normalized_control=args.fast_entropy_normalized_control,
        slow_value_coef=args.slow_value_coef,
        slow_count_value_coef=args.slow_count_value_coef,
        slow_critic_lr=args.slow_critic_lr,
        slow_critic_k_epochs=args.slow_critic_k_epochs,
        slow_critic_replay_windows=args.slow_critic_replay_windows,
        slow_critic_replay_decay=args.slow_critic_replay_decay,
        slow_critic_holdout_windows=args.slow_critic_holdout_windows,
        slow_critic_holdout_episodes=args.slow_critic_holdout_episodes,
        slow_critic_gradient_clip=args.slow_critic_gradient_clip,
        slow_window_gamma=args.slow_window_gamma,
        fast_value_coef=args.fast_value_coef,
        slow_target_kl=args.slow_target_kl,
        slow_count_target_kl=args.slow_count_target_kl,
        slow_placement_target_kl=args.slow_placement_target_kl,
        fast_target_kl=args.fast_target_kl,
        slow_minibatch_size=args.slow_minibatch_size,
        fast_minibatch_size=args.fast_minibatch_size,
        fast_policy_kind=args.fast_policy_kind,
        fast_chain_context=args.fast_chain_context,
        training_repair=args.training_repair,
        slow_team_value_coef=args.slow_team_value_coef,
        slow_deployment_context=args.slow_deployment_context,
        slow_learning_repair=args.slow_learning_repair,
        fast_reservation_microbatch_size=args.fast_reservation_microbatch_size,
        fast_load_balanced_updates=args.fast_load_balanced_updates,
        fast_load_group_weights=_load_probabilities_for_args(
            args,
            len(_load_strata_for_args(args)),
        ),
        fast_full_batch_kl_stop=args.fast_full_batch_kl_stop,
        fast_update_chunks=args.fast_update_chunks,
        fast_independent_critic=args.fast_independent_critic,
        slow_reward_scale=args.reward_scale,
        slow_tail_latency_coef=args.slow_tail_latency_coef,
        slow_colocation_coef=args.slow_colocation_coef,
        slow_deployment_memory_coef=args.slow_deployment_memory_coef,
        slow_deployment_storage_coef=args.slow_deployment_storage_coef,
        slow_migration_coef=args.slow_migration_coef,
        slow_idle_replica_coef=args.slow_idle_replica_coef,
        slow_count_unused_replica_coef=args.slow_count_unused_replica_coef,
        slow_placement_idle_coef=args.slow_placement_idle_coef,
        slow_placement_compute_coef=args.slow_placement_compute_coef,
        slow_count_shortage_coef=args.slow_count_shortage_coef,
        slow_count_latency_coef=args.slow_count_latency_coef,
        slow_deadline_violation_coef=args.slow_deadline_violation_coef,
        slow_shared_return_coef=args.slow_shared_return_coef,
        slow_deterministic_count_mode=args.slow_deterministic_count_mode,
        slow_allocation_mode=args.slow_allocation_mode,
        slow_quota_decode=args.slow_quota_decode,
        slow_counterfactual_credit_coef=args.slow_counterfactual_credit_coef,
    )
    agent.window_replica_ablation_samples = args.slow_replica_ablation_samples
    args.fast_initialization = (initialize_fast_checkpoint(agent, Path(args.init_fast_checkpoint), args)
                                if args.init_fast_checkpoint else None)
    args.slow_initialization = None
    if args.init_slow_checkpoint:
        from edge_drl.agents.slow_transfer import initialize_slow_actors
        args.slow_initialization = initialize_slow_actors(env, agent, args.init_slow_checkpoint,
                                                       scope=args.init_slow_actor_scope)
        # Matched actor-initialized arms start action sampling at the same RNG
        # state even when their fresh observation encoders have different sizes.
        action_sampling_seed = args.seed + 7_000_019
        torch.manual_seed(action_sampling_seed)
        args.slow_initialization["action_sampling_seed"] = action_sampling_seed
    loaded_metadata: dict[str, object] = {}
    if args.load_checkpoint:
        loaded_metadata = load_checkpoint(
            agent,
            Path(args.load_checkpoint),
            training_random_streams,
        )
        # Keep the run's original actor initialization provenance on resume.
        # No initialization is executed again and no fresh RNG is installed.
        args.fast_initialization = saved_args.get("fast_initialization")
        args.slow_initialization = saved_args.get("slow_initialization")
    bc_metrics = pretrain_fast_agent(
        args,
        agent,
        requests=0 if args.load_checkpoint or args.init_fast_checkpoint else args.fast_bc_requests,
        epochs=args.fast_bc_epochs,
    )

    print("Hierarchical dual-agent PPO")
    print("  reference_style=DRL-AC-Allocation masked PPO with joint per-second settlement")
    print(f"  users={args.num_users}, nodes={args.num_edge_nodes}, services={args.num_service_types}")
    print(
        "  traffic avg={:.2f}/s min={:.2f}/s peak={:.2f}/s expected_episode({}min)={:.0f}".format(
            traffic["avg_requests_per_second"],
            traffic["min_requests_per_second"],
            traffic["max_requests_per_second"],
            args.episode_minutes,
            traffic["expected_requests_per_episode"],
        )
    )
    print(f"  train_mode={args.train_mode}")
    print(f"  training_design={args.training_design}")
    print(f"  slow_deployment_context={args.slow_deployment_context}")
    print(f"  slow_learning_repair={args.slow_learning_repair}")
    print(f"  proposed_design={args.proposed_design} fast_update_chunks={args.fast_update_chunks} "
          f"fast_independent_critic={args.fast_independent_critic}")
    if args.proposed_design in {"joint-credit-v2", "joint-credit-v3", "joint-credit-v4", "joint-credit-v5"}:
        print("  slow_credit=real_window_return_with_prefix_GAE legacy_factorized_terms=diagnostics_only legacy_window_critic=disabled")
    if args.fast_initialization and not args.load_checkpoint:
        print(f"  Fast initialized from {args.fast_initialization['path']}; fresh optimizers and run counters")
    if args.slow_initialization and not args.load_checkpoint:
        print(f"  Slow actors initialized from {args.slow_initialization['path']}; "
              f"context={args.slow_initialization['source_context']}->{args.slow_initialization['target_context']} "
              "new critics/optimizers, zero new observation weights")
    print(f"  fast_policy_kind={args.fast_policy_kind}")
    print(
        f"  fast_chain_context={args.fast_chain_context} "
        f"counterfactual_credit={args.fast_counterfactual_credit_coef:.3f}"
        f"->{args.fast_counterfactual_credit_final_coef:.3f} "
        f"hold={args.fast_counterfactual_credit_hold_updates} "
        f"decay={args.fast_counterfactual_credit_decay_updates} "
        f"controllable_latency_credit={args.fast_controllable_latency_credit}"
    )
    print(f"  rollout_unit={args.rollout_unit}")
    print(f"  eval_rollout_unit={eval_rollout_unit}")
    print(f"  physical_seed={args.seed if args.physical_seed is None else args.physical_seed}")
    print(f"  pressure_profile={args.pressure_profile}")
    print(f"  training_repair={args.training_repair}")
    hardware_counts: dict[str, int] = {}
    assert env.scenario is not None
    for node in env.scenario.nodes:
        hardware_counts[node.hardware_type] = hardware_counts.get(node.hardware_type, 0) + 1
    print(
        f"  edge_node_profile={args.edge_node_profile} "
        f"hardware_mix={hardware_counts}"
    )
    print(f"  service_workload_profile={args.service_workload_profile}")
    print(
        "  physical_capacity compute={:.1f}-{:.1f}Gcycle/s "
        "memory={:.1f}-{:.1f}GB wired_uplink_cap={:.0f}-{:.0f}MB/s".format(
            min(node.compute_gcycles_per_s for node in env.scenario.nodes),
            max(node.compute_gcycles_per_s for node in env.scenario.nodes),
            min(node.memory_gb for node in env.scenario.nodes),
            max(node.memory_gb for node in env.scenario.nodes),
            min(node.network_uplink_mb_s for node in env.scenario.nodes),
            max(node.network_uplink_mb_s for node in env.scenario.nodes),
        )
    )
    service_compute = np.asarray(
        [sum(stage.compute_gcycles_mean for stage in service.stages) for service in env.scenario.services],
        dtype=np.float64,
    )
    service_memory = np.asarray(
        [sum(stage.memory_gb for stage in service.stages) for service in env.scenario.services],
        dtype=np.float64,
    )
    service_storage = np.asarray(
        [sum(stage.storage_gb for stage in service.stages) for service in env.scenario.services],
        dtype=np.float64,
    )
    service_inputs = np.asarray(
        [service.input_mb_mean for service in env.scenario.services],
        dtype=np.float64,
    )
    print(
        "  service_demand per_request_compute={:.2f}-{:.2f}Gcycle "
        "chain_memory={:.2f}-{:.2f}GB chain_storage={:.1f}-{:.1f}GB "
        "input={:.2f}-{:.2f}MB".format(
            float(service_compute.min()),
            float(service_compute.max()),
            float(service_memory.min()),
            float(service_memory.max()),
            float(service_storage.min()),
            float(service_storage.max()),
            float(service_inputs.min()),
            float(service_inputs.max()),
        )
    )
    print(f"  demand_sampling_mode={args.demand_sampling_mode}")
    if args.demand_scenario_schedule == "shuffled-pool":
        print(
            f"  demand_scenario_schedule=shuffled-pool "
            f"pool_size={args.demand_scenario_pool_size}"
        )
    else:
        print(f"  demand_scenario_schedule={args.demand_scenario_schedule}")
    print(f"  fast_windows_per_update={args.fast_windows_per_update}")
    print(f"  slow_windows_per_update={args.slow_windows_per_update}")
    print(
        f"  joint_training_schedule={args.joint_training_schedule} "
        f"fast_updates_per_cycle={args.fast_updates_per_cycle} "
        f"fast_warmup_updates={args.fast_warmup_updates} slow_warmup_updates={args.slow_warmup_updates}"
    )
    print(
        f"  fast_congestion_credit={args.fast_congestion_credit_coef} "
        f"reservation_microbatch={args.fast_reservation_microbatch_size}"
    )
    print(f"  topology_k_nearest={args.topology_k_nearest} deadline_scale={args.deadline_scale}")
    print(f"  synchronized_window_block={args.synchronized_window_block or 'disabled'}")
    print(f"  slow_tail_latency_coef={args.slow_tail_latency_coef:.2f} (P95 weight)")
    slow_colocation_final = (
        args.slow_colocation_coef
        if args.slow_colocation_final_coef is None
        else args.slow_colocation_final_coef
    )
    print(
        f"  slow_colocation_coef={args.slow_colocation_coef:.3f}->{slow_colocation_final:.3f} "
        f"hold={args.slow_colocation_hold_updates} decay={args.slow_colocation_decay_updates} "
        "(early cross-stage transition guidance)"
    )
    print(
        f"  slow_shared_return_coef={args.slow_shared_return_coef:.3f} "
        "colocation_credit=data-volume-weighted"
    )
    print(
        f"  slow_count_value_coef={args.slow_count_value_coef:.3f} "
        f"effective_conditional_coef={args.slow_team_value_coef if agent.slow_agent.team_window_credit else args.slow_count_value_coef:.3f} "
        "(repaired critics use detached backbones and normalized targets)"
    )
    print(
        f"  slow_count_lr={args.slow_count_lr:.6f} count_target_kl={args.slow_count_target_kl:.4f} "
        f"slow_fast_collection={args.slow_fast_collection_mode}"
    )
    deployment_windows = max(
        int(np.ceil(args.episode_minutes / args.deployment_interval_minutes)),
        1,
    )
    print(f"  episode_horizon={args.episode_minutes}min deployment_windows={deployment_windows}")
    print("  environment_step=1s request_granularity=individual batch_settlement=joint")
    window_seconds = args.deployment_interval_minutes * 60
    effective_sampled_seconds = (
        window_seconds
        if args.sampled_seconds_per_window == 0
        else min(args.sampled_seconds_per_window, window_seconds)
    )
    if args.sampled_seconds_per_window > 0 and args.sampling_max_interval_seconds > 0:
        effective_sampled_seconds = max(effective_sampled_seconds, int(np.ceil(window_seconds / args.sampling_max_interval_seconds)))
    print(
        f"  temporal_sampling train={effective_sampled_seconds}/{window_seconds}s "
        f"({effective_sampled_seconds / window_seconds:.1%}) eval=full requested={args.sampled_seconds_per_window} "
        f"hold_cap={args.sampling_max_interval_seconds:g}s temporal_mode={args.temporal_sampling_mode} "
        f"load_update={args.sampled_load_update_mode}"
    )
    print(f"  arrival_profile={args.arrival_profile}")
    if args.arrival_profile == "stationary":
        print("  rollout_start_mode=beginning (stationary demand; requested start modes have no effect)")
    else:
        print(f"  rollout_start_mode={args.rollout_start_mode} eval_rollout_start_mode={args.eval_rollout_start_mode}")
    print(
        f"  load_multipliers={args.load_multipliers} sampling={args.load_sampling_mode} "
        f"strata={args.load_strata or 'fixed-anchors'} "
        f"probabilities={args.load_stratum_probabilities}"
    )
    print(f"  scenario_refresh_episodes={args.scenario_refresh_episodes} demand_only=true")
    print(f"  reward_mode={args.reward_mode}")
    print(f"  optimizer_reward_scale={args.reward_scale}")
    print(
        f"  max_replicas_per_stage={replica_action_dim} "
        f"actual_replica_count=learned_by_count_ppo artificial_cap={'none' if args.replicas_per_stage == 0 else 'explicit'}"
    )
    print(
        f"  slow_allocation_mode={args.slow_allocation_mode} "
        f"slow_counterfactual_credit_coef={args.slow_counterfactual_credit_coef:.3f} "
        f"replica_ablation_samples={args.slow_replica_ablation_samples}"
    )
    print(f"  service_resource_fraction={args.service_resource_fraction:.2f} of fixed node memory/storage")
    print(
        "  load_scales compute_task={} data_task={} node_capacity={} wired_bandwidth={}".format(
            args.task_compute_scale,
            args.task_data_scale,
            args.node_compute_capacity_scale,
            args.wired_link_bandwidth_scale,
        )
    )
    print(
        "  resource_diagnostics compute_hotspot_coef={} link_hotspot_coef={} compute_imbalance_coef={} link_imbalance_coef={} idle_deployed_node_coef={}".format(
            args.compute_hotspot_coef,
            args.link_hotspot_coef,
            args.compute_imbalance_coef,
            args.link_imbalance_coef,
            args.idle_deployed_node_coef,
        )
    )
    print(
        "  slow_window_cost count_latency_coef={} served_imbalance_coef={} unused_replica_coef={} placement_idle_coef={} placement_compute_coef={} shortage_coef={} memory_coef={} storage_coef={} migration_coef={} critic_lr={} critic_epochs={}".format(
            args.slow_count_latency_coef,
            args.slow_idle_replica_coef,
            args.slow_count_unused_replica_coef,
            args.slow_placement_idle_coef,
            args.slow_placement_compute_coef,
            args.slow_count_shortage_coef,
            args.slow_deployment_memory_coef,
            args.slow_deployment_storage_coef,
            args.slow_migration_coef,
            args.slow_critic_lr,
            args.slow_critic_k_epochs,
        )
    )
    print(f"  slow_deterministic_count_mode={args.slow_deterministic_count_mode} slow_quota_decode={args.slow_quota_decode}")
    print(
        "  ppo slow_lr={} count_lr={} stage_lr={} placement_lr={} fast_lr={} slow_epochs={} stage_epochs={} placement_epochs={} slow_entropy={} slow_count_entropy={} slow_placement_entropy={}->{} hold={} decay={} fast_entropy={} slow_value_coef={}".format(
            args.slow_lr,
            args.slow_count_lr,
            args.slow_stage_lr if args.slow_stage_lr is not None else args.slow_count_lr,
            args.slow_placement_lr,
            args.fast_lr,
            args.slow_k_epochs,
            args.slow_stage_k_epochs if args.slow_stage_k_epochs is not None else args.slow_k_epochs,
            args.slow_placement_k_epochs if args.slow_placement_k_epochs is not None else args.slow_k_epochs,
            args.slow_entropy_coef,
            args.slow_count_entropy_coef if args.slow_count_entropy_coef is not None else args.slow_entropy_coef,
            args.slow_placement_entropy_coef if args.slow_placement_entropy_coef is not None else args.slow_entropy_coef,
            args.slow_placement_entropy_final_coef,
            args.slow_placement_entropy_hold_updates,
            args.slow_placement_entropy_decay_updates,
            args.fast_entropy_coef,
            args.slow_value_coef,
        )
    )
    print(f"  ppo_minibatch slow={args.slow_minibatch_size} fast={args.fast_minibatch_size}")
    print(
        f"  fast_load_balanced_updates={args.fast_load_balanced_updates} "
        f"fast_full_batch_kl_stop={args.fast_full_batch_kl_stop}"
    )
    print(
        f"  adaptive_entropy fast_target={args.fast_entropy_target} fast_max={args.fast_entropy_max_coef} "
        f"fast_rate={args.fast_entropy_adaptation_rate} placement_target={args.slow_placement_entropy_target} "
        f"fast_normalized_control={args.fast_entropy_normalized_control} "
        f"placement_max={args.slow_placement_entropy_max_coef} "
        f"placement_rate={args.slow_placement_entropy_adaptation_rate}"
    )
    print(
        f"  slow_global_advantage count_coef={args.slow_count_global_advantage_coef} "
        f"placement_coef={args.slow_placement_global_advantage_coef} "
        f"placement_attribution={args.slow_placement_global_attribution_coef} "
        f"ev_full={args.slow_global_advantage_ev_full} window_gamma={args.slow_window_gamma}"
    )
    print(
        f"  slow_critic replay={args.slow_critic_replay_windows} "
        f"decay={args.slow_critic_replay_decay} "
        f"holdout={args.slow_critic_holdout_episodes}episodes/"
        f"{args.slow_critic_holdout_windows}windows(legacy) "
        f"gradient_clip={args.slow_critic_gradient_clip} "
        "target=running_normalized_huber"
    )
    print(
        f"  slow_lr_control independent=true patience={args.slow_lr_decay_patience} "
        f"factor={args.slow_lr_decay_factor} max_reductions={args.slow_lr_max_reductions} "
        f"kl_floor_fraction={args.slow_lr_kl_floor_fraction} "
        f"count_min_lr={args.slow_count_min_lr} "
        f"placement_min_lr={args.slow_placement_min_lr}"
    )
    print(
        f"  checkpoints latest=each_update best_window={args.best_checkpoint_window} "
        f"snapshot_interval={args.checkpoint_interval} atomic=true"
    )
    print(
        f"  slow_lr_decay enabled={args.slow_lr_decay} patience={args.slow_lr_decay_patience} "
        f"factor={args.slow_lr_decay_factor} min_delta={args.slow_lr_decay_min_delta}s "
        f"min_lr={args.slow_min_lr} low_entropy_override={args.slow_lr_low_entropy_override}"
    )
    print(
        f"  ppo_target_kl count={args.slow_count_target_kl} "
        f"placement={args.slow_placement_target_kl} fast={args.fast_target_kl}"
    )
    print(f"  slow_agent=service deployment every {args.deployment_interval_minutes} minutes")
    print("  fast_agent=independent request scheduling within each one-second batch")
    if args.fast_bc_requests > 0:
        print(
            "  fast_bc samples={} loss={:.4f} accuracy={:.4f}".format(
                int(bc_metrics["bc_samples"]),
                bc_metrics["bc_loss"],
                bc_metrics["bc_accuracy"],
            )
    )
    start = datetime.now().replace(microsecond=0)
    run_name, run_dir, log_dir, save_dir = make_run_paths(args)
    log_path = log_dir / "training.csv"
    episode_log_path = log_dir / "episode_metrics.csv"
    rollout_log_path = log_dir / "rollout_metrics.csv"
    initial_path = save_dir / "initial.pt"
    if args.init_slow_checkpoint and initial_path.exists():
        raise FileExistsError(initial_path)
    if not args.append_log:
        for path in (log_path, episode_log_path, rollout_log_path):
            if path.exists():
                path.unlink()
    write_metadata(run_dir, args, bc_metrics, loaded_metadata)
    if args.init_slow_checkpoint:
        # Retain the actual pre-training model for initialization/learning
        # ablations. This does not participate in best-checkpoint selection.
        save_checkpoint(agent, initial_path, {"update":0, "completed_updates":0,
            "completed_rollouts":0, "completed_episodes":0, "args":vars(args),
            "selection_kind":"actor_initialization_only"}, training_random_streams)
    resume_update_offset = int(
        loaded_metadata.get("completed_updates", loaded_metadata.get("update", 0))
    ) if args.load_checkpoint else 0
    inferred_rollouts = resume_update_offset * int(args.fast_windows_per_update)
    resume_rollout_offset = int(
        loaded_metadata.get("completed_rollouts", inferred_rollouts)
    ) if args.load_checkpoint else 0
    windows_per_episode = max(
        int(np.ceil(args.episode_minutes / args.deployment_interval_minutes)),
        1,
    )
    resume_episode_offset = int(
        loaded_metadata.get(
            "completed_episodes",
            resume_rollout_offset // windows_per_episode,
        )
    ) if args.load_checkpoint else 0
    best_latency = float(loaded_metadata.get("best_latency_s", float("inf")))
    best_checkpoint_score = float(
        loaded_metadata.get("best_checkpoint_score", float("inf"))
    )
    best_checkpoint_ready = bool(loaded_metadata.get("best_checkpoint_ready", False))
    joint_credit_v2 = args.proposed_design in {"joint-credit-v2", "joint-credit-v3", "joint-credit-v4", "joint-credit-v5"}
    best_probe_score = float(loaded_metadata.get("best_probe_score", float("inf")))
    reference_checkpoint_compute = float(loaded_metadata.get("checkpoint_reference_compute",
        np.mean([user.service_weights for user in env.scenario.users], axis=0)
        @ np.asarray([sum(stage.compute_gcycles_mean for stage in service.stages)
                      for service in env.scenario.services]) * env.config.task_compute_scale))
    raw_selection_history = loaded_metadata.get("checkpoint_selection_history", [])
    checkpoint_selection_history: list[dict[str, float]] = []
    if isinstance(raw_selection_history, list):
        for item in raw_selection_history:
            if isinstance(item, dict):
                checkpoint_selection_history.append(
                    {
                        "latency_s": float(item.get("latency_s", np.nan)),
                        "load_multiplier": float(item.get("load_multiplier", np.nan)),
                        "compute_gcycles": float(item.get("compute_gcycles", np.nan)),
                    }
                )
    reference_checkpoint_load = checkpoint_reference_load(args)
    slow_lr_controller = SlowLearningRateController(
        independent_stage=agent.slow_agent.deployment_aware,
        enabled=args.slow_lr_decay,
        patience=args.slow_lr_decay_patience,
        factor=args.slow_lr_decay_factor,
        min_delta=args.slow_lr_decay_min_delta,
        min_lr=args.slow_min_lr,
        count_min_lr=args.slow_count_min_lr,
        placement_min_lr=args.slow_placement_min_lr,
        kl_floor_fraction=args.slow_lr_kl_floor_fraction,
        max_reductions=args.slow_lr_max_reductions,
        cooldown_updates=args.slow_lr_cooldown_updates,
        state=loaded_metadata.get("slow_lr_controller_state"),
    )
    slow_lr_floor_restored = slow_lr_controller.enforce_minimum_lrs(agent)
    if slow_lr_floor_restored:
        print(
            "  slow_lr_floor_restore "
            f"count_lr={SlowLearningRateController.optimizer_lr(agent.slow_agent.count_ppo.optimizer):.3g} "
            f"placement_lr={SlowLearningRateController.optimizer_lr(agent.slow_agent.placement_ppo.optimizer):.3g}"
        )
    target_update = resume_update_offset + args.updates

    if args.eval_baseline:
        baseline_env = build_env(args, seed_offset=20_000)
        baseline_stats = rollout_baseline(baseline_env, args.eval_requests)
        write_single_row_csv(run_dir / "evaluation" / "baseline.csv", baseline_stats)
        print(
            "baseline requests={} avg_latency={:.4f}s p95_latency={:.4f}s invalid={} violation_rate={:.4f}".format(
                int(baseline_stats["requests"]),
                baseline_stats["avg_latency_s"],
                baseline_stats["p95_latency_s"],
                int(baseline_stats["invalid_actions"]),
                baseline_stats["deadline_violation_rate"],
            )
        )

    if args.eval_before_training and args.eval_interval:
        eval_stats = evaluate_agent(
            args,
            agent,
            seed_base=30_000,
            max_requests=args.eval_requests,
            train_mode=args.train_mode,
            rollout_unit=eval_rollout_unit,
        )
        seen_eval_stats: dict[str, float] = {}
        diagnostic_stats: dict[str, float] = {}
        initial_row = {
            "update": 0,
            "training_phase": "eval",
            "episode": 0,
            "episode_start": 0,
            "episode_end": 0,
            "episodes_collected": 0,
            "demand_seed": scenario_seed_for_offset(args, 0),
            "demand_seed_end": scenario_seed_for_offset(args, 0),
            "environment_seed": int(args.seed),
            "environment_seed_end": int(args.seed),
            "load_multiplier": load_multiplier_for_rollout(args, 0),
            "load_multiplier_end": load_multiplier_for_rollout(args, 0),
            "load_group": load_group_for_rollout(args, 0),
            "load_group_end": load_group_for_rollout(args, 0),
            "load_target_probability": load_probability_for_group(
                args,
                load_group_for_rollout(args, 0),
            ),
            "load_target_probability_end": load_probability_for_group(
                args,
                load_group_for_rollout(args, 0),
            ),
            "load_multiplier_mean": np.nan,
            "load_multiplier_std": np.nan,
            "load_group_counts": "",
            "load_group_frequencies": "",
            "start_minute": rollout_start_minute(args, 0),
            "start_minute_end": rollout_start_minute(args, 0),
            "rollouts_collected": 0,
            "window_in_episode": 0,
            "requests": 0,
            "request_events": 0,
            "settlement_steps": 0,
            "logical_steps": 0,
            "temporal_sampling_fraction": np.nan,
            "simulated_hours": np.nan,
            "episode_fraction": np.nan,
            "episode_complete": 0,
            "demand_expected_compute_gcycles": np.nan,
            "demand_expected_data_mb": np.nan,
            "demand_expected_deadline_s": np.nan,
            "demand_service_popularity_entropy": np.nan,
            "avg_reward": np.nan,
            "avg_train_reward": np.nan,
            "avg_train_latency_cost_s": np.nan,
            "avg_fast_externality_cost_s": np.nan,
            "avg_fast_counterfactual_regret_s": np.nan,
            "avg_fast_kkt_reward_residual_s": np.nan,
            "max_fast_kkt_reward_residual_s": np.nan,
            "fast_oracle_samples": 0,
            "avg_fast_oracle_latency_gap_s": np.nan,
            "avg_fast_oracle_relative_gap": np.nan,
            "avg_train_resource_penalty": np.nan,
            "avg_diagnostic_resource_penalty": np.nan,
            "avg_compute_hotspot_penalty": np.nan,
            "avg_link_hotspot_penalty": np.nan,
            "avg_compute_imbalance_penalty": np.nan,
            "avg_link_imbalance_penalty": np.nan,
            "avg_idle_deployed_node_penalty": np.nan,
            "avg_latency_s": np.nan,
            "p95_latency_s": np.nan,
            "avg_compute_latency_s": np.nan,
            "avg_link_latency_s": np.nan,
            "avg_access_latency_s": np.nan,
            "avg_propagation_latency_s": np.nan,
            "avg_instantaneous_compute_work_gcycles": np.nan,
            "avg_instantaneous_compute_pressure": np.nan,
            "avg_max_instantaneous_compute_pressure": np.nan,
            "avg_p95_instantaneous_compute_pressure": np.nan,
            "avg_valid_latency_s": np.nan,
            "p95_valid_latency_s": np.nan,
            "valid_requests": 0,
            "avg_penalty_latency_s": np.nan,
            "penalty_latency_share": np.nan,
            "invalid_actions": 0,
            "invalid_action_rate": np.nan,
            "deadline_violation_rate": np.nan,
            "deployment_updates": 0,
            "avg_replicas_per_stage": np.nan,
            "min_replicas_per_stage": np.nan,
            "max_replicas_per_stage": np.nan,
            "single_replica_stage_rate": np.nan,
            "total_deployed_replicas": np.nan,
            "avg_node_compute_load": np.nan,
            "max_node_compute_load": np.nan,
            "p95_node_compute_load": np.nan,
            "std_node_compute_load": np.nan,
            "active_node_rate": np.nan,
            "hot_node_rate": np.nan,
            "avg_link_load": np.nan,
            "max_link_load": np.nan,
            "p95_link_load": np.nan,
            "std_link_load": np.nan,
            "active_link_rate": np.nan,
            "hot_link_rate": np.nan,
            "avg_node_memory_util": np.nan,
            "max_node_memory_util": np.nan,
            "avg_node_storage_util": np.nan,
            "max_node_storage_util": np.nan,
            "avg_service_memory_util": np.nan,
            "max_service_memory_util": np.nan,
            "avg_service_storage_util": np.nan,
            "max_service_storage_util": np.nan,
            "deployed_node_rate": np.nan,
            "idle_deployed_node_rate": np.nan,
            "scheduled_stage_invocations": np.nan,
            "used_replica_rate": np.nan,
            "idle_replica_rate": np.nan,
            "used_replicas_per_stage": np.nan,
            "avg_replica_use_entropy": np.nan,
            "avg_replica_use_top1_share": np.nan,
            "cross_node_stage_transition_rate": np.nan,
            "first_window_avg_latency_s": np.nan,
            "last_window_avg_latency_s": np.nan,
            "window_latency_delta_s": np.nan,
            "slow_window_return": np.nan,
            "slow_window_latency_return": np.nan,
            "slow_window_avg_latency": np.nan,
            "slow_window_p95_latency": np.nan,
            "slow_tail_latency_cost": np.nan,
            "slow_colocation_credit_coef": np.nan,
            "slow_colocation_cost": np.nan,
            "slow_cross_stage_transition_rate": np.nan,
            "slow_colocation_rate": np.nan,
            "slow_data_weighted_cross_stage_rate": np.nan,
            "slow_shared_return_credit": np.nan,
            "slow_incremental_add_actions": 0.0,
            "slow_incremental_stop_actions": 0.0,
            "slow_budget_fraction": 0.0,
            "slow_budget_feasible_capacity": 0.0,
            "slow_budget_replica_slot_upper_bound": 0.0,
            "slow_budget_extra_replicas": 0.0,
            "slow_budget_allocated_replicas": 0.0,
            "slow_budget_execution_ratio": 1.0,
            "slow_budget_available_memory_gb": 0.0,
            "slow_budget_available_storage_gb": 0.0,
            "slow_budget_target_memory_gb": 0.0,
            "slow_budget_target_storage_gb": 0.0,
            "slow_budget_used_memory_gb": 0.0,
            "slow_budget_used_storage_gb": 0.0,
            "slow_budget_memory_fill_ratio": 1.0,
            "slow_budget_storage_fill_ratio": 1.0,
            "slow_replica_ablation_samples": 0.0,
            "slow_replica_ablation_mean_s": 0.0,
            "slow_stop_ablation_value_s": 0.0,
            "slow_deployment_memory_cost": np.nan,
            "slow_deployment_storage_cost": np.nan,
            "slow_migration_cost": np.nan,
            "slow_deadline_violation_cost": np.nan,
            "slow_factorized_stage_return_mean": np.nan,
            "slow_factorized_stage_return_std": np.nan,
            "slow_factorized_count_return_mean": np.nan,
            "slow_factorized_count_return_std": np.nan,
            "slow_count_effective_replicas_per_stage": np.nan,
            "slow_count_redundant_replica_fraction": np.nan,
            "slow_count_unused_replica_fraction": np.nan,
            "slow_count_unused_replica_cost": np.nan,
            "slow_count_replica_imbalance_fraction": np.nan,
            "slow_count_replica_efficiency_cost": np.nan,
            "slow_placement_node_compute_load": np.nan,
            "slow_placement_node_compute_cost": np.nan,
            "slow_counterfactual_marginal_value": np.nan,
            "slow_counterfactual_samples": 0.0,
            "slow_stage_ablation_covered_stages": 0.0,
            "slow_stage_ablation_credit_actions": 0.0,
            "slow_stage_ablation_credit_fraction": 0.0,
            "slow_deployment_memory_fraction": np.nan,
            "slow_deployment_storage_fraction": np.nan,
            "slow_migration_fraction": np.nan,
            "slow_loss": 0.0,
            "slow_updated": 0,
            "slow_windows_available": 0,
            "slow_windows_buffered": 0,
            "checkpoint_score": np.nan,
            "checkpoint_score_load_slope": np.nan,
            "slow_count_lr": SlowLearningRateController.optimizer_lr(
                agent.slow_agent.count_ppo.optimizer
            ),
            "slow_stage_lr": (
                SlowLearningRateController.optimizer_lr(
                    agent.slow_agent.stage_ppo.optimizer
                )
                if agent.slow_agent.stage_ppo is not None
                else np.nan
            ),
            "slow_placement_lr": SlowLearningRateController.optimizer_lr(
                agent.slow_agent.placement_ppo.optimizer
            ),
            "slow_lr_bad_updates": slow_lr_controller.bad_updates,
            "slow_lr_reductions": slow_lr_controller.reductions,
            "slow_lr_decayed": 0,
            "slow_count_lr_bad_updates": slow_lr_controller.actor_metric(
                "count", "bad_updates"
            ),
            "slow_placement_lr_bad_updates": slow_lr_controller.actor_metric(
                "placement", "bad_updates"
            ),
            "slow_count_lr_reductions": slow_lr_controller.actor_metric(
                "count", "reductions"
            ),
            "slow_placement_lr_reductions": slow_lr_controller.actor_metric(
                "placement", "reductions"
            ),
            "slow_count_lr_low_kl_blocks": slow_lr_controller.actor_metric(
                "count", "low_kl_blocks"
            ),
            "slow_placement_lr_low_kl_blocks": slow_lr_controller.actor_metric(
                "placement", "low_kl_blocks"
            ),
            "slow_placement_lr_low_entropy_overrides": slow_lr_controller.actor_metric(
                "placement", "low_entropy_overrides"
            ),
            "slow_policy_loss": 0.0,
            "slow_value_loss": 0.0,
            "slow_approx_kl": 0.0,
            "slow_window_count": 0.0,
            "slow_window_return_mean": np.nan,
            "slow_window_return_std": np.nan,
            "slow_trajectory_return_mean": np.nan,
            "slow_trajectory_return_std": np.nan,
            "slow_count_return_mean": np.nan,
            "slow_count_return_std": np.nan,
            "slow_stage_return_mean": np.nan,
            "slow_stage_return_std": np.nan,
            "slow_placement_return_mean": np.nan,
            "slow_placement_return_std": np.nan,
            "slow_advantage_mean": np.nan,
            "slow_advantage_std": np.nan,
            "slow_window_advantage_mean": np.nan,
            "slow_window_advantage_std": np.nan,
            "slow_critic_explained_variance": np.nan,
            "slow_window_critic_explained_variance": np.nan,
            "slow_window_critic_value_loss": np.nan,
            "slow_window_critic_raw_value_mse": np.nan,
            "slow_window_critic_train_explained_variance": np.nan,
            "slow_window_critic_holdout_explained_variance": np.nan,
            "slow_window_critic_replay_size": 0,
            "slow_window_critic_train_size": 0,
            "slow_window_critic_holdout_size": 0,
            "slow_window_critic_train_episode_count": 0,
            "slow_window_critic_holdout_episode_count": 0,
            "slow_window_critic_return_mean": np.nan,
            "slow_window_critic_return_std": np.nan,
            "slow_global_advantage_reliability": 0.0,
            "slow_count_loss": 0.0,
            "slow_count_advantage_mean": np.nan,
            "slow_count_advantage_std": np.nan,
            "slow_count_global_advantage_mean": np.nan,
            "slow_count_global_advantage_std": np.nan,
            "slow_count_global_advantage_coef": 0.0,
            "slow_count_global_advantage_configured_coef": args.slow_count_global_advantage_coef,
            "slow_count_combined_advantage_std": np.nan,
            "slow_count_value_loss": 0.0,
            "slow_count_explained_variance": np.nan,
            "slow_count_post_explained_variance": np.nan,
            "slow_count_entropy": 0.0,
            "slow_count_approx_kl": 0.0,
            "slow_count_epochs_completed": 0.0,
            "slow_count_kl_early_stop": 0.0,
            "slow_count_optimizer_steps": 0.0,
            "slow_stage_loss": 0.0,
            "slow_stage_policy_loss": 0.0,
            "slow_stage_value_loss": 0.0,
            "slow_stage_entropy": 0.0,
            "slow_stage_approx_kl": 0.0,
            "slow_stage_epochs_completed": 0.0,
            "slow_stage_kl_early_stop": 0.0,
            "slow_stage_optimizer_steps": 0.0,
            "slow_stage_advantage_mean": np.nan,
            "slow_stage_advantage_std": np.nan,
            "slow_placement_loss": 0.0,
            "slow_placement_advantage_mean": np.nan,
            "slow_placement_advantage_std": np.nan,
            "slow_placement_global_advantage_mean": np.nan,
            "slow_placement_global_advantage_std": np.nan,
            "slow_placement_global_advantage_coef": 0.0,
            "slow_placement_global_advantage_configured_coef": args.slow_placement_global_advantage_coef,
            "slow_placement_global_attribution_coef": args.slow_placement_global_attribution_coef,
            "slow_placement_global_attribution_mean_abs": 0.0,
            "slow_placement_combined_advantage_std": np.nan,
            "slow_placement_value_loss": 0.0,
            "slow_placement_explained_variance": np.nan,
            "slow_placement_post_explained_variance": np.nan,
            "slow_placement_entropy": 0.0,
            "slow_placement_entropy_coef": args.slow_placement_entropy_coef,
            "slow_placement_entropy_next_coef": args.slow_placement_entropy_coef,
            "slow_placement_entropy_schedule_coef": args.slow_placement_entropy_coef,
            "slow_placement_entropy_target": args.slow_placement_entropy_target,
            "slow_placement_entropy_shortfall": 0.0,
            "slow_placement_entropy_saturated": 0,
            "slow_placement_updates_completed": 0,
            "slow_placement_approx_kl": 0.0,
            "slow_placement_epochs_completed": 0.0,
            "slow_placement_kl_early_stop": 0.0,
            "slow_placement_optimizer_steps": 0.0,
            "fast_loss": 0.0,
            "fast_policy_loss": 0.0,
            "fast_value_loss": 0.0,
            "fast_entropy": 0.0,
            "fast_normalized_entropy": 0.0,
            "fast_entropy_control_value": 0.0,
            "fast_entropy_normalized_control": int(
                args.fast_entropy_normalized_control
            ),
            "fast_entropy_coef": args.fast_entropy_coef,
            "fast_entropy_next_coef": args.fast_entropy_coef,
            "fast_entropy_target": args.fast_entropy_target,
            "fast_entropy_shortfall": 0.0,
            "fast_entropy_saturated": 0,
            "fast_counterfactual_credit_coef": fast_counterfactual_credit_coefficient(
                args, resume_update_offset
            ),
            "fast_approx_kl": 0.0,
            "fast_clip_fraction": 0.0,
            "fast_advantage_mean": np.nan,
            "fast_advantage_std": np.nan,
            "fast_epochs_completed": 0.0,
            "fast_kl_early_stop": 0.0,
            "fast_optimizer_steps": 0.0,
            "fast_minibatches_completed": 0.0,
            "fast_minibatches_planned": 0.0,
            "fast_samples_seen_fraction": 0.0,
            "fast_min_group_seen_fraction": 0.0,
            "fast_full_batch_kl_checks": 0.0,
            "fast_batch_credit": int(agent.fast_agent.batch_credit),
            "fast_kl_backtracks": 0.0,
            "fast_accepted_step_lr": 0.0,
            "fast_value_return_mean": agent.fast_agent.ppo.value_return_mean,
            "fast_value_return_std": agent.fast_agent.ppo.value_return_std,
            "slow_team_window_credit": int(agent.slow_agent.team_window_credit),
            "slow_stage_team_credit_fraction": 0.0,
            "fast_group_count": 0.0,
            "fast_max_group_approx_kl": 0.0,
            "fast_min_group_approx_kl": 0.0,
            "fast_group_approx_kl_std": 0.0,
            "fast_load_approx_kl": "",
            "fast_load_clip_fraction": "",
            "eval_avg_latency_s": eval_stats["eval_avg_latency_s"],
            "eval_avg_latency_std": eval_stats["eval_avg_latency_std"],
            "eval_p95_latency_s": eval_stats["eval_p95_latency_s"],
            "eval_avg_compute_latency_s": eval_stats["eval_avg_compute_latency_s"],
            "eval_avg_link_latency_s": eval_stats["eval_avg_link_latency_s"],
            "eval_avg_access_latency_s": eval_stats["eval_avg_access_latency_s"],
            "eval_avg_propagation_latency_s": eval_stats["eval_avg_propagation_latency_s"],
            "eval_avg_instantaneous_compute_work_gcycles": eval_stats["eval_avg_instantaneous_compute_work_gcycles"],
            "eval_avg_instantaneous_compute_pressure": eval_stats["eval_avg_instantaneous_compute_pressure"],
            "eval_avg_max_instantaneous_compute_pressure": eval_stats["eval_avg_max_instantaneous_compute_pressure"],
            "eval_avg_p95_instantaneous_compute_pressure": eval_stats["eval_avg_p95_instantaneous_compute_pressure"],
            "eval_avg_valid_latency_s": eval_stats["eval_avg_valid_latency_s"],
            "eval_p95_valid_latency_s": eval_stats["eval_p95_valid_latency_s"],
            "eval_avg_penalty_latency_s": eval_stats["eval_avg_penalty_latency_s"],
            "eval_penalty_latency_share": eval_stats["eval_penalty_latency_share"],
            "eval_invalid_actions": eval_stats["eval_invalid_actions"],
            "eval_invalid_action_rate": eval_stats["eval_invalid_action_rate"],
            "eval_deadline_violation_rate": eval_stats["eval_deadline_violation_rate"],
            "eval_deployment_updates": eval_stats["eval_deployment_updates"],
            "eval_request_events": eval_stats["eval_request_events"],
            "eval_settlement_steps": eval_stats["eval_settlement_steps"],
            "eval_logical_steps": eval_stats["eval_logical_steps"],
            "eval_temporal_sampling_fraction": eval_stats["eval_temporal_sampling_fraction"],
            "eval_avg_replicas_per_stage": eval_stats["eval_avg_replicas_per_stage"],
            "eval_single_replica_stage_rate": eval_stats["eval_single_replica_stage_rate"],
            "eval_total_deployed_replicas": eval_stats["eval_total_deployed_replicas"],
            "eval_avg_node_compute_load": eval_stats["eval_avg_node_compute_load"],
            "eval_max_node_compute_load": eval_stats["eval_max_node_compute_load"],
            "eval_p95_node_compute_load": eval_stats["eval_p95_node_compute_load"],
            "eval_std_node_compute_load": eval_stats["eval_std_node_compute_load"],
            "eval_active_node_rate": eval_stats["eval_active_node_rate"],
            "eval_hot_node_rate": eval_stats["eval_hot_node_rate"],
            "eval_avg_link_load": eval_stats["eval_avg_link_load"],
            "eval_max_link_load": eval_stats["eval_max_link_load"],
            "eval_p95_link_load": eval_stats["eval_p95_link_load"],
            "eval_std_link_load": eval_stats["eval_std_link_load"],
            "eval_active_link_rate": eval_stats["eval_active_link_rate"],
            "eval_hot_link_rate": eval_stats["eval_hot_link_rate"],
            "eval_avg_node_memory_util": eval_stats["eval_avg_node_memory_util"],
            "eval_max_node_memory_util": eval_stats["eval_max_node_memory_util"],
            "eval_avg_node_storage_util": eval_stats["eval_avg_node_storage_util"],
            "eval_max_node_storage_util": eval_stats["eval_max_node_storage_util"],
            "eval_deployed_node_rate": eval_stats["eval_deployed_node_rate"],
            "eval_idle_deployed_node_rate": eval_stats["eval_idle_deployed_node_rate"],
            "eval_scheduled_stage_invocations": eval_stats["eval_scheduled_stage_invocations"],
            "eval_used_replica_rate": eval_stats["eval_used_replica_rate"],
            "eval_idle_replica_rate": eval_stats["eval_idle_replica_rate"],
            "eval_used_replicas_per_stage": eval_stats["eval_used_replicas_per_stage"],
            "eval_avg_replica_use_entropy": eval_stats["eval_avg_replica_use_entropy"],
            "eval_avg_replica_use_top1_share": eval_stats["eval_avg_replica_use_top1_share"],
            "eval_cross_node_stage_transition_rate": eval_stats["eval_cross_node_stage_transition_rate"],
            "eval_first_window_avg_latency_s": eval_stats["eval_first_window_avg_latency_s"],
            "eval_last_window_avg_latency_s": eval_stats["eval_last_window_avg_latency_s"],
            "eval_window_latency_delta_s": eval_stats["eval_window_latency_delta_s"],
            **prefix_eval_stats(seen_eval_stats, "seen_eval_"),
            **diagnostic_stats,
        }
        append_log(log_path, initial_row)
        print(
            "update=000 eval_mean_latency={:.4f}s eval_std={:.4f}s eval_p95={:.4f}s invalid={:.2f}".format(
                eval_stats["eval_avg_latency_s"],
                eval_stats["eval_avg_latency_std"],
                eval_stats["eval_p95_latency_s"],
                eval_stats["eval_invalid_actions"],
            )
        )
        if args.save_best:
            best_latency = eval_stats["eval_avg_latency_s"]
            save_checkpoint(
                agent,
                save_dir / "best_eval.pt",
                {
                    "update": resume_update_offset,
                    "completed_updates": resume_update_offset,
                    "completed_rollouts": resume_rollout_offset,
                    "completed_episodes": resume_episode_offset,
                    "avg_latency_s": best_latency,
                    "avg_reward": np.nan,
                    "selection_kind": "held_out_eval",
                    "run_name": run_name,
                    "train_mode": args.train_mode,
                },
                training_random_streams,
            )

    train_env: EdgeComputingEnv | None = None
    train_episode_idx = resume_episode_offset
    training_rollout_idx = resume_rollout_offset
    episode_rollout_stats: list[dict[str, float]] = []
    episode_rollout_contexts: list[dict[str, float | int | str]] = []
    total_windows = max(
        int(np.ceil(args.episode_minutes / args.deployment_interval_minutes)),
        1,
    )
    for local_update in range(args.updates):
        update = resume_update_offset + local_update
        args.slow_colocation_current_coef = slow_colocation_credit_coefficient(
            args,
            update,
        )
        agent.slow_colocation_coef = args.slow_colocation_current_coef
        args.fast_counterfactual_credit_current_coef = (
            fast_counterfactual_credit_coefficient(args, update)
        )
        alternating_joint = args.train_mode == "joint" and args.joint_training_schedule == "alternating"
        fast_warmup_phase = alternating_joint and update < args.fast_warmup_updates
        slow_warmup_start = args.fast_warmup_updates
        slow_warmup_end = slow_warmup_start + args.slow_warmup_updates
        slow_warmup_phase = alternating_joint and slow_warmup_start <= update < slow_warmup_end
        alternating_update = update - slow_warmup_end
        scheduled_slow_phase = (
            alternating_joint
            and alternating_update >= 0
            and alternating_update % (args.fast_updates_per_cycle + 1) == args.fast_updates_per_cycle
        )
        slow_phase = slow_warmup_phase or scheduled_slow_phase
        training_phase = (
            "fast_warmup"
            if fast_warmup_phase
            else "slow_warmup"
            if slow_warmup_phase
            else "slow"
            if slow_phase
            else "fast"
            if alternating_joint
            else "joint"
        )
        windows_this_update = args.slow_windows_per_update if slow_phase else args.fast_windows_per_update
        record_fast_phase = not slow_phase
        record_slow_phase = args.train_mode == "joint" and (slow_phase or not alternating_joint)
        deterministic_fast_phase = use_deterministic_fast_collection(
            slow_phase,
            args.slow_fast_collection_mode,
        )
        deterministic_slow_phase = bool(alternating_joint and not slow_phase)
        rollout_stats: list[dict[str, float]] = []
        demand_seeds: list[int] = []
        environment_seeds: list[int] = []
        load_multipliers: list[float] = []
        load_groups: list[int] = []
        load_target_probabilities: list[float] = []
        start_minutes: list[float] = []
        episode_numbers: list[int] = []
        window_numbers: list[int] = []
        update_load_assignments = load_assignments_for_update(
            args,
            update,
            windows_this_update,
            rollout_start_idx=training_rollout_idx,
            rng=training_random_streams.load_rng,
        )
        for rollout_in_update in range(windows_this_update):
            rollout_idx = training_rollout_idx
            training_rollout_idx += 1
            start_minute = rollout_start_minute(args, rollout_idx)
            load_multiplier, load_group = update_load_assignments[rollout_in_update]
            load_target_probability = load_probability_for_group(args, load_group)
            batch_suffix = (
                ""
                if windows_this_update <= 1
                else f" rollout={rollout_in_update + 1:02d}/{windows_this_update:02d}"
            )
            if args.rollout_unit == "window":
                if args.demand_sampling_mode == "rollout":
                    stream_demand_seed = (
                        training_random_streams.next_demand_seed()
                        if args.demand_scenario_schedule == "stream"
                        else None
                    )
                    stream_environment_seed = (
                        training_random_streams.next_environment_seed()
                        if args.demand_scenario_schedule == "stream"
                        else None
                    )
                    train_env = build_training_env(
                        args,
                        rollout_idx=rollout_idx,
                        episode_idx=rollout_idx,
                        load_multiplier=load_multiplier,
                        load_group=load_group,
                        demand_seed=stream_demand_seed,
                        environment_seed=stream_environment_seed,
                    )
                    train_env.reset()
                    start_env_at_minute(train_env, start_minute)
                    episode_number = rollout_idx + 1
                else:
                    if train_env is None or train_env.done:
                        stream_demand_seed = (
                            training_random_streams.demand_seed_for_episode(
                                train_episode_idx,
                                args.scenario_refresh_episodes,
                            )
                            if args.demand_scenario_schedule == "stream"
                            else None
                        )
                        stream_environment_seed = (
                            training_random_streams.next_environment_seed()
                            if args.demand_scenario_schedule == "stream"
                            else None
                        )
                        train_env = build_training_env(
                            args,
                            rollout_idx=rollout_idx,
                            episode_idx=train_episode_idx,
                            load_multiplier=load_multiplier,
                            load_group=load_group,
                            demand_seed=stream_demand_seed,
                            environment_seed=stream_environment_seed,
                        )
                        train_env.reset()
                    episode_number = train_episode_idx + 1
                env = train_env
                if args.demand_sampling_mode == "episode":
                    # Keep the fixed physical scenario and user preferences, while
                    # cycling demand intensity at each window boundary. This makes
                    # a synchronized four-window block expose distinct load cases.
                    previous_multiplier = float(env.config.demand_load_multiplier)
                    env.config.demand_load_multiplier = float(load_multiplier)
                    env.config.demand_load_group = int(load_group)
                    if not np.isclose(previous_multiplier, load_multiplier):
                        env.current_requests = env._generate_current_second_requests()
                        env.current_request = env.current_requests[0] if env.current_requests else None
                window_in_episode = min(int(env.current_time_minute // env.config.deployment_interval_minutes) + 1, total_windows)
                demand_seed = int(env.config.scenario_seed)
                progress_label = (
                    f"update={update + 1:03d}/{target_update:03d}{batch_suffix} "
                    f"ep={episode_number:03d} win={window_in_episode:02d}/{total_windows:02d}"
                )
                one_stats = rollout(
                    env,
                    agent,
                    args.requests_per_update,
                    args=args,
                    reward_scale=args.reward_scale,
                    train_mode=args.train_mode,
                    progress_label=progress_label,
                    progress_interval_seconds=args.progress_interval_seconds,
                    rollout_unit=args.rollout_unit,
                    reset_env=False,
                    record_fast=record_fast_phase,
                    record_slow=record_slow_phase,
                    deterministic_fast=deterministic_fast_phase,
                    deterministic_slow=deterministic_slow_phase,
                )
                if args.rollout_unit == "window" and one_stats["episode_complete"]:
                    train_episode_idx += 1
            else:
                stream_demand_seed = (
                    training_random_streams.next_demand_seed()
                    if args.demand_scenario_schedule == "stream"
                    else None
                )
                stream_environment_seed = (
                    training_random_streams.next_environment_seed()
                    if args.demand_scenario_schedule == "stream"
                    else None
                )
                env = build_training_env(
                    args,
                    rollout_idx=rollout_idx,
                    episode_idx=rollout_idx,
                    load_multiplier=load_multiplier,
                    load_group=load_group,
                    demand_seed=stream_demand_seed,
                    environment_seed=stream_environment_seed,
                )
                episode_number = rollout_idx + 1
                demand_seed = int(env.config.scenario_seed)
                one_stats = rollout(
                    env,
                    agent,
                    args.requests_per_update,
                    args=args,
                    reward_scale=args.reward_scale,
                    train_mode=args.train_mode,
                    progress_label=f"update={update + 1:03d}/{target_update:03d}{batch_suffix}",
                    progress_interval_seconds=args.progress_interval_seconds,
                    rollout_unit=args.rollout_unit,
                    record_fast=record_fast_phase,
                    record_slow=record_slow_phase,
                    deterministic_fast=deterministic_fast_phase,
                    deterministic_slow=deterministic_slow_phase,
                )
                window_in_episode = int(one_stats["deployment_updates"])
            rollout_stats.append(one_stats)
            demand_seeds.append(demand_seed)
            environment_seeds.append(int(env.config.seed))
            load_multipliers.append(load_multiplier)
            load_groups.append(load_group)
            load_target_probabilities.append(load_target_probability)
            start_minutes.append(start_minute)
            episode_numbers.append(episode_number)
            window_numbers.append(window_in_episode)
            episode_context = {
                "episode": episode_number,
                "update": update + 1,
                "training_phase": training_phase,
                "demand_seed": demand_seed,
                "environment_seed": int(env.config.seed),
                "load_multiplier": load_multiplier,
                "load_group": load_group,
                "load_target_probability": load_target_probability,
                "start_minute": start_minute,
                "rollout": rollout_idx + 1,
                "window": window_in_episode,
            }
            append_log(
                rollout_log_path,
                build_rollout_metrics_row(one_stats, episode_context, rollout_in_update + 1),
            )
            if agent.slow_agent.deployment_aware:
                append_log(run_dir / "logs" / "slow_deployment_metrics.csv", {
                    **episode_context, "context_version": args.slow_deployment_context,
                    "budget_fraction": one_stats.get("slow_budget_fraction", 0.0),
                    "allocation_mode":agent.slow_agent.allocation_mode,
                    "quota_json":json.dumps(agent.slow_agent.last_stage_budget_diagnostics, separators=(",", ":")),
                    "stages_json": json.dumps(agent.slow_agent.last_deployment_diagnostics, separators=(",", ":")),
                })
            if (
                episode_rollout_contexts
                and int(episode_rollout_contexts[-1]["episode"]) != episode_number
            ):
                append_log(
                    episode_log_path,
                    build_episode_metrics_row(episode_rollout_stats, episode_rollout_contexts),
                )
                episode_rollout_stats.clear()
                episode_rollout_contexts.clear()
            episode_rollout_stats.append(one_stats)
            episode_rollout_contexts.append(episode_context)
            continues_same_episode = (
                args.rollout_unit == "window" and args.demand_sampling_mode == "episode"
            )
            if one_stats["episode_complete"] or not continues_same_episode:
                append_log(
                    episode_log_path,
                    build_episode_metrics_row(episode_rollout_stats, episode_rollout_contexts),
                )
                episode_rollout_stats.clear()
                episode_rollout_contexts.clear()

        stats = aggregate_rollout_stats(rollout_stats)
        episode_start_number = episode_numbers[0]
        episode_number = episode_numbers[-1]
        episodes_collected = len(set(episode_numbers))
        window_in_episode = window_numbers[-1]
        demand_seed = demand_seeds[0]
        demand_seed_end = demand_seeds[-1]
        environment_seed = environment_seeds[0]
        environment_seed_end = environment_seeds[-1]
        load_multiplier = load_multipliers[0]
        load_multiplier_end = load_multipliers[-1]
        load_group = load_groups[0]
        load_group_end = load_groups[-1]
        load_target_probability = load_target_probabilities[0]
        load_target_probability_end = load_target_probabilities[-1]
        load_multiplier_mean = float(np.mean(load_multipliers))
        load_multiplier_std = float(np.std(load_multipliers))
        load_group_counts = {
            group_id: load_groups.count(group_id)
            for group_id in sorted(set(load_groups))
        }
        load_group_count_text = ";".join(
            f"{group_id}={count}"
            for group_id, count in load_group_counts.items()
        )
        load_group_frequency_text = ";".join(
            f"{group_id}={count / len(load_groups):.8g}"
            for group_id, count in load_group_counts.items()
        )
        start_minute = start_minutes[0]
        start_minute_end = start_minutes[-1]
        fast_metrics = agent.update_fast(
            progress_label=f"update={update + 1:03d}/{target_update:03d} fast PPO",
            progress_interval_seconds=args.progress_interval_seconds,
        )
        slow_updated = False
        slow_windows_available = agent.completed_slow_windows
        if args.train_mode == "fast-only":
            slow_metrics = agent.slow_agent.empty_update_metrics()
            agent.slow_agent.count_ppo.buffer.clear()
            if agent.slow_agent.stage_ppo is not None:
                agent.slow_agent.stage_ppo.buffer.clear()
            agent.slow_agent.placement_ppo.buffer.clear()
            agent.window_reward = 0.0
            agent.window_steps = 0
        elif record_slow_phase and slow_windows_available >= args.slow_windows_per_update:
            slow_metrics = agent.update_slow(
                progress_label=f"update={update + 1:03d}/{target_update:03d} slow PPO",
                progress_interval_seconds=args.progress_interval_seconds,
            )
            slow_updated = True
        else:
            slow_metrics = agent.slow_agent.empty_update_metrics()
        losses = {"slow": slow_metrics, "fast": fast_metrics}
        if agent.slow_agent.deployment_aware and slow_updated:
            # An explicitly upgraded resume may append to an old run. Do not
            # silently append wider rows under the old CSV header.
            diagnostic_file = ("slow_update_metrics_prefix_structured_v3.csv" if agent.slow_agent.learning_repair == "prefix-structured-v3" else
                               "slow_update_metrics_prefix_credit_v2.csv" if agent.slow_agent.learning_repair == "prefix-credit-v2" else
                               "slow_update_metrics_conditional_replay_v1.csv"
                               if agent.slow_agent.learning_repair != "none" else "slow_update_metrics.csv")
            append_log(run_dir / "logs" / diagnostic_file, {
                "update": update + 1, "context_version": args.slow_deployment_context,
                **agent.slow_agent.last_update_diagnostics,
            })
        slow_windows_buffered = agent.completed_slow_windows
        checkpoint_selection_history.append(
            {
                "latency_s": float(stats["avg_latency_s"]),
                "load_multiplier": float(load_multiplier_mean),
                "compute_gcycles": float(stats["demand_expected_compute_gcycles"]),
            }
        )
        if joint_credit_v2:
            checkpoint_selection_history = checkpoint_selection_history[-max(80, args.best_checkpoint_window):]
            from edge_drl.checkpoint_selection import recent_workload_score
            checkpoint_score, checkpoint_load_slope = recent_workload_score(
                checkpoint_selection_history, args.best_checkpoint_window,
                reference_checkpoint_load, reference_checkpoint_compute)
        else:
            checkpoint_score, checkpoint_load_slope = load_adjusted_rolling_latency(
                checkpoint_selection_history,
                args.best_checkpoint_window,
                reference_checkpoint_load,
            )
        probe_result = None
        if joint_credit_v2 and ((update+1) == 1 or (update+1) % args.checkpoint_probe_interval == 0
                                or (update+1) == target_update):
            from edge_drl.checkpoint_selection import checkpoint_probe
            probe_result = checkpoint_probe(agent, env.config, seed=args.seed,
                samples=args.sampled_seconds_per_window, hold_cap=args.sampling_max_interval_seconds)
            append_log(run_dir / "logs" / "checkpoint_probe_metrics.csv", {"update":update+1, **probe_result})
            print(f"  checkpoint_probe update={update+1} latency={1000*probe_result['mean_latency_s']:.2f}ms "
                  f"minutes={probe_result['minutes']} steps={probe_result['sampled_steps']}", flush=True)
        checkpoint_ready = len(checkpoint_selection_history) >= args.best_checkpoint_window
        slow_lr_decayed = slow_lr_controller.observe(
            checkpoint_score,
            ready=checkpoint_ready,
            slow_updated=slow_updated,
            agent=agent,
            count_approx_kl=slow_metrics.get("count_approx_kl"),
            stage_approx_kl=slow_metrics.get("stage_approx_kl"),
            placement_approx_kl=slow_metrics.get("placement_approx_kl"),
            count_target_kl=args.slow_count_target_kl,
            placement_target_kl=args.slow_placement_target_kl,
            placement_entropy=slow_metrics.get("placement_entropy"),
            placement_entropy_target=args.slow_placement_entropy_target,
            low_entropy_override=args.slow_lr_low_entropy_override,
        )
        slow_count_lr = SlowLearningRateController.optimizer_lr(
            agent.slow_agent.count_ppo.optimizer
        )
        slow_stage_lr = (
            SlowLearningRateController.optimizer_lr(
                agent.slow_agent.stage_ppo.optimizer
            )
            if agent.slow_agent.stage_ppo is not None
            else np.nan
        )
        slow_placement_lr = SlowLearningRateController.optimizer_lr(
            agent.slow_agent.placement_ppo.optimizer
        )
        if slow_lr_decayed:
            print(
                f"  slow_lr_decay score={checkpoint_score:.6f}s "
                f"count_lr={slow_count_lr:.3g} placement_lr={slow_placement_lr:.3g}"
            )

        eval_stats = {}
        seen_eval_stats = {}
        if args.eval_interval and (update + 1) % args.eval_interval == 0:
            eval_stats = evaluate_agent(
                args,
                agent,
                seed_base=30_000,
                max_requests=args.eval_requests,
                train_mode=args.train_mode,
                rollout_unit=eval_rollout_unit,
            )
        diagnostic_stats = {}
        fast_group_diagnostics = agent.fast_agent.ppo.last_group_diagnostics
        log_row = {
            "update": update + 1,
            "training_phase": training_phase,
            "episode": episode_number,
            "episode_start": episode_start_number,
            "episode_end": episode_number,
            "episodes_collected": episodes_collected,
            "demand_seed": demand_seed,
            "demand_seed_end": demand_seed_end,
            "environment_seed": environment_seed,
            "environment_seed_end": environment_seed_end,
            "load_multiplier": load_multiplier,
            "load_multiplier_end": load_multiplier_end,
            "load_group": load_group,
            "load_group_end": load_group_end,
            "load_target_probability": load_target_probability,
            "load_target_probability_end": load_target_probability_end,
            "load_multiplier_mean": load_multiplier_mean,
            "load_multiplier_std": load_multiplier_std,
            "load_group_counts": load_group_count_text,
            "load_group_frequencies": load_group_frequency_text,
            "start_minute": start_minute,
            "start_minute_end": start_minute_end,
            "rollouts_collected": len(rollout_stats),
            "window_in_episode": window_in_episode,
            "requests": int(stats["requests"]),
            "request_events": int(stats["request_events"]),
            "sampled_request_events": int(stats.get("sampled_request_events", 0.)),
            "settlement_steps": int(stats["settlement_steps"]),
            "logical_steps": int(round(stats["logical_steps"])),
            "temporal_sampling_fraction": stats["temporal_sampling_fraction"],
            "simulated_hours": stats["simulated_hours"],
            "episode_fraction": stats["episode_fraction"],
            "episode_complete": int(stats["episode_complete"]),
            "demand_expected_compute_gcycles": stats["demand_expected_compute_gcycles"],
            "demand_expected_data_mb": stats["demand_expected_data_mb"],
            "demand_expected_deadline_s": stats["demand_expected_deadline_s"],
            "demand_service_popularity_entropy": stats["demand_service_popularity_entropy"],
            "avg_reward": stats["avg_reward"],
            "avg_train_reward": stats["avg_train_reward"],
            "avg_train_latency_cost_s": stats["avg_train_latency_cost_s"],
            "avg_fast_externality_cost_s": stats["avg_fast_externality_cost_s"],
            "avg_fast_counterfactual_regret_s": stats[
                "avg_fast_counterfactual_regret_s"
            ],
            "avg_fast_kkt_reward_residual_s": stats[
                "avg_fast_kkt_reward_residual_s"
            ],
            "max_fast_kkt_reward_residual_s": stats[
                "max_fast_kkt_reward_residual_s"
            ],
            "fast_oracle_samples": int(stats["fast_oracle_samples"]),
            "avg_fast_oracle_latency_gap_s": stats[
                "avg_fast_oracle_latency_gap_s"
            ],
            "avg_fast_oracle_relative_gap": stats[
                "avg_fast_oracle_relative_gap"
            ],
            "avg_train_resource_penalty": stats["avg_train_resource_penalty"],
            "avg_diagnostic_resource_penalty": stats["avg_diagnostic_resource_penalty"],
            "avg_compute_hotspot_penalty": stats["avg_compute_hotspot_penalty"],
            "avg_link_hotspot_penalty": stats["avg_link_hotspot_penalty"],
            "avg_compute_imbalance_penalty": stats["avg_compute_imbalance_penalty"],
            "avg_link_imbalance_penalty": stats["avg_link_imbalance_penalty"],
            "avg_idle_deployed_node_penalty": stats["avg_idle_deployed_node_penalty"],
            "avg_latency_s": stats["avg_latency_s"],
            "p95_latency_s": stats["p95_latency_s"],
            "avg_compute_latency_s": stats["avg_compute_latency_s"],
            "avg_link_latency_s": stats["avg_link_latency_s"],
            "avg_access_latency_s": stats["avg_access_latency_s"],
            "avg_propagation_latency_s": stats["avg_propagation_latency_s"],
            "avg_instantaneous_compute_work_gcycles": stats["avg_instantaneous_compute_work_gcycles"],
            "avg_instantaneous_compute_pressure": stats["avg_instantaneous_compute_pressure"],
            "avg_max_instantaneous_compute_pressure": stats["avg_max_instantaneous_compute_pressure"],
            "avg_p95_instantaneous_compute_pressure": stats["avg_p95_instantaneous_compute_pressure"],
            "avg_valid_latency_s": stats["avg_valid_latency_s"],
            "p95_valid_latency_s": stats["p95_valid_latency_s"],
            "valid_requests": int(stats["valid_requests"]),
            "avg_penalty_latency_s": stats["avg_penalty_latency_s"],
            "penalty_latency_share": stats["penalty_latency_share"],
            "invalid_actions": int(stats["invalid_actions"]),
            "invalid_action_rate": stats["invalid_action_rate"],
            "deadline_violation_rate": stats["deadline_violation_rate"],
            "deployment_updates": int(stats["deployment_updates"]),
            "avg_replicas_per_stage": stats["avg_replicas_per_stage"],
            "min_replicas_per_stage": stats["min_replicas_per_stage"],
            "max_replicas_per_stage": stats["max_replicas_per_stage"],
            "single_replica_stage_rate": stats["single_replica_stage_rate"],
            "total_deployed_replicas": stats["total_deployed_replicas"],
            "avg_node_compute_load": stats["avg_node_compute_load"],
            "max_node_compute_load": stats["max_node_compute_load"],
            "p95_node_compute_load": stats["p95_node_compute_load"],
            "std_node_compute_load": stats["std_node_compute_load"],
            "active_node_rate": stats["active_node_rate"],
            "hot_node_rate": stats["hot_node_rate"],
            "avg_link_load": stats["avg_link_load"],
            "max_link_load": stats["max_link_load"],
            "p95_link_load": stats["p95_link_load"],
            "std_link_load": stats["std_link_load"],
            "active_link_rate": stats["active_link_rate"],
            "hot_link_rate": stats["hot_link_rate"],
            "avg_node_memory_util": stats["avg_node_memory_util"],
            "max_node_memory_util": stats["max_node_memory_util"],
            "avg_node_storage_util": stats["avg_node_storage_util"],
            "max_node_storage_util": stats["max_node_storage_util"],
            "avg_service_memory_util": stats["avg_service_memory_util"],
            "max_service_memory_util": stats["max_service_memory_util"],
            "avg_service_storage_util": stats["avg_service_storage_util"],
            "max_service_storage_util": stats["max_service_storage_util"],
            "deployed_node_rate": stats["deployed_node_rate"],
            "idle_deployed_node_rate": stats["idle_deployed_node_rate"],
            "scheduled_stage_invocations": stats["scheduled_stage_invocations"],
            "used_replica_rate": stats["used_replica_rate"],
            "idle_replica_rate": stats["idle_replica_rate"],
            "used_replicas_per_stage": stats["used_replicas_per_stage"],
            "avg_replica_use_entropy": stats["avg_replica_use_entropy"],
            "avg_replica_use_top1_share": stats["avg_replica_use_top1_share"],
            "cross_node_stage_transition_rate": stats["cross_node_stage_transition_rate"],
            "first_window_avg_latency_s": stats["first_window_avg_latency_s"],
            "last_window_avg_latency_s": stats["last_window_avg_latency_s"],
            "window_latency_delta_s": stats["window_latency_delta_s"],
            "slow_window_return": stats["slow_window_return"],
            "slow_window_latency_return": stats["slow_window_latency_return"],
            "slow_window_avg_latency": stats["slow_window_avg_latency"],
            "slow_window_p95_latency": stats["slow_window_p95_latency"],
            "slow_tail_latency_cost": stats["slow_tail_latency_cost"],
            "slow_colocation_credit_coef": stats["slow_colocation_credit_coef"],
            "slow_colocation_cost": stats["slow_colocation_cost"],
            "slow_cross_stage_transition_rate": stats["slow_cross_stage_transition_rate"],
            "slow_colocation_rate": stats["slow_colocation_rate"],
            "slow_data_weighted_cross_stage_rate": stats[
                "slow_data_weighted_cross_stage_rate"
            ],
            "slow_shared_return_credit": stats["slow_shared_return_credit"],
            "slow_incremental_add_actions": stats["slow_incremental_add_actions"],
            "slow_incremental_stop_actions": stats["slow_incremental_stop_actions"],
            "slow_budget_fraction": stats["slow_budget_fraction"],
            "slow_budget_feasible_capacity": stats[
                "slow_budget_feasible_capacity"
            ],
            "slow_budget_replica_slot_upper_bound": stats[
                "slow_budget_replica_slot_upper_bound"
            ],
            "slow_budget_extra_replicas": stats["slow_budget_extra_replicas"],
            "slow_budget_allocated_replicas": stats[
                "slow_budget_allocated_replicas"
            ],
            "slow_budget_execution_ratio": stats["slow_budget_execution_ratio"],
            "slow_budget_available_memory_gb": stats[
                "slow_budget_available_memory_gb"
            ],
            "slow_budget_available_storage_gb": stats[
                "slow_budget_available_storage_gb"
            ],
            "slow_budget_target_memory_gb": stats["slow_budget_target_memory_gb"],
            "slow_budget_target_storage_gb": stats[
                "slow_budget_target_storage_gb"
            ],
            "slow_budget_used_memory_gb": stats["slow_budget_used_memory_gb"],
            "slow_budget_used_storage_gb": stats["slow_budget_used_storage_gb"],
            "slow_budget_memory_fill_ratio": stats[
                "slow_budget_memory_fill_ratio"
            ],
            "slow_budget_storage_fill_ratio": stats[
                "slow_budget_storage_fill_ratio"
            ],
            "slow_replica_ablation_samples": stats["slow_replica_ablation_samples"],
            "slow_replica_ablation_mean_s": stats["slow_replica_ablation_mean_s"],
            "slow_stop_ablation_value_s": stats["slow_stop_ablation_value_s"],
            "slow_deployment_memory_cost": stats["slow_deployment_memory_cost"],
            "slow_deployment_storage_cost": stats["slow_deployment_storage_cost"],
            "slow_migration_cost": stats["slow_migration_cost"],
            "slow_deadline_violation_cost": stats["slow_deadline_violation_cost"],
            "slow_factorized_stage_return_mean": stats["slow_factorized_stage_return_mean"],
            "slow_factorized_stage_return_std": stats["slow_factorized_stage_return_std"],
            "slow_factorized_count_return_mean": stats["slow_factorized_count_return_mean"],
            "slow_factorized_count_return_std": stats["slow_factorized_count_return_std"],
            "slow_count_effective_replicas_per_stage": stats["slow_count_effective_replicas_per_stage"],
            "slow_count_redundant_replica_fraction": stats["slow_count_redundant_replica_fraction"],
            "slow_count_unused_replica_fraction": stats[
                "slow_count_unused_replica_fraction"
            ],
            "slow_count_unused_replica_cost": stats[
                "slow_count_unused_replica_cost"
            ],
            "slow_count_replica_imbalance_fraction": stats[
                "slow_count_replica_imbalance_fraction"
            ],
            "slow_count_replica_efficiency_cost": stats[
                "slow_count_replica_efficiency_cost"
            ],
            "slow_placement_node_compute_load": stats["slow_placement_node_compute_load"],
            "slow_placement_node_compute_cost": stats["slow_placement_node_compute_cost"],
            "slow_counterfactual_marginal_value": stats[
                "slow_counterfactual_marginal_value"
            ],
            "slow_counterfactual_samples": stats["slow_counterfactual_samples"],
            "slow_stage_ablation_covered_stages": stats[
                "slow_stage_ablation_covered_stages"
            ],
            "slow_stage_ablation_credit_actions": stats[
                "slow_stage_ablation_credit_actions"
            ],
            "slow_stage_ablation_credit_fraction": stats[
                "slow_stage_ablation_credit_fraction"
            ],
            "slow_deployment_memory_fraction": stats["slow_deployment_memory_fraction"],
            "slow_deployment_storage_fraction": stats["slow_deployment_storage_fraction"],
            "slow_migration_fraction": stats["slow_migration_fraction"],
            "slow_loss": losses["slow"]["loss"],
            "slow_updated": int(slow_updated),
            "slow_windows_available": int(slow_windows_available),
            "slow_windows_buffered": int(slow_windows_buffered),
            "checkpoint_score": checkpoint_score,
            "checkpoint_score_load_slope": checkpoint_load_slope,
            "checkpoint_probe_latency_s": probe_result["mean_latency_s"] if probe_result else float("nan"),
            "checkpoint_probe_best_latency_s": min(best_probe_score, probe_result["mean_latency_s"]) if probe_result else best_probe_score,
            "slow_count_lr": slow_count_lr,
            "slow_stage_lr": slow_stage_lr,
            "slow_placement_lr": slow_placement_lr,
            "slow_lr_bad_updates": slow_lr_controller.bad_updates,
            "slow_lr_reductions": slow_lr_controller.reductions,
            "slow_lr_decayed": int(slow_lr_decayed),
            "slow_count_lr_bad_updates": slow_lr_controller.actor_metric(
                "count", "bad_updates"
            ),
            "slow_placement_lr_bad_updates": slow_lr_controller.actor_metric(
                "placement", "bad_updates"
            ),
            "slow_count_lr_reductions": slow_lr_controller.actor_metric(
                "count", "reductions"
            ),
            "slow_placement_lr_reductions": slow_lr_controller.actor_metric(
                "placement", "reductions"
            ),
            "slow_count_lr_low_kl_blocks": slow_lr_controller.actor_metric(
                "count", "low_kl_blocks"
            ),
            "slow_placement_lr_low_kl_blocks": slow_lr_controller.actor_metric(
                "placement", "low_kl_blocks"
            ),
            "slow_placement_lr_low_entropy_overrides": slow_lr_controller.actor_metric(
                "placement", "low_entropy_overrides"
            ),
            "slow_policy_loss": losses["slow"]["policy_loss"],
            "slow_value_loss": losses["slow"]["value_loss"],
            "slow_approx_kl": losses["slow"].get("approx_kl", 0.0),
            "slow_window_count": losses["slow"].get("window_count", 0.0),
            "slow_window_return_mean": losses["slow"].get("window_return_mean", np.nan),
            "slow_window_return_std": losses["slow"].get("window_return_std", np.nan),
            "slow_trajectory_return_mean": losses["slow"].get("trajectory_return_mean", np.nan),
            "slow_trajectory_return_std": losses["slow"].get("trajectory_return_std", np.nan),
            "slow_count_return_mean": losses["slow"].get("count_return_mean", np.nan),
            "slow_count_return_std": losses["slow"].get("count_return_std", np.nan),
            "slow_stage_return_mean": losses["slow"].get("stage_return_mean", np.nan),
            "slow_stage_return_std": losses["slow"].get("stage_return_std", np.nan),
            "slow_placement_return_mean": losses["slow"].get("placement_return_mean", np.nan),
            "slow_placement_return_std": losses["slow"].get("placement_return_std", np.nan),
            "slow_advantage_mean": losses["slow"].get("advantage_mean", np.nan),
            "slow_advantage_std": losses["slow"].get("advantage_std", np.nan),
            "slow_window_advantage_mean": losses["slow"].get("window_advantage_mean", np.nan),
            "slow_window_advantage_std": losses["slow"].get("window_advantage_std", np.nan),
            "slow_critic_explained_variance": losses["slow"].get("critic_explained_variance", np.nan),
            "slow_window_critic_explained_variance": losses["slow"].get(
                "window_critic_explained_variance", np.nan
            ),
            "slow_window_critic_value_loss": losses["slow"].get(
                "window_critic_value_loss", np.nan
            ),
            "slow_window_critic_raw_value_mse": losses["slow"].get(
                "window_critic_raw_value_mse", np.nan
            ),
            "slow_window_critic_train_explained_variance": losses["slow"].get(
                "window_critic_train_explained_variance", np.nan
            ),
            "slow_window_critic_holdout_explained_variance": losses["slow"].get(
                "window_critic_holdout_explained_variance", np.nan
            ),
            "slow_window_critic_replay_size": losses["slow"].get(
                "window_critic_replay_size", 0.0
            ),
            "slow_window_critic_train_size": losses["slow"].get(
                "window_critic_train_size", 0.0
            ),
            "slow_window_critic_holdout_size": losses["slow"].get(
                "window_critic_holdout_size", 0.0
            ),
            "slow_window_critic_train_episode_count": losses["slow"].get(
                "window_critic_train_episode_count", 0.0
            ),
            "slow_window_critic_holdout_episode_count": losses["slow"].get(
                "window_critic_holdout_episode_count", 0.0
            ),
            "slow_window_critic_return_mean": losses["slow"].get(
                "window_critic_return_mean", np.nan
            ),
            "slow_window_critic_return_std": losses["slow"].get(
                "window_critic_return_std", np.nan
            ),
            "slow_global_advantage_reliability": losses["slow"].get(
                "global_advantage_reliability", 0.0
            ),
            "slow_count_loss": losses["slow"].get("count_loss", np.nan),
            "slow_count_advantage_mean": losses["slow"].get("count_advantage_mean", np.nan),
            "slow_count_advantage_std": losses["slow"].get("count_advantage_std", np.nan),
            "slow_count_global_advantage_mean": losses["slow"].get(
                "count_global_advantage_mean", np.nan
            ),
            "slow_count_global_advantage_std": losses["slow"].get(
                "count_global_advantage_std", np.nan
            ),
            "slow_count_global_advantage_coef": losses["slow"].get(
                "count_global_advantage_coef", 0.0
            ),
            "slow_count_global_advantage_configured_coef": losses["slow"].get(
                "count_global_advantage_configured_coef",
                args.slow_count_global_advantage_coef,
            ),
            "slow_count_combined_advantage_std": losses["slow"].get(
                "count_combined_advantage_std", np.nan
            ),
            "slow_count_value_loss": losses["slow"].get("count_value_loss", np.nan),
            "slow_count_explained_variance": losses["slow"].get("count_explained_variance", np.nan),
            "slow_count_post_explained_variance": losses["slow"].get(
                "count_post_explained_variance", np.nan
            ),
            "slow_count_entropy": losses["slow"].get("count_entropy", np.nan),
            "slow_count_approx_kl": losses["slow"].get("count_approx_kl", np.nan),
            "slow_count_epochs_completed": losses["slow"].get(
                "count_epochs_completed", 0.0
            ),
            "slow_count_kl_early_stop": losses["slow"].get(
                "count_kl_early_stop", 0.0
            ),
            "slow_count_optimizer_steps": losses["slow"].get(
                "count_optimizer_steps", 0.0
            ),
            "slow_stage_loss": losses["slow"].get("stage_loss", np.nan),
            "slow_stage_policy_loss": losses["slow"].get(
                "stage_policy_loss", np.nan
            ),
            "slow_stage_value_loss": losses["slow"].get(
                "stage_value_loss", np.nan
            ),
            "slow_stage_entropy": losses["slow"].get("stage_entropy", np.nan),
            "slow_stage_approx_kl": losses["slow"].get(
                "stage_approx_kl", np.nan
            ),
            "slow_stage_epochs_completed": losses["slow"].get(
                "stage_epochs_completed", 0.0
            ),
            "slow_stage_kl_early_stop": losses["slow"].get(
                "stage_kl_early_stop", 0.0
            ),
            "slow_stage_optimizer_steps": losses["slow"].get(
                "stage_optimizer_steps", 0.0
            ),
            "slow_stage_advantage_mean": losses["slow"].get(
                "stage_advantage_mean", np.nan
            ),
            "slow_stage_advantage_std": losses["slow"].get(
                "stage_advantage_std", np.nan
            ),
            "slow_placement_loss": losses["slow"].get("placement_loss", np.nan),
            "slow_placement_advantage_mean": losses["slow"].get(
                "placement_advantage_mean", np.nan
            ),
            "slow_placement_advantage_std": losses["slow"].get(
                "placement_advantage_std", np.nan
            ),
            "slow_placement_global_advantage_mean": losses["slow"].get(
                "placement_global_advantage_mean", np.nan
            ),
            "slow_placement_global_advantage_std": losses["slow"].get(
                "placement_global_advantage_std", np.nan
            ),
            "slow_placement_global_advantage_coef": losses["slow"].get(
                "placement_global_advantage_coef", 0.0
            ),
            "slow_placement_global_advantage_configured_coef": losses["slow"].get(
                "placement_global_advantage_configured_coef",
                args.slow_placement_global_advantage_coef,
            ),
            "slow_placement_global_attribution_coef": losses["slow"].get(
                "placement_global_attribution_coef",
                args.slow_placement_global_attribution_coef,
            ),
            "slow_placement_global_attribution_mean_abs": losses["slow"].get(
                "placement_global_attribution_mean_abs", 0.0
            ),
            "slow_placement_combined_advantage_std": losses["slow"].get(
                "placement_combined_advantage_std", np.nan
            ),
            "slow_placement_value_loss": losses["slow"].get("placement_value_loss", np.nan),
            "slow_placement_explained_variance": losses["slow"].get(
                "placement_explained_variance", np.nan
            ),
            "slow_placement_post_explained_variance": losses["slow"].get(
                "placement_post_explained_variance", np.nan
            ),
            "slow_placement_entropy": losses["slow"].get("placement_entropy", np.nan),
            "slow_placement_entropy_coef": losses["slow"].get("placement_entropy_coef", np.nan),
            "slow_placement_entropy_next_coef": losses["slow"].get(
                "placement_entropy_next_coef", np.nan
            ),
            "slow_placement_entropy_schedule_coef": losses["slow"].get(
                "placement_entropy_schedule_coef", np.nan
            ),
            "slow_placement_entropy_target": losses["slow"].get(
                "placement_entropy_target", args.slow_placement_entropy_target
            ),
            "slow_placement_entropy_shortfall": losses["slow"].get(
                "placement_entropy_shortfall", 0.0
            ),
            "slow_placement_entropy_saturated": losses["slow"].get(
                "placement_entropy_saturated", 0.0
            ),
            "slow_placement_updates_completed": int(
                losses["slow"].get("placement_updates_completed", 0.0)
            ),
            "slow_placement_approx_kl": losses["slow"].get("placement_approx_kl", np.nan),
            "slow_placement_epochs_completed": losses["slow"].get(
                "placement_epochs_completed", 0.0
            ),
            "slow_placement_kl_early_stop": losses["slow"].get(
                "placement_kl_early_stop", 0.0
            ),
            "slow_placement_optimizer_steps": losses["slow"].get(
                "placement_optimizer_steps", 0.0
            ),
            "fast_loss": losses["fast"]["loss"],
            "fast_policy_loss": losses["fast"]["policy_loss"],
            "fast_value_loss": losses["fast"]["value_loss"],
            "fast_entropy": losses["fast"].get("entropy", np.nan),
            "fast_normalized_entropy": losses["fast"].get(
                "normalized_entropy", np.nan
            ),
            "fast_entropy_control_value": losses["fast"].get(
                "entropy_control_value", np.nan
            ),
            "fast_entropy_normalized_control": losses["fast"].get(
                "entropy_normalized_control",
                float(args.fast_entropy_normalized_control),
            ),
            "fast_entropy_coef": losses["fast"].get("entropy_coef", np.nan),
            "fast_entropy_next_coef": losses["fast"].get("entropy_next_coef", np.nan),
            "fast_entropy_target": losses["fast"].get("entropy_target", args.fast_entropy_target),
            "fast_entropy_shortfall": losses["fast"].get("entropy_shortfall", 0.0),
            "fast_entropy_saturated": losses["fast"].get("entropy_saturated", 0.0),
            "fast_counterfactual_credit_coef": stats[
                "fast_counterfactual_credit_coef"
            ],
            "fast_approx_kl": losses["fast"].get("approx_kl", 0.0),
            "fast_clip_fraction": losses["fast"].get("clip_fraction", 0.0),
            "fast_advantage_mean": losses["fast"].get("advantage_mean", np.nan),
            "fast_advantage_std": losses["fast"].get("advantage_std", np.nan),
            "fast_epochs_completed": losses["fast"].get("epochs_completed", 0.0),
            "fast_kl_early_stop": losses["fast"].get("kl_early_stop", 0.0),
            "fast_optimizer_steps": losses["fast"].get("optimizer_steps", 0.0),
            "fast_minibatches_completed": losses["fast"].get("minibatches_completed", 0.0),
            "fast_minibatches_planned": losses["fast"].get("minibatches_planned", 0.0),
            "fast_samples_seen_fraction": losses["fast"].get("samples_seen_fraction", 0.0),
            "fast_min_group_seen_fraction": losses["fast"].get("min_group_seen_fraction", 0.0),
            "fast_full_batch_kl_checks": losses["fast"].get("full_batch_kl_checks", 0.0),
            "fast_batch_credit": int(agent.fast_agent.batch_credit),
            "fast_kl_backtracks": losses["fast"].get("kl_backtracks", 0.0),
            "fast_accepted_step_lr": losses["fast"].get("accepted_step_lr", 0.0),
            "fast_value_return_mean": agent.fast_agent.ppo.value_return_mean,
            "fast_value_return_std": agent.fast_agent.ppo.value_return_std,
            "slow_team_window_credit": int(agent.slow_agent.team_window_credit),
            "slow_stage_team_credit_fraction": losses["slow"].get("stage_team_credit_fraction", 0.0),
            "fast_group_count": losses["fast"].get("group_count", 0.0),
            "fast_max_group_approx_kl": losses["fast"].get("max_group_approx_kl", 0.0),
            "fast_min_group_approx_kl": losses["fast"].get("min_group_approx_kl", 0.0),
            "fast_group_approx_kl_std": losses["fast"].get("group_approx_kl_std", 0.0),
            "fast_load_approx_kl": format_group_diagnostics(
                fast_group_diagnostics,
                "approx_kl",
            ),
            "fast_load_clip_fraction": format_group_diagnostics(
                fast_group_diagnostics,
                "clip_fraction",
            ),
            "eval_avg_latency_s": eval_stats.get("eval_avg_latency_s", np.nan),
            "eval_avg_latency_std": eval_stats.get("eval_avg_latency_std", np.nan),
            "eval_p95_latency_s": eval_stats.get("eval_p95_latency_s", np.nan),
            "eval_avg_compute_latency_s": eval_stats.get("eval_avg_compute_latency_s", np.nan),
            "eval_avg_link_latency_s": eval_stats.get("eval_avg_link_latency_s", np.nan),
            "eval_avg_access_latency_s": eval_stats.get("eval_avg_access_latency_s", np.nan),
            "eval_avg_propagation_latency_s": eval_stats.get("eval_avg_propagation_latency_s", np.nan),
            "eval_avg_instantaneous_compute_work_gcycles": eval_stats.get("eval_avg_instantaneous_compute_work_gcycles", np.nan),
            "eval_avg_instantaneous_compute_pressure": eval_stats.get("eval_avg_instantaneous_compute_pressure", np.nan),
            "eval_avg_max_instantaneous_compute_pressure": eval_stats.get("eval_avg_max_instantaneous_compute_pressure", np.nan),
            "eval_avg_p95_instantaneous_compute_pressure": eval_stats.get("eval_avg_p95_instantaneous_compute_pressure", np.nan),
            "eval_avg_valid_latency_s": eval_stats.get("eval_avg_valid_latency_s", np.nan),
            "eval_p95_valid_latency_s": eval_stats.get("eval_p95_valid_latency_s", np.nan),
            "eval_avg_penalty_latency_s": eval_stats.get("eval_avg_penalty_latency_s", np.nan),
            "eval_penalty_latency_share": eval_stats.get("eval_penalty_latency_share", np.nan),
            "eval_invalid_actions": eval_stats.get("eval_invalid_actions", np.nan),
            "eval_invalid_action_rate": eval_stats.get("eval_invalid_action_rate", np.nan),
            "eval_deadline_violation_rate": eval_stats.get("eval_deadline_violation_rate", np.nan),
            "eval_deployment_updates": eval_stats.get("eval_deployment_updates", np.nan),
            "eval_request_events": eval_stats.get("eval_request_events", np.nan),
            "eval_settlement_steps": eval_stats.get("eval_settlement_steps", np.nan),
            "eval_logical_steps": eval_stats.get("eval_logical_steps", np.nan),
            "eval_temporal_sampling_fraction": eval_stats.get("eval_temporal_sampling_fraction", np.nan),
            "eval_avg_replicas_per_stage": eval_stats.get("eval_avg_replicas_per_stage", np.nan),
            "eval_single_replica_stage_rate": eval_stats.get("eval_single_replica_stage_rate", np.nan),
            "eval_total_deployed_replicas": eval_stats.get("eval_total_deployed_replicas", np.nan),
            "eval_avg_node_compute_load": eval_stats.get("eval_avg_node_compute_load", np.nan),
            "eval_max_node_compute_load": eval_stats.get("eval_max_node_compute_load", np.nan),
            "eval_p95_node_compute_load": eval_stats.get("eval_p95_node_compute_load", np.nan),
            "eval_std_node_compute_load": eval_stats.get("eval_std_node_compute_load", np.nan),
            "eval_active_node_rate": eval_stats.get("eval_active_node_rate", np.nan),
            "eval_hot_node_rate": eval_stats.get("eval_hot_node_rate", np.nan),
            "eval_avg_link_load": eval_stats.get("eval_avg_link_load", np.nan),
            "eval_max_link_load": eval_stats.get("eval_max_link_load", np.nan),
            "eval_p95_link_load": eval_stats.get("eval_p95_link_load", np.nan),
            "eval_std_link_load": eval_stats.get("eval_std_link_load", np.nan),
            "eval_active_link_rate": eval_stats.get("eval_active_link_rate", np.nan),
            "eval_hot_link_rate": eval_stats.get("eval_hot_link_rate", np.nan),
            "eval_avg_node_memory_util": eval_stats.get("eval_avg_node_memory_util", np.nan),
            "eval_max_node_memory_util": eval_stats.get("eval_max_node_memory_util", np.nan),
            "eval_avg_node_storage_util": eval_stats.get("eval_avg_node_storage_util", np.nan),
            "eval_max_node_storage_util": eval_stats.get("eval_max_node_storage_util", np.nan),
            "eval_deployed_node_rate": eval_stats.get("eval_deployed_node_rate", np.nan),
            "eval_idle_deployed_node_rate": eval_stats.get("eval_idle_deployed_node_rate", np.nan),
            "eval_scheduled_stage_invocations": eval_stats.get("eval_scheduled_stage_invocations", np.nan),
            "eval_used_replica_rate": eval_stats.get("eval_used_replica_rate", np.nan),
            "eval_idle_replica_rate": eval_stats.get("eval_idle_replica_rate", np.nan),
            "eval_used_replicas_per_stage": eval_stats.get("eval_used_replicas_per_stage", np.nan),
            "eval_avg_replica_use_entropy": eval_stats.get("eval_avg_replica_use_entropy", np.nan),
            "eval_avg_replica_use_top1_share": eval_stats.get("eval_avg_replica_use_top1_share", np.nan),
            "eval_cross_node_stage_transition_rate": eval_stats.get("eval_cross_node_stage_transition_rate", np.nan),
            "eval_first_window_avg_latency_s": eval_stats.get("eval_first_window_avg_latency_s", np.nan),
            "eval_last_window_avg_latency_s": eval_stats.get("eval_last_window_avg_latency_s", np.nan),
            "eval_window_latency_delta_s": eval_stats.get("eval_window_latency_delta_s", np.nan),
            "eval_policy_entropy": diagnostic_stats.get("eval_policy_entropy", np.nan),
            "eval_top1_prob": diagnostic_stats.get("eval_top1_prob", np.nan),
            "eval_top1_margin": diagnostic_stats.get("eval_top1_margin", np.nan),
            "eval_action_change_rate": diagnostic_stats.get("eval_action_change_rate", np.nan),
            "eval_stochastic_avg_latency_s": diagnostic_stats.get("eval_stochastic_avg_latency_s", np.nan),
            "eval_deterministic_avg_latency_s": diagnostic_stats.get("eval_deterministic_avg_latency_s", np.nan),
            **prefix_eval_stats(seen_eval_stats, "seen_eval_"),
        }
        append_log(log_path, log_row)
        episode_label = (
            f"episode={episode_number:03d}"
            if episode_start_number == episode_number
            else f"episodes={episode_start_number:03d}-{episode_number:03d}"
        )
        print(
            "update={:03d} {} demand_seed={}-{} load={:.2f}-{:.2f} start_min={:.0f}-{:.0f} rollouts={} complete={} window={:02d} group={}-{} requests={} request_events={} sampled_steps={}/{} sim_hours={:.2f} episode_frac={:.1%} "
            "avg_reward={:.4f} avg_latency={:.4f}s valid_latency={:.4f}s penalty_latency={:.4f}s train_reward={:.4f} diag_res={:.4f} slowR={:.4f} invalid={} invalid_rate={:.2%} deployments={} "
            "replicas={:.2f}/{:.0f}-{:.0f} single={:.1%} "
            "used_replica={:.1%} idle_replica={:.1%} use_entropy={:.3f} top1_use={:.1%} cross_stage={:.1%} "
            "node_load={:.1%}/{:.1%} active={:.1%} hot={:.1%} link_load={:.2%}/{:.1%} active_link={:.1%} hot_link={:.1%} mem={:.1%}/{:.1%} storage={:.1%}/{:.1%} service_mem={:.1%}/{:.1%} service_storage={:.1%}/{:.1%} idle_deployed={:.1%} "
            "slow_update={} slow_buffer={}/{} slow_loss={:.4f} slow_windows={:.0f} critic_ev={:.3f} "
            "fast_loss={:.4f} fast_epochs={:.0f} fast_steps={:.0f} fast_cover={:.1%} fast_kl={:.5f}/{:.5f}".format(
                update + 1,
                episode_label,
                demand_seed,
                demand_seed_end,
                load_multiplier,
                load_multiplier_end,
                start_minute,
                start_minute_end,
                len(rollout_stats),
                int(stats["episode_complete"]),
                window_in_episode,
                load_group,
                load_group_end,
                int(stats["requests"]),
                int(stats["request_events"]),
                int(stats["settlement_steps"]),
                int(round(stats["logical_steps"])),
                stats["simulated_hours"],
                stats["episode_fraction"],
                stats["avg_reward"],
                stats["avg_latency_s"],
                stats["avg_valid_latency_s"],
                stats["avg_penalty_latency_s"],
                stats["avg_train_reward"],
                stats["avg_diagnostic_resource_penalty"],
                stats["slow_window_return"],
                int(stats["invalid_actions"]),
                stats["invalid_action_rate"],
                int(stats["deployment_updates"]),
                stats["avg_replicas_per_stage"],
                stats["min_replicas_per_stage"],
                stats["max_replicas_per_stage"],
                stats["single_replica_stage_rate"],
                stats["used_replica_rate"],
                stats["idle_replica_rate"],
                stats["avg_replica_use_entropy"],
                stats["avg_replica_use_top1_share"],
                stats["cross_node_stage_transition_rate"],
                stats["avg_node_compute_load"],
                stats["max_node_compute_load"],
                stats["active_node_rate"],
                stats["hot_node_rate"],
                stats["avg_link_load"],
                stats["max_link_load"],
                stats["active_link_rate"],
                stats["hot_link_rate"],
                stats["avg_node_memory_util"],
                stats["max_node_memory_util"],
                stats["avg_node_storage_util"],
                stats["max_node_storage_util"],
                stats["avg_service_memory_util"],
                stats["max_service_memory_util"],
                stats["avg_service_storage_util"],
                stats["max_service_storage_util"],
                stats["idle_deployed_node_rate"],
                int(slow_updated),
                int(slow_windows_buffered),
                args.slow_windows_per_update,
                losses["slow"]["loss"],
                losses["slow"].get("window_count", 0.0),
                losses["slow"].get("critic_explained_variance", 0.0),
                losses["fast"]["loss"],
                losses["fast"].get("epochs_completed", 0.0),
                losses["fast"].get("optimizer_steps", 0.0),
                losses["fast"].get("min_group_seen_fraction", 0.0),
                losses["fast"].get("approx_kl", 0.0),
                losses["fast"].get("max_group_approx_kl", 0.0),
            )
        )
        if eval_stats:
            print(
                "  eval_mean_latency={:.4f}s eval_valid_latency={:.4f}s eval_penalty_latency={:.4f}s eval_std={:.4f}s eval_p95={:.4f}s invalid={:.2f} "
                "eval_replicas={:.2f} single={:.1%} used_replica={:.1%} use_entropy={:.3f} top1_use={:.1%} cross_stage={:.1%} "
                "node_load={:.1%}/{:.1%} hot={:.1%} link_load={:.2%}/{:.1%} hot_link={:.1%}".format(
                    eval_stats["eval_avg_latency_s"],
                    eval_stats["eval_avg_valid_latency_s"],
                    eval_stats["eval_avg_penalty_latency_s"],
                    eval_stats["eval_avg_latency_std"],
                    eval_stats["eval_p95_latency_s"],
                    eval_stats["eval_invalid_actions"],
                    eval_stats["eval_avg_replicas_per_stage"],
                    eval_stats["eval_single_replica_stage_rate"],
                    eval_stats["eval_used_replica_rate"],
                    eval_stats["eval_avg_replica_use_entropy"],
                    eval_stats["eval_avg_replica_use_top1_share"],
                    eval_stats["eval_cross_node_stage_transition_rate"],
                    eval_stats["eval_avg_node_compute_load"],
                    eval_stats["eval_max_node_compute_load"],
                    eval_stats["eval_hot_node_rate"],
                    eval_stats["eval_avg_link_load"],
                    eval_stats["eval_max_link_load"],
                    eval_stats["eval_hot_link_rate"],
                )
            )
        should_replace_best = (
            (checkpoint_ready and not best_checkpoint_ready)
            or (checkpoint_ready == best_checkpoint_ready and checkpoint_score < best_checkpoint_score)
        )
        common_checkpoint_metadata: dict[str, object] = {
            "args": vars(args).copy(),
            "update": update + 1,
            "completed_updates": update + 1,
            "completed_rollouts": training_rollout_idx,
            "completed_episodes": train_episode_idx,
            "episode_minutes": args.episode_minutes,
            "checkpoint_at_episode_boundary": bool(train_env is None or train_env.done),
            "avg_latency_s": float(stats["avg_latency_s"]),
            "avg_reward": float(stats["avg_reward"]),
            "best_latency_s": best_latency,
            "best_checkpoint_score": min(best_checkpoint_score, checkpoint_score)
            if should_replace_best
            else best_checkpoint_score,
            "best_checkpoint_ready": best_checkpoint_ready or checkpoint_ready,
            "best_probe_score": min(best_probe_score, probe_result["mean_latency_s"]) if probe_result else best_probe_score,
            "checkpoint_reference_compute": reference_checkpoint_compute,
            "proposed_design": args.proposed_design,
            "checkpoint_score": checkpoint_score,
            "checkpoint_score_load_slope": checkpoint_load_slope,
            "checkpoint_reference_load": reference_checkpoint_load,
            "checkpoint_selection_window": args.best_checkpoint_window,
            "checkpoint_selection_history": checkpoint_selection_history,
            "slow_lr_controller_state": slow_lr_controller.state_dict(),
            "run_name": run_name,
            "train_mode": args.train_mode,
        }
        if args.save_best and should_replace_best:
            best_checkpoint_score = checkpoint_score
            best_checkpoint_ready = checkpoint_ready
            common_checkpoint_metadata["best_checkpoint_score"] = best_checkpoint_score
            common_checkpoint_metadata["best_checkpoint_ready"] = best_checkpoint_ready
            if not joint_credit_v2:
                save_checkpoint(
                    agent,
                    save_dir / "best.pt",
                    {**common_checkpoint_metadata, "selection_kind": "load_adjusted_rolling_train"},
                    training_random_streams,
                )
            if checkpoint_ready:
                save_checkpoint(
                    agent,
                    save_dir / "best_rolling.pt",
                    {**common_checkpoint_metadata, "selection_kind": "recent_workload_rolling_train_v2" if joint_credit_v2 else "load_adjusted_rolling_train"},
                    training_random_streams,
                )
        if joint_credit_v2 and args.save_best and probe_result and probe_result["mean_latency_s"] < best_probe_score:
            best_probe_score = probe_result["mean_latency_s"]
            common_checkpoint_metadata["best_probe_score"] = best_probe_score
            save_checkpoint(agent, save_dir / "best.pt", {
                **common_checkpoint_metadata, "selection_kind":"post_update_nominal_probe_v2",
                "selection_score":best_probe_score, "probe_result":probe_result}, training_random_streams)
        if eval_stats and args.save_best:
            selection_latency = float(eval_stats["eval_avg_latency_s"])
            if selection_latency < best_latency:
                best_latency = selection_latency
                common_checkpoint_metadata["best_latency_s"] = best_latency
                save_checkpoint(
                    agent,
                    save_dir / "best_eval.pt",
                    {
                        **common_checkpoint_metadata,
                        "avg_latency_s": best_latency,
                        "selection_kind": "held_out_eval",
                    },
                    training_random_streams,
                )
        save_checkpoint(
            agent,
            save_dir / "latest.pt",
            {**common_checkpoint_metadata, "selection_kind": "latest"},
            training_random_streams,
        )
        if args.checkpoint_interval and (update + 1) % args.checkpoint_interval == 0:
            save_checkpoint(
                agent,
                save_dir / "snapshots" / f"update_{update + 1:04d}.pt",
                {**common_checkpoint_metadata, "selection_kind": "periodic_snapshot"},
                training_random_streams,
            )

    if episode_rollout_stats:
        append_log(
            episode_log_path,
            build_episode_metrics_row(episode_rollout_stats, episode_rollout_contexts),
        )

    if args.deterministic_eval:
        stats = evaluate_agent(
            args,
            agent,
            seed_base=10_000,
            max_requests=args.eval_requests,
            train_mode=args.train_mode,
            rollout_unit=eval_rollout_unit,
        )
        print(
            "eval seeds={} requests_per_seed={} avg_latency={:.4f}s valid_latency={:.4f}s penalty_latency={:.4f}s std={:.4f}s p95_latency={:.4f}s invalid={:.2f} violation_rate={:.4f} replicas={:.2f} single={:.1%}".format(
                args.eval_seeds,
                args.eval_requests,
                stats["eval_avg_latency_s"],
                stats["eval_avg_valid_latency_s"],
                stats["eval_avg_penalty_latency_s"],
                stats["eval_avg_latency_std"],
                stats["eval_p95_latency_s"],
                stats["eval_invalid_actions"],
                stats["eval_deadline_violation_rate"],
                stats["eval_avg_replicas_per_stage"],
                stats["eval_single_replica_stage_rate"],
            )
        )

    if args.updates > 0:
        save_checkpoint(
            agent,
            save_dir / "last.pt",
            {
                "args": vars(args).copy(),
                "update": target_update,
                "completed_updates": target_update,
                "completed_rollouts": training_rollout_idx,
                "completed_episodes": train_episode_idx,
                "episode_minutes": args.episode_minutes,
                "checkpoint_at_episode_boundary": bool(train_env is None or train_env.done),
                "best_latency_s": best_latency,
                "best_checkpoint_score": best_checkpoint_score,
                "best_checkpoint_ready": best_checkpoint_ready,
                "best_probe_score": best_probe_score,
                "checkpoint_reference_compute": reference_checkpoint_compute,
                "proposed_design": args.proposed_design,
                "checkpoint_score": checkpoint_score,
                "checkpoint_score_load_slope": checkpoint_load_slope,
                "checkpoint_reference_load": reference_checkpoint_load,
                "checkpoint_selection_window": args.best_checkpoint_window,
                "checkpoint_selection_history": checkpoint_selection_history,
                "slow_lr_controller_state": slow_lr_controller.state_dict(),
                "selection_kind": "final",
                "run_name": run_name,
                "train_mode": args.train_mode,
            },
            training_random_streams,
        )
        print(f"log={log_path}")
        print(f"episode_log={episode_log_path}")
        print(f"rollout_log={rollout_log_path}")
        print(f"checkpoint={save_dir / 'last.pt'}")
    print(f"elapsed={datetime.now().replace(microsecond=0) - start}")


if __name__ == "__main__":
    main()
